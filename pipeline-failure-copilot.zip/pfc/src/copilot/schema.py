"""Canonical failure record — the ingestion contract.

Every orchestrator adapter emits this shape and nothing else. The agents,
retrieval layer and evaluation harness only ever see this, which is what
makes the system cloud-agnostic: a new platform is a new adapter, not a
new assistant.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any


class RunStatus(str, Enum):
    SUCCESS = "success"
    FAILED = "failed"
    RUNNING = "running"
    CANCELLED = "cancelled"


class Severity(str, Enum):
    P1 = "p1"
    P2 = "p2"
    P3 = "p3"


def _utc(value: Any) -> datetime:
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    if isinstance(value, str):
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    raise TypeError(f"cannot coerce {value!r} to datetime")


@dataclass
class FailureRecord:
    """One failed pipeline activity, normalized."""

    run_id: str
    pipeline: str
    activity: str
    platform: str                     # adf | airflow | databricks | synapse
    status: RunStatus
    started_at: datetime
    ended_at: datetime | None = None
    error_code: str | None = None
    error_text: str = ""              # ALWAYS post-redaction
    upstream_deps: list[str] = field(default_factory=list)
    downstream_deps: list[str] = field(default_factory=list)
    duration_s: float | None = None
    attempt: int = 1
    severity: Severity = Severity.P2
    tenant: str = "default"           # onboarded application id
    raw_ref: str | None = None        # pointer to source log, never the log
    signature: str | None = None      # set by the diagnostician
    redaction_applied: bool = False

    def __post_init__(self) -> None:
        self.started_at = _utc(self.started_at)
        if self.ended_at:
            self.ended_at = _utc(self.ended_at)
        if self.duration_s is None and self.ended_at:
            self.duration_s = (self.ended_at - self.started_at).total_seconds()
        if isinstance(self.status, str):
            self.status = RunStatus(self.status)
        if isinstance(self.severity, str):
            self.severity = Severity(self.severity)

    @property
    def key(self) -> str:
        return f"{self.platform}:{self.pipeline}:{self.activity}:{self.run_id}"

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["status"] = self.status.value
        d["severity"] = self.severity.value
        d["started_at"] = self.started_at.isoformat()
        d["ended_at"] = self.ended_at.isoformat() if self.ended_at else None
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "FailureRecord":
        allowed = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in d.items() if k in allowed})


@dataclass
class Resolution:
    """What actually fixed a failure. This is the asset the brief says is missing."""

    resolution_id: str
    signature: str
    summary: str
    action_taken: str
    resolved_by: str
    resolved_at: datetime
    run_id: str
    succeeded: bool = True
    notes: str = ""

    def __post_init__(self) -> None:
        self.resolved_at = _utc(self.resolved_at)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["resolved_at"] = self.resolved_at.isoformat()
        return d


@dataclass
class Evidence:
    """Every claim the assistant makes must carry one of these."""

    kind: str          # run | log_line | resolution | lineage
    ref: str
    detail: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class Diagnosis:
    root_cause: str
    signature: str
    confidence: float
    evidence: list[Evidence] = field(default_factory=list)
    abstained: bool = False
    reason: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "root_cause": self.root_cause,
            "signature": self.signature,
            "confidence": round(self.confidence, 3),
            "evidence": [e.to_dict() for e in self.evidence],
            "abstained": self.abstained,
            "reason": self.reason,
        }


@dataclass
class Recommendation:
    action: str
    rationale: str
    success_rate: float
    observations: int
    tool: str | None = None
    tool_args: dict[str, Any] = field(default_factory=dict)
    evidence: list[Evidence] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "action": self.action,
            "rationale": self.rationale,
            "success_rate": round(self.success_rate, 3),
            "observations": self.observations,
            "tool": self.tool,
            "tool_args": self.tool_args,
            "evidence": [e.to_dict() for e in self.evidence],
        }
