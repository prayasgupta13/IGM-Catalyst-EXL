"""LLM abstraction layer.

The model is a swappable component, not the architecture. Two guarantees
enforced here rather than left to prompt discipline:

  * every prompt passes the redaction guard before it leaves the process
  * every call is traced and its token usage metered
"""
from __future__ import annotations

import abc
import json
import os
from dataclasses import dataclass
from typing import Any

from ..config import settings
from ..observability import METRICS, log_event, span
from ..redaction import assert_clean


@dataclass
class LLMResponse:
    text: str
    model: str
    input_tokens: int = 0
    output_tokens: int = 0

    def json(self) -> Any:
        cleaned = self.text.strip().removeprefix("```json").removeprefix("```").removesuffix("```")
        return json.loads(cleaned)


class LLMClient(abc.ABC):
    name = "base"

    @abc.abstractmethod
    def _complete(self, system: str, prompt: str, max_tokens: int) -> LLMResponse: ...

    def complete(self, system: str, prompt: str, max_tokens: int = 800) -> LLMResponse:
        assert_clean(prompt)          # hard boundary: no unredacted text leaves
        assert_clean(system)
        with span("llm.complete", provider=self.name, model=settings.llm_model) as bag:
            resp = self._complete(system, prompt, max_tokens)
            bag["input_tokens"] = resp.input_tokens
            bag["output_tokens"] = resp.output_tokens
        METRICS.inc("llm.calls", 1, provider=self.name)
        METRICS.inc("llm.input_tokens", resp.input_tokens)
        METRICS.inc("llm.output_tokens", resp.output_tokens)
        return resp


class MockClient(LLMClient):
    """Deterministic summariser used in tests, CI and offline demos.

    It never invents a root cause: it renders the evidence it was given.
    That is deliberate — it proves the grounding is done by retrieval, not
    by the model.
    """

    name = "mock"

    def _complete(self, system: str, prompt: str, max_tokens: int) -> LLMResponse:
        facts = [l for l in prompt.splitlines() if l.startswith("- ")]
        head = facts[0][2:] if facts else "No evidence was retrieved."
        body = " ".join(f[2:] for f in facts[1:3])
        text = f"{head} {body}".strip()
        return LLMResponse(text=text, model="mock-deterministic",
                           input_tokens=len(prompt) // 4, output_tokens=len(text) // 4)


class AnthropicClient(LLMClient):  # pragma: no cover - needs a key
    name = "anthropic"

    def __init__(self) -> None:
        from anthropic import Anthropic
        key = settings.llm_api_key or os.environ["ANTHROPIC_API_KEY"]
        self.client = Anthropic(api_key=key)

    def _complete(self, system: str, prompt: str, max_tokens: int) -> LLMResponse:
        msg = self.client.messages.create(
            model=settings.llm_model, max_tokens=max_tokens, system=system,
            messages=[{"role": "user", "content": prompt}],
        )
        text = "".join(b.text for b in msg.content if b.type == "text")
        return LLMResponse(text=text, model=settings.llm_model,
                           input_tokens=msg.usage.input_tokens,
                           output_tokens=msg.usage.output_tokens)


def get_client() -> LLMClient:
    if settings.llm_provider == "anthropic":
        try:
            return AnthropicClient()
        except Exception as exc:  # never fail closed into an unsafe path
            log_event("llm.fallback", reason=str(exc), provider="mock")
    return MockClient()
