"""HTTP surface.

Deliberately thin: it authenticates, delegates and returns evidence. All
policy lives in the security package so it cannot be bypassed by adding a
new endpoint.
"""
from __future__ import annotations

from typing import Any

from fastapi import Depends, FastAPI, Header, HTTPException, Response
from pydantic import BaseModel, Field

from ..agents import Copilot
from ..agents.operator import ActionPlan
from ..config import ROOT, settings
from ..observability import METRICS
from ..security.audit import AUDIT
from ..security.onboarding import Registry
from ..security.rbac import AccessDenied, Principal

app = FastAPI(title="Pipeline Failure Copilot", version="1.0.0")
registry = Registry(ROOT / "onboarding" / "manifests")
copilot = Copilot(registry)

# In production these come from the org IdP (OIDC/Entra) and the token is
# exchanged for a short-lived, on-behalf-of platform credential. The demo
# header keeps the repo runnable without an IdP.
DEMO_PRINCIPALS = {
    "demo-viewer": Principal("v.viewer", ("viewer",), ("billing",)),
    "demo-l1": Principal("l1.support", ("support_l1",), ("billing",)),
    "demo-l2": Principal("l2.support", ("support_l2",), ("billing",), mfa=True),
    "demo-engineer": Principal("p.gupta", ("data_engineer",), ("billing",), mfa=True),
}


def current_principal(x_copilot_token: str = Header(default="")) -> Principal:
    principal = DEMO_PRINCIPALS.get(x_copilot_token)
    if principal is None:
        raise HTTPException(401, "unknown or missing X-Copilot-Token")
    return principal


class AskRequest(BaseModel):
    question: str = Field(min_length=3, max_length=500)
    tenant: str = "billing"


class ApproveRequest(BaseModel):
    question: str
    plan_id: str
    tenant: str = "billing"


@app.get("/healthz")
def healthz() -> dict[str, Any]:
    ok, msg = AUDIT.verify()
    return {"status": "ok", "audit_chain": ok, "audit_detail": msg,
            "actions_enabled": settings.allow_actions,
            "llm_provider": settings.llm_provider}


@app.get("/metrics")
def metrics() -> Response:
    return Response(METRICS.prometheus(), media_type="text/plain")


@app.get("/tenants")
def tenants(_: Principal = Depends(current_principal)) -> list[dict[str, Any]]:
    return [{"tenant_id": m.tenant_id, "application": m.application,
             "state": m.state, "classification": m.data_classification,
             "enabled_actions": m.enabled_actions,
             "attestation_due": m.attestation_due()} for m in registry.all()]


@app.post("/ask")
def ask(req: AskRequest, principal: Principal = Depends(current_principal)) -> dict[str, Any]:
    try:
        return copilot.ask(req.question, principal, req.tenant).to_dict()
    except (AccessDenied, PermissionError) as exc:
        raise HTTPException(403, str(exc))


@app.post("/approve")
def approve(req: ApproveRequest,
            principal: Principal = Depends(current_principal)) -> dict[str, Any]:
    answer = copilot.ask(req.question, principal, req.tenant)
    if not answer.plan:
        raise HTTPException(409, "no action was proposed for that question")
    if answer.plan.plan_id != req.plan_id:
        raise HTTPException(409, "plan_id does not match the current proposal")
    try:
        return {"result": copilot.approve(answer.plan, principal, req.plan_id)}
    except (AccessDenied, PermissionError) as exc:
        raise HTTPException(403, str(exc))


@app.get("/audit")
def audit(tail: int = 20, _: Principal = Depends(current_principal)) -> dict[str, Any]:
    ok, msg = AUDIT.verify()
    return {"chain_valid": ok, "detail": msg, "entries": AUDIT.entries()[-tail:]}
