"""Replay harness — the evidence that the system works.

Given a labelled set of historical failures (what the on-call engineer
actually concluded), replay them through the assistant and score:

  precision@1        share where the top diagnosis matched the label
  abstention_rate    share where it correctly declined to answer
  false_confidence   answered confidently AND was wrong  <- the number that matters
  mean_latency_ms

false_confidence is the metric a reviewer should look at first: an assistant
that is 80% right and never wrong-but-certain is safer than one that is 90%
right and confidently wrong the rest of the time.
"""
from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from ..agents.diagnostician import diagnose
from ..lineage import LineageGraph
from ..schema import FailureRecord
from ..store import query_failures


@dataclass
class ReplayResult:
    cases: int
    correct: int
    abstained: int
    false_confidence: int
    precision_at_1: float
    abstention_rate: float
    false_confidence_rate: float
    mean_latency_ms: float
    details: list[dict[str, Any]]

    def summary(self) -> str:
        return (f"cases={self.cases} precision@1={self.precision_at_1:.2%} "
                f"abstained={self.abstention_rate:.2%} "
                f"false_confidence={self.false_confidence_rate:.2%} "
                f"mean_latency={self.mean_latency_ms:.1f}ms")


def run_replay(labels_path: str, tenant: str = "billing") -> ReplayResult:
    labels = json.loads(Path(labels_path).read_text())
    corpus = query_failures(tenant=tenant, limit=1000)
    graph = LineageGraph.from_records(corpus)
    by_run = {r.run_id: r for r in corpus}

    correct = abstained = false_conf = 0
    details, latencies = [], []

    for case in labels:
        target = by_run.get(str(case["run_id"]))
        if target is None:
            continue
        t0 = time.perf_counter()
        # exclude the case itself from its own evidence
        others = [r for r in corpus if r.run_id != target.run_id]
        d = diagnose(target, others, graph)
        latencies.append((time.perf_counter() - t0) * 1000)

        hit = d.signature == case["expected_signature"]
        if d.abstained:
            abstained += 1
        elif hit:
            correct += 1
        else:
            false_conf += 1

        details.append({"run_id": target.run_id, "expected": case["expected_signature"],
                        "predicted": d.signature, "confidence": d.confidence,
                        "abstained": d.abstained, "correct": hit})

    n = len(details) or 1
    answered = n - abstained or 1
    return ReplayResult(
        cases=len(details), correct=correct, abstained=abstained,
        false_confidence=false_conf,
        precision_at_1=correct / answered,
        abstention_rate=abstained / n,
        false_confidence_rate=false_conf / n,
        mean_latency_ms=sum(latencies) / len(latencies) if latencies else 0.0,
        details=details,
    )


def write_report(result: ReplayResult, path: str = "data/replay_report.json") -> str:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(asdict(result), indent=2))
    return path
