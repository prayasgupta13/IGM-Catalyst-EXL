"""Central config. Everything is env-overridable; nothing secret is defaulted."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _f(name: str, default: float) -> float:
    return float(os.getenv(name, default))


def _b(name: str, default: bool) -> bool:
    return os.getenv(name, str(default)).lower() in {"1", "true", "yes"}


@dataclass(frozen=True)
class Settings:
    # --- storage ---
    db_path: str = os.getenv("COPILOT_DB", str(ROOT / "data" / "copilot.db"))
    audit_path: str = os.getenv("COPILOT_AUDIT", str(ROOT / "data" / "audit.log"))

    # --- llm ---
    llm_provider: str = os.getenv("LLM_PROVIDER", "mock")   # mock | anthropic
    llm_model: str = os.getenv("LLM_MODEL", "claude-sonnet-4-6")
    llm_api_key: str | None = os.getenv("ANTHROPIC_API_KEY")

    # --- agent behaviour ---
    confidence_threshold: float = _f("CONFIDENCE_THRESHOLD", 0.55)
    max_evidence_items: int = int(os.getenv("MAX_EVIDENCE", 6))
    log_window_lines: int = int(os.getenv("LOG_WINDOW_LINES", 40))

    # --- autonomy: graded, and off by default ---
    allow_actions: bool = _b("ALLOW_ACTIONS", False)          # phase 3 switch
    allow_auto_remediate: bool = _b("ALLOW_AUTO_REMEDIATE", False)

    # --- observability ---
    otel_enabled: bool = _b("OTEL_ENABLED", True)
    otel_endpoint: str | None = os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT")
    service_name: str = os.getenv("OTEL_SERVICE_NAME", "pipeline-failure-copilot")


settings = Settings()
