"""Minimal OpenLineage emitter.

The assistant is a lineage *consumer* for diagnosis and a lineage *producer*
for its own actions: when the Operator runs a backfill, that run is emitted
as an OpenLineage event so the assistant's writes appear in the same lineage
graph as everything else. Nothing the assistant does is invisible.
"""
from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

PRODUCER = "https://github.com/exl/pipeline-failure-copilot"


def build_event(event_type: str, job_name: str, namespace: str = "copilot",
                inputs: list[str] | None = None, outputs: list[str] | None = None,
                run_id: str | None = None, **facets: Any) -> dict[str, Any]:
    return {
        "eventType": event_type,                      # START | COMPLETE | FAIL
        "eventTime": datetime.now(timezone.utc).isoformat(),
        "producer": PRODUCER,
        "run": {"runId": run_id or str(uuid.uuid4()),
                "facets": {"copilot": {"_producer": PRODUCER, **facets}}},
        "job": {"namespace": namespace, "name": job_name},
        "inputs": [{"namespace": namespace, "name": n} for n in (inputs or [])],
        "outputs": [{"namespace": namespace, "name": n} for n in (outputs or [])],
    }


class FileEmitter:
    """Writes newline-delimited OpenLineage events. Swap for an HTTP transport
    against Marquez / Purview / Unity Catalog without touching callers."""

    def __init__(self, path: str | Path = "data/lineage_events.ndjson") -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def emit(self, event: dict[str, Any]) -> dict[str, Any]:
        with self.path.open("a") as fh:
            fh.write(json.dumps(event) + "\n")
        return event

    def read_all(self) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        return [json.loads(l) for l in self.path.read_text().splitlines() if l.strip()]
