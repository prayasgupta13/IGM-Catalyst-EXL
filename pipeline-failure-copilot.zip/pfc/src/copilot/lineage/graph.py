"""Lineage and impact analysis.

Two questions the assistant must answer that a log chatbot cannot:
  * "what caused this?"      -> walk upstream to the earliest failure in the chain
  * "what does this affect?" -> walk downstream to the assets at risk

Edges are built from the dependency fields every adapter populates, and can
be enriched from OpenLineage events (see openlineage.py). Both directions
are cited as lineage evidence.
"""
from __future__ import annotations

from collections import defaultdict, deque
from datetime import timedelta
from dataclasses import dataclass, field
from typing import Iterable

from ..schema import FailureRecord, RunStatus


def node_id(pipeline: str, activity: str) -> str:
    return f"{pipeline}.{activity}"


@dataclass
class LineageGraph:
    upstream: dict[str, set[str]] = field(default_factory=lambda: defaultdict(set))
    downstream: dict[str, set[str]] = field(default_factory=lambda: defaultdict(set))
    nodes: set[str] = field(default_factory=set)

    # ------------------------------------------------------------- building
    def add_edge(self, parent: str, child: str) -> None:
        self.nodes.update({parent, child})
        self.downstream[parent].add(child)
        self.upstream[child].add(parent)

    @classmethod
    def from_records(cls, records: Iterable[FailureRecord]) -> "LineageGraph":
        g = cls()
        for r in records:
            me = node_id(r.pipeline, r.activity)
            g.nodes.add(me)
            for up in r.upstream_deps:
                g.add_edge(up if "." in up else node_id(r.pipeline, up), me)
            for down in r.downstream_deps:
                g.add_edge(me, down if "." in down else node_id(r.pipeline, down))
        return g

    def add_openlineage_event(self, event: dict) -> None:
        """Accept a subset of the OpenLineage RunEvent spec."""
        job = event.get("job", {})
        me = f"{job.get('namespace','default')}.{job.get('name','unknown')}"
        for i in event.get("inputs", []):
            self.add_edge(f"{i.get('namespace','default')}.{i.get('name')}", me)
        for o in event.get("outputs", []):
            self.add_edge(me, f"{o.get('namespace','default')}.{o.get('name')}")

    # ------------------------------------------------------------ traversal
    def _walk(self, start: str, edges: dict[str, set[str]], max_depth: int) -> list[tuple[str, int]]:
        seen, out, q = {start}, [], deque([(start, 0)])
        while q:
            node, depth = q.popleft()
            if depth >= max_depth:
                continue
            for nxt in sorted(edges.get(node, ())):
                if nxt not in seen:
                    seen.add(nxt)
                    out.append((nxt, depth + 1))
                    q.append((nxt, depth + 1))
        return out

    def blast_radius(self, pipeline: str, activity: str, max_depth: int = 4) -> list[tuple[str, int]]:
        """Everything downstream that is now at risk. Answers the owner's question."""
        return self._walk(node_id(pipeline, activity), self.downstream, max_depth)

    def ancestors(self, pipeline: str, activity: str, max_depth: int = 4) -> list[tuple[str, int]]:
        return self._walk(node_id(pipeline, activity), self.upstream, max_depth)

    def root_candidates(self, target: FailureRecord,
                        all_records: Iterable[FailureRecord],
                        window_hours: int = 24) -> list[FailureRecord]:
        """Upstream activities that ALSO failed in the same window.

        This is the difference between 'the task that errored' and 'the thing
        that broke'. A downstream OOM caused by an upstream throttle should
        point the engineer upstream.
        """
        ancestry = {n for n, _ in self.ancestors(target.pipeline, target.activity)}
        window_start = target.started_at - timedelta(hours=window_hours)
        out = []
        for r in all_records:
            if r.key == target.key or r.status != RunStatus.FAILED:
                continue
            if node_id(r.pipeline, r.activity) not in ancestry:
                continue
            # only failures in the same incident window count as a root candidate;
            # an unrelated failure six weeks ago is not the cause of tonight's run
            if window_start <= r.started_at <= target.started_at:
                out.append(r)
        # closest preceding failure first
        return sorted(out, key=lambda r: r.started_at, reverse=True)
