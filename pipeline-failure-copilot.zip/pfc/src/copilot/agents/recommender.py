"""Recommender — ranks corrective actions by observed success rate.

Ranking is computed from the resolution history, not asserted by the model.
A fix that failed before ranks below one that worked, and the count is shown
so the engineer can judge how much history is behind the number.
"""
from __future__ import annotations

from collections import defaultdict

from ..observability import METRICS, span
from ..schema import Diagnosis, Evidence, FailureRecord, Recommendation
from ..store import resolutions_for

#: maps a signature to the tool the action would use, with argument builders
PLAYBOOK: dict[str, tuple[str, callable]] = {
    "schema_drift:type_mismatch:timestamp": (
        "backfill", lambda r: {"pipeline": r.pipeline,
                               "window_start": r.started_at.isoformat(),
                               "window_end": (r.ended_at or r.started_at).isoformat()}),
    "throttling:rate_limit:429": ("rerun", lambda r: {"pipeline": r.pipeline,
                                                      "activity": r.activity,
                                                      "run_id": r.run_id}),
    "resource:oom:executor": ("scale_cluster", lambda r: {"job": r.pipeline,
                                                          "executor_memory": "28g"}),
    "db:deadlock": ("rerun", lambda r: {"pipeline": r.pipeline, "activity": r.activity,
                                        "run_id": r.run_id}),
}


def recommend(diagnosis: Diagnosis, target: FailureRecord,
              top_n: int = 3) -> list[Recommendation]:
    with span("recommender.rank", signature=diagnosis.signature) as bag:
        if diagnosis.abstained:
            bag["recommendations"] = 0
            return []

        history = resolutions_for(diagnosis.signature)
        buckets: dict[str, list] = defaultdict(list)
        for r in history:
            buckets[r.action_taken].append(r)

        out: list[Recommendation] = []
        for action, items in buckets.items():
            wins = sum(1 for i in items if i.succeeded)
            rate = wins / len(items)
            tool_name, arg_builder = PLAYBOOK.get(diagnosis.signature, (None, lambda r: {}))
            out.append(Recommendation(
                action=action,
                rationale=(f"Resolved {wins} of {len(items)} previous occurrences of this "
                           f"signature. Most recent: {items[0].resolved_at:%Y-%m-%d} "
                           f"by {items[0].resolved_by}."),
                success_rate=rate, observations=len(items),
                tool=tool_name, tool_args=arg_builder(target) if tool_name else {},
                evidence=[Evidence("resolution", i.resolution_id, i.summary) for i in items[:2]],
            ))

        out.sort(key=lambda r: (r.success_rate, r.observations), reverse=True)

        if not out:
            out.append(Recommendation(
                action="Escalate to the pipeline owner with the diagnosis attached.",
                rationale="No prior resolution recorded for this signature. The assistant "
                          "will capture whatever fixes it, so the next occurrence is cheaper.",
                success_rate=0.0, observations=0, tool="notify",
                tool_args={"channel": f"#{target.pipeline}", "message": diagnosis.root_cause}))

        METRICS.inc("recommendations.total", len(out))
        bag["recommendations"] = len(out)
        return out[:top_n]
