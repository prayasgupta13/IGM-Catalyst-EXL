"""Error-signature normalization.

Turning a noisy error string into a stable signature is what makes repeat
failures cheap: signature match is a database lookup, not an inference call.
Rules run first (fast, deterministic, auditable); anything unmatched falls
back to a normalized fingerprint so it can still cluster.
"""
from __future__ import annotations

import hashlib
import re

RULES: list[tuple[str, re.Pattern[str]]] = [
    ("schema_drift:type_mismatch:timestamp",
     re.compile(r"(cannot resolve|data type mismatch).{0,80}(timestamp|date).{0,40}(string|varchar)"
                r"|expected timestamp,? got string", re.I)),
    ("schema_drift:missing_column",
     re.compile(r"(column|field)\s+['\"]?\w+['\"]?\s+(does not exist|not found|cannot be resolved)", re.I)),
    ("throttling:rate_limit:429",
     re.compile(r"\b429\b|rate.?limit|request limit exceeded|too many requests|REQUEST_LIMIT_EXCEEDED", re.I)),
    ("resource:oom:executor",
     re.compile(r"(outofmemory|\bOOM\b|exceeding memory limits|executorlostfailure.{0,60}memory)", re.I)),
    ("resource:disk_full",
     re.compile(r"(no space left on device|disk quota exceeded)", re.I)),
    ("db:deadlock",
     re.compile(r"deadlock(ed)? on lock resources|deadlock victim", re.I)),
    ("auth:expired_credential",
     re.compile(r"(401|403).{0,40}(unauthorized|forbidden)|token (has )?expired|invalid client secret", re.I)),
    ("network:timeout",
     re.compile(r"(connection timed out|read timeout|socket timeout|etimedout)", re.I)),
    ("upstream:missing_data",
     re.compile(r"(source (file|table) not found|no files matched|path does not exist)", re.I)),
    ("dependency:upstream_failed",
     re.compile(r"upstream (task|activity) failed|dependency (not met|failed)", re.I)),
]

_NOISE = [
    (re.compile(r"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}\S*", re.I), "<ts>"),
    (re.compile(r"\b0x[0-9a-fA-F]+\b", re.I), "<hex>"),
    (re.compile(r"\b\d+\b", re.I), "<n>"),
    (re.compile(r"\[REDACTED:[A-Z_]+\]", re.I), "<redacted>"),
    (re.compile(r"\s+", re.I), " "),
]


def fingerprint(text: str) -> str:
    norm = text.lower()
    for pattern, repl in _NOISE:
        norm = pattern.sub(repl, norm)
    return "unclassified:" + hashlib.sha1(norm.strip()[:400].encode()).hexdigest()[:10]


def classify(error_text: str, error_code: str | None = None) -> tuple[str, bool]:
    """Return (signature, matched_a_known_rule)."""
    haystack = f"{error_code or ''} {error_text or ''}"
    for signature, pattern in RULES:
        if pattern.search(haystack):
            return signature, True
    if error_code:
        mapped = {
            "SCHEMA_DRIFT": "schema_drift:type_mismatch:timestamp",
            "THROTTLED": "throttling:rate_limit:429",
            "DEADLOCK": "db:deadlock",
        }.get(error_code.upper())
        if mapped:
            return mapped, True
    return fingerprint(error_text or ""), False
