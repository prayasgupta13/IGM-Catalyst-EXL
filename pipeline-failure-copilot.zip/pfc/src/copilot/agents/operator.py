"""Operator — the only component that can change anything.

Every execution passes five gates, in this order, and each gate failure is
audited:

  1. the feature switch (ALLOW_ACTIONS) — graded autonomy, off by default
  2. the tenant manifest permits this action at all
  3. the tool is on the allow-list
  4. the principal is authorised, re-checked NOW against this tenant
  5. an explicit human approval record exists for THIS plan

A dry run is always produced first, so the human approves a concrete plan
rather than an intention.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from typing import Any

from ..config import settings
from ..lineage import FileEmitter, build_event
from ..observability import METRICS, current_trace_id, span
from ..security.audit import AUDIT
from ..security.onboarding import Registry
from ..security.rbac import AccessDenied, Principal, authorize
from ..tools import get_tool

_emitter = FileEmitter()


@dataclass
class ActionPlan:
    tool: str
    args: dict[str, Any]
    tenant: str
    rationale: str = ""
    dry_run_result: dict[str, Any] = field(default_factory=dict)

    @property
    def plan_id(self) -> str:
        body = json.dumps({"tool": self.tool, "args": self.args, "tenant": self.tenant},
                          sort_keys=True)
        return hashlib.sha256(body.encode()).hexdigest()[:16]

    def to_dict(self) -> dict[str, Any]:
        return {"plan_id": self.plan_id, "tool": self.tool, "args": self.args,
                "tenant": self.tenant, "rationale": self.rationale,
                "dry_run": self.dry_run_result,
                "rollback": get_tool(self.tool).rollback}


class Operator:
    def __init__(self, registry: Registry) -> None:
        self.registry = registry

    # ------------------------------------------------------------- propose
    def propose(self, tool_name: str, args: dict[str, Any], tenant: str,
                principal: Principal, rationale: str = "") -> ActionPlan:
        """Build a concrete, reviewable plan. Never mutates anything."""
        tool = get_tool(tool_name)
        with span("operator.propose", tool=tool_name, tenant=tenant) as bag:
            result = tool.handler(**args, dry_run=True)
            plan = ActionPlan(tool_name, args, tenant, rationale, result)
            bag["plan_id"] = plan.plan_id
        AUDIT.record(principal.user_id, f"action.propose:{tool_name}", tenant, "allowed",
                     trace_id=current_trace_id(), plan_id=plan.plan_id, args=args)
        return plan

    # ------------------------------------------------------------- execute
    def execute(self, plan: ActionPlan, principal: Principal,
                approval_token: str | None) -> dict[str, Any]:
        tool = get_tool(plan.tool)
        audit = lambda outcome, **d: AUDIT.record(  # noqa: E731
            principal.user_id, f"action.execute:{plan.tool}", plan.tenant, outcome,
            trace_id=current_trace_id(), plan_id=plan.plan_id, **d)

        # gate 1 — graded autonomy
        if not settings.allow_actions:
            audit("denied", gate="feature_switch")
            raise PermissionError("action execution is disabled (ALLOW_ACTIONS=false)")

        # gate 2 — the application owner agreed to this action class
        if not self.registry.action_allowed(plan.tenant, plan.tool):
            audit("denied", gate="manifest")
            raise PermissionError(
                f"tool {plan.tool!r} is not in the onboarding manifest for {plan.tenant!r}")
        self.registry.assert_active(plan.tenant, principal.user_id)

        # gate 3 — approval must bind to THIS plan, not to the session
        if approval_token != plan.plan_id:
            audit("denied", gate="approval")
            raise PermissionError("approval token does not match the proposed plan")

        # gate 4 — authorisation re-evaluated at execution time
        decision = authorize(principal, tool.scope, plan.tenant, approved=True)
        if not decision.allowed:
            audit("denied", gate="rbac", reason=decision.reason)
            raise AccessDenied(decision.reason)

        # gate 5 — execute, then emit lineage so the write is itself observable
        with span("operator.execute", tool=plan.tool, tenant=plan.tenant) as bag:
            try:
                result = tool.handler(**plan.args, dry_run=False)
                bag["executed"] = True
            except Exception as exc:
                audit("failed", error=str(exc))
                METRICS.inc("actions.total", 1, outcome="failed")
                raise

        _emitter.emit(build_event(
            "COMPLETE", job_name=f"copilot.{plan.tool}",
            inputs=[plan.args.get("pipeline", plan.tenant)],
            outputs=[plan.args.get("pipeline", plan.tenant)],
            actor=principal.user_id, plan_id=plan.plan_id))

        audit("executed", result=result, rollback=tool.rollback)
        METRICS.inc("actions.total", 1, outcome="executed")
        return result
