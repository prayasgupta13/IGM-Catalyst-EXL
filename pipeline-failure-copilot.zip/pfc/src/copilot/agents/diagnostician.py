"""Diagnostician — signature first, generation second, abstention always available.

Order matters and is the accuracy argument: a deterministic signature match
over history is cheaper and more reliable than asking a model to guess. The
model is used to *phrase* a conclusion that retrieval already supports.
"""
from __future__ import annotations

from ..config import settings
from ..lineage import LineageGraph
from ..llm import get_client
from ..observability import METRICS, span
from ..schema import Diagnosis, Evidence, FailureRecord
from ..store import query_failures, resolutions_for
from .signatures import classify

SYSTEM = (
    "You are a data platform reliability assistant. You may ONLY restate facts "
    "given to you as evidence. If the evidence does not support a cause, say so. "
    "Never speculate, never invent a column, table, run id or metric."
)


def diagnose(target: FailureRecord, all_records: list[FailureRecord],
             graph: LineageGraph | None = None) -> Diagnosis:
    with span("diagnostician.diagnose", run_id=target.run_id,
              pipeline=target.pipeline) as bag:
        signature, known = classify(target.error_text, target.error_code)
        target.signature = signature

        evidence: list[Evidence] = [
            Evidence("run", target.key, f"{target.pipeline}.{target.activity} failed "
                                        f"at {target.started_at:%Y-%m-%d %H:%M} UTC"),
        ]
        if target.raw_ref:
            evidence.append(Evidence("log_line", target.raw_ref,
                                     (target.error_text or "")[:180]))

        # history of the same signature
        priors = [r for r in query_failures(tenant=target.tenant, signature=signature, limit=25)
                  if r.key != target.key]
        for p in priors[:3]:
            evidence.append(Evidence("run", p.key,
                                     f"same signature on {p.started_at:%Y-%m-%d}"))

        # upstream failure in the same window beats the local error
        upstream_cause = None
        if graph:
            roots = graph.root_candidates(target, all_records)
            if roots:
                upstream_cause = roots[0]
                evidence.append(Evidence(
                    "lineage", upstream_cause.key,
                    f"upstream {upstream_cause.pipeline}.{upstream_cause.activity} "
                    f"failed at {upstream_cause.started_at:%H:%M} UTC, before this activity"))

        resolutions = resolutions_for(signature)
        for r in resolutions[:2]:
            evidence.append(Evidence("resolution", r.resolution_id, r.summary))

        confidence = _score(known, len(priors), len(resolutions), bool(upstream_cause))

        if confidence < settings.confidence_threshold:
            METRICS.inc("diagnosis.total", 1, outcome="abstained")
            bag["outcome"] = "abstained"
            return Diagnosis(
                root_cause="Not enough evidence to state a root cause.",
                signature=signature, confidence=confidence, evidence=evidence,
                abstained=True,
                reason=("No known signature and no comparable history. Escalating to a human "
                        "is cheaper than a wrong root cause."))

        facts = [f"- {e.detail or e.ref}" for e in evidence if e.detail]
        if upstream_cause:
            facts.insert(0, f"- The true origin is upstream: {upstream_cause.pipeline}."
                            f"{upstream_cause.activity} failed first.")
        prompt = ("Summarise the root cause in two sentences using ONLY these facts:\n"
                  + "\n".join(facts))
        text = get_client().complete(SYSTEM, prompt, max_tokens=300).text

        METRICS.inc("diagnosis.total", 1, outcome="matched" if known else "clustered")
        bag["outcome"] = "diagnosed"
        bag["signature"] = signature
        bag["confidence"] = round(confidence, 3)
        return Diagnosis(root_cause=text, signature=signature, confidence=confidence,
                         evidence=evidence[: settings.max_evidence_items])


def _score(known_signature: bool, priors: int, resolutions: int, upstream: bool) -> float:
    """Transparent, auditable confidence. No hidden model score."""
    score = 0.30 if known_signature else 0.10
    score += min(priors, 3) * 0.12          # up to +0.36 for repeat history
    score += min(resolutions, 2) * 0.14     # up to +0.28 for known fixes
    score += 0.08 if upstream else 0.0      # lineage corroboration
    return round(min(score, 0.97), 3)
