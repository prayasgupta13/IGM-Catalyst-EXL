"""Orchestrator — the planning loop that makes this agentic rather than a chatbot.

  plan -> retrieve -> diagnose -> (re-plan on thin evidence) -> recommend -> propose

The re-plan step is the part a single prompt cannot do: when the first
retrieval yields no comparable history, the orchestrator widens the search
across the tenant before concluding, and only then abstains.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..lineage import LineageGraph
from ..observability import METRICS, request_context, span
from ..schema import Diagnosis, FailureRecord, Recommendation
from ..security.audit import AUDIT
from ..security.onboarding import Registry
from ..security.rbac import Principal, Scope, require
from ..store import query_failures
from .diagnostician import diagnose
from .operator import ActionPlan, Operator
from .recommender import recommend
from .retriever import retrieve


@dataclass
class Answer:
    question: str
    tenant: str
    trace_id: str
    target: FailureRecord | None = None
    diagnosis: Diagnosis | None = None
    recommendations: list[Recommendation] = field(default_factory=list)
    plan: ActionPlan | None = None
    blast_radius: list[dict[str, Any]] = field(default_factory=list)
    steps: list[str] = field(default_factory=list)
    message: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "question": self.question,
            "tenant": self.tenant,
            "trace_id": self.trace_id,
            "message": self.message,
            "target": self.target.to_dict() if self.target else None,
            "diagnosis": self.diagnosis.to_dict() if self.diagnosis else None,
            "recommendations": [r.to_dict() for r in self.recommendations],
            "proposed_action": self.plan.to_dict() if self.plan else None,
            "downstream_impact": self.blast_radius,
            "reasoning_steps": self.steps,
        }


class Copilot:
    def __init__(self, registry: Registry) -> None:
        self.registry = registry
        self.operator = Operator(registry)

    def ask(self, question: str, principal: Principal, tenant: str) -> Answer:
        with request_context(principal.user_id) as trace_id:
            answer = Answer(question=question, tenant=tenant, trace_id=trace_id)
            with span("copilot.ask", tenant=tenant, actor=principal.user_id):
                # -- gate: the tenant must be onboarded and active -------------
                self.registry.assert_active(tenant, principal.user_id)
                require(principal, Scope.READ_METADATA, tenant)
                AUDIT.record(principal.user_id, "query.ask", tenant, "allowed",
                             trace_id=trace_id, question=question[:200])

                # -- step 1: retrieve ------------------------------------------
                records, _q = retrieve(question, principal, tenant)
                answer.steps.append(f"retrieved {len(records)} candidate failures")
                if not records:
                    answer.message = "No failed runs matched that question for this application."
                    return answer

                target = records[0]
                answer.target = target

                # -- step 2: lineage context -----------------------------------
                corpus = query_failures(tenant=tenant, limit=500)
                graph = LineageGraph.from_records(corpus)
                answer.blast_radius = [
                    {"asset": n, "hops": d}
                    for n, d in graph.blast_radius(target.pipeline, target.activity)
                ]
                answer.steps.append(f"lineage: {len(answer.blast_radius)} downstream assets at risk")

                # -- step 3: diagnose ------------------------------------------
                diagnosis = diagnose(target, corpus, graph)

                # -- step 4: RE-PLAN when the evidence is thin ------------------
                if diagnosis.abstained:
                    answer.steps.append("evidence thin — widening search across the tenant")
                    wider = query_failures(tenant=tenant, limit=500)
                    retry = diagnose(target, wider, graph)
                    if not retry.abstained:
                        diagnosis = retry
                        answer.steps.append("re-plan succeeded on the widened corpus")
                    else:
                        answer.steps.append("re-plan did not help — abstaining and escalating")
                        METRICS.inc("copilot.escalations", 1)
                answer.diagnosis = diagnosis

                # -- step 5: recommend -----------------------------------------
                answer.recommendations = recommend(diagnosis, target)
                answer.steps.append(f"ranked {len(answer.recommendations)} corrective actions")

                # -- step 6: propose (never execute) ---------------------------
                top = answer.recommendations[0] if answer.recommendations else None
                if top and top.tool and self.registry.action_allowed(tenant, top.tool):
                    answer.plan = self.operator.propose(
                        top.tool, top.tool_args, tenant, principal, rationale=top.rationale)
                    answer.steps.append(f"proposed {top.tool} — awaiting human approval")

                answer.message = (diagnosis.root_cause if diagnosis else "").strip()
                return answer

    def approve(self, plan: ActionPlan, principal: Principal, token: str) -> dict[str, Any]:
        with request_context(principal.user_id):
            return self.operator.execute(plan, principal, token)
