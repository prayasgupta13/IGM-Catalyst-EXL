"""Retriever — turns a natural-language question into a scoped query.

Two deliberate properties:
  * it never returns a raw log file, only the failing window
  * it never crosses a tenant boundary, and the tenant must be ACTIVE
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from ..observability import METRICS, span
from ..schema import FailureRecord
from ..security.rbac import Principal, Scope, require
from ..store import query_failures, search_failures

_RUN_ID = re.compile(r"\b(?:run|run[_ ]?id)\s*#?\s*([A-Za-z0-9._-]{2,})\b", re.I)
_STOP = {"why", "did", "the", "fail", "failed", "last", "night", "what", "how",
         "can", "we", "it", "and", "for", "job", "a", "is", "was", "on", "in",
         "recover", "pipeline", "run", "show", "me", "of", "to"}


@dataclass
class Query:
    text: str
    tenant: str
    run_id: str | None = None
    keywords: tuple[str, ...] = ()


def parse(question: str, tenant: str) -> Query:
    run_id = m.group(1) if (m := _RUN_ID.search(question)) else None
    words = [w for w in re.findall(r"[a-z_0-9]{3,}", question.lower()) if w not in _STOP]
    return Query(text=question, tenant=tenant, run_id=run_id, keywords=tuple(words[:6]))


def retrieve(question: str, principal: Principal, tenant: str,
             limit: int = 10) -> tuple[list[FailureRecord], Query]:
    require(principal, Scope.READ_METADATA, tenant)
    q = parse(question, tenant)

    with span("retriever.retrieve", tenant=tenant, actor=principal.user_id) as bag:
        records: list[FailureRecord] = []
        if q.run_id:
            records = query_failures(tenant=tenant, run_id=q.run_id, limit=limit)
        if not records:
            seen: set[str] = set()
            for kw in q.keywords:
                for r in search_failures(kw, tenant=tenant, limit=limit):
                    if r.key not in seen:
                        seen.add(r.key)
                        records.append(r)
        if not records:
            records = query_failures(tenant=tenant, limit=limit)

        # scope the log text to the failing window; never a whole file
        may_read_logs = principal.has(Scope.READ_LOGS)
        for r in records:
            if may_read_logs:
                r.error_text = window(r.error_text)
            else:
                # metadata-only principals get the classification, never the text
                r.error_text = "[withheld: principal lacks read:logs]"
                r.raw_ref = None

        bag["records"] = len(records)
        bag["by_run_id"] = bool(q.run_id)
        bag["log_text_withheld"] = not may_read_logs
    METRICS.inc("retriever.queries", 1, matched=str(bool(records)))
    return records[:limit], q


def window(text: str, lines: int = 40) -> str:
    """Keep the error window, drop the rest. Cost and hallucination control."""
    parts = [l for l in (text or "").splitlines() if l.strip()]
    return "\n".join(parts[:lines])
