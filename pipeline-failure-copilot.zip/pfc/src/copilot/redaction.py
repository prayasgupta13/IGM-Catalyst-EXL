"""Redaction at ingest.

This runs BEFORE anything is persisted and before any text reaches the model.
It is deliberately conservative: over-redacting costs a little context,
under-redacting is a production data incident.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

# Ordered: more specific patterns first.
PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("CONN_STRING", re.compile(r"(?i)\b(?:Server|Data Source|Host)\s*=\s*[^;\s]+;[^\"'\s]*", re.I)),
    ("JWT", re.compile(r"\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b")),
    ("AWS_KEY", re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b")),
    ("BEARER", re.compile(r"(?i)\bBearer\s+[A-Za-z0-9._\-]{12,}")),
    # NB: the negative lookahead makes redaction IDEMPOTENT — re-running it over
    # already-redacted text must not re-fire, or the model-boundary guard in
    # llm/client.py raises false positives on stored records.
    ("SECRET_KV", re.compile(
        r"(?i)\b(password|passwd|pwd|secret|token|api[_-]?key|access[_-]?key|client[_-]?secret|sas)\b"
        r"\s*[=:]\s*[\"']?(?!\[REDACTED:)([^\s\"',;]+)")),
    ("EMAIL", re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]{2,}\b")),
    ("PAN", re.compile(r"\b[A-Z]{5}[0-9]{4}[A-Z]\b")),
    ("AADHAAR", re.compile(r"\b\d{4}\s?\d{4}\s?\d{4}\b")),
    ("CARD", re.compile(r"\b(?:\d[ -]?){13,19}\b")),
    ("IPV4", re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")),
    ("SSN", re.compile(r"\b\d{3}-\d{2}-\d{4}\b")),
]


@dataclass
class RedactionResult:
    text: str
    hits: dict[str, int]

    @property
    def applied(self) -> bool:
        return bool(self.hits)


def redact(text: str | None) -> RedactionResult:
    """Return text with sensitive substrings replaced by typed placeholders."""
    if not text:
        return RedactionResult("", {})
    hits: dict[str, int] = {}
    out = text
    for label, pattern in PATTERNS:
        if label == "SECRET_KV":
            def _kv(m: re.Match[str]) -> str:
                return f"{m.group(1)}=[REDACTED:SECRET]"
            out, n = pattern.subn(_kv, out)
        else:
            out, n = pattern.subn(f"[REDACTED:{label}]", out)
        if n:
            hits[label] = hits.get(label, 0) + n
    return RedactionResult(out, hits)


def assert_clean(text: str) -> None:
    """Defence in depth: called on the prompt just before the LLM boundary."""
    result = redact(text)
    if result.applied:
        raise ValueError(
            f"unredacted sensitive data reached the model boundary: {sorted(result.hits)}"
        )
