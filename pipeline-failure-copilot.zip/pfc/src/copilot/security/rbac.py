"""Access control.

Three properties the evaluators asked for evidence of:

1. No standing privilege. The agent has no identity of its own. Every
   privileged call carries the *caller's* principal, and is re-evaluated at
   execution time against the target tenant — not at session start.
2. Deny by default. An action not explicitly granted is denied, and the
   denial is auditable.
3. Separation of read and write. Read scopes never imply write scopes;
   escalation requires an explicit approval record.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Iterable


class Scope(str, Enum):
    READ_METADATA = "read:metadata"
    READ_LOGS = "read:logs"
    READ_LINEAGE = "read:lineage"
    ACTION_RERUN = "action:rerun"
    ACTION_BACKFILL = "action:backfill"
    ACTION_SCALE = "action:scale"
    ADMIN_ONBOARD = "admin:onboard"


ROLES: dict[str, set[Scope]] = {
    "viewer": {Scope.READ_METADATA, Scope.READ_LINEAGE},
    "support_l1": {Scope.READ_METADATA, Scope.READ_LOGS, Scope.READ_LINEAGE},
    "support_l2": {Scope.READ_METADATA, Scope.READ_LOGS, Scope.READ_LINEAGE,
                   Scope.ACTION_RERUN},
    "data_engineer": {Scope.READ_METADATA, Scope.READ_LOGS, Scope.READ_LINEAGE,
                      Scope.ACTION_RERUN, Scope.ACTION_BACKFILL, Scope.ACTION_SCALE},
    "platform_admin": set(Scope),
}


class AccessDenied(PermissionError):
    """Raised at execution time, never swallowed, always audited."""


@dataclass(frozen=True)
class Principal:
    """The human. The agent never has one of these of its own."""

    user_id: str
    roles: tuple[str, ...] = ()
    tenants: tuple[str, ...] = ()          # applications the user may touch
    mfa: bool = False
    groups: tuple[str, ...] = field(default_factory=tuple)

    @property
    def scopes(self) -> set[Scope]:
        out: set[Scope] = set()
        for role in self.roles:
            out |= ROLES.get(role, set())
        return out

    def has(self, scope: Scope) -> bool:
        return scope in self.scopes


#: write scopes additionally require MFA and an approval record
WRITE_SCOPES = {Scope.ACTION_RERUN, Scope.ACTION_BACKFILL, Scope.ACTION_SCALE}


@dataclass
class Decision:
    allowed: bool
    reason: str
    scope: Scope
    principal: str
    tenant: str

    def raise_for_status(self) -> None:
        if not self.allowed:
            raise AccessDenied(f"{self.principal} denied {self.scope.value} on {self.tenant}: {self.reason}")


def authorize(principal: Principal, scope: Scope, tenant: str,
              approved: bool = False) -> Decision:
    """Evaluated at execution time, on every call. Deny by default."""
    d = lambda ok, why: Decision(ok, why, scope, principal.user_id, tenant)  # noqa: E731

    if tenant not in principal.tenants and "*" not in principal.tenants:
        return d(False, "principal is not entitled to this tenant")
    if not principal.has(scope):
        return d(False, "role set does not grant this scope")
    if scope in WRITE_SCOPES:
        if not principal.mfa:
            return d(False, "write scopes require an MFA-backed session")
        if not approved:
            return d(False, "write scopes require an explicit human approval record")
    return d(True, "granted")


def require(principal: Principal, scope: Scope, tenant: str, approved: bool = False) -> Decision:
    decision = authorize(principal, scope, tenant, approved)
    decision.raise_for_status()
    return decision


def scopes_for(roles: Iterable[str]) -> set[Scope]:
    out: set[Scope] = set()
    for r in roles:
        out |= ROLES.get(r, set())
    return out
