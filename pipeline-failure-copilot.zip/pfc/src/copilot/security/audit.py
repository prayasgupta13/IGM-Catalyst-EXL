"""Tamper-evident audit trail.

Each entry stores the hash of the previous entry, so any modification or
deletion breaks the chain and `verify()` reports the first bad index. This
is what turns "we log actions" into evidence an auditor can check.
"""
from __future__ import annotations

import hashlib
import json
import os
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ..config import settings

GENESIS = "0" * 64


@dataclass
class AuditEntry:
    ts: str
    actor: str
    action: str
    tenant: str
    outcome: str                       # allowed | denied | executed | failed
    trace_id: str = "-"
    detail: dict[str, Any] = field(default_factory=dict)
    prev_hash: str = GENESIS
    entry_hash: str = ""

    def compute_hash(self) -> str:
        body = json.dumps(
            {k: v for k, v in asdict(self).items() if k != "entry_hash"},
            sort_keys=True, default=str,
        )
        return hashlib.sha256(body.encode()).hexdigest()


class AuditLog:
    def __init__(self, path: str | None = None) -> None:
        self.path = Path(path or settings.audit_path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.touch(exist_ok=True)

    def _last_hash(self) -> str:
        last = GENESIS
        with self.path.open() as fh:
            for line in fh:
                if line.strip():
                    last = json.loads(line)["entry_hash"]
        return last

    def record(self, actor: str, action: str, tenant: str, outcome: str,
               trace_id: str = "-", **detail: Any) -> AuditEntry:
        entry = AuditEntry(
            ts=datetime.now(timezone.utc).isoformat(),
            actor=actor, action=action, tenant=tenant, outcome=outcome,
            trace_id=trace_id, detail=detail, prev_hash=self._last_hash(),
        )
        entry.entry_hash = entry.compute_hash()
        with self.path.open("a") as fh:
            fh.write(json.dumps(asdict(entry), default=str) + "\n")
            fh.flush()
            os.fsync(fh.fileno())
        return entry

    def entries(self) -> list[dict[str, Any]]:
        with self.path.open() as fh:
            return [json.loads(l) for l in fh if l.strip()]

    def verify(self) -> tuple[bool, str]:
        prev = GENESIS
        for i, raw in enumerate(self.entries()):
            entry = AuditEntry(**raw)
            if entry.prev_hash != prev:
                return False, f"chain broken at entry {i}: prev_hash mismatch"
            recomputed = entry.compute_hash()
            if recomputed != entry.entry_hash:
                return False, f"entry {i} was modified after write"
            prev = entry.entry_hash
        return True, f"verified {len(self.entries())} entries"


AUDIT = AuditLog()
