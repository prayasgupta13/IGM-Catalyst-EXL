"""Application onboarding.

No pipeline is visible to the assistant until its owning application has an
approved onboarding manifest. This is the control the evaluators asked
about: it is where security and org compliance are enforced, and it is
enforced in code, not in a document.

Lifecycle:
    DRAFT -> VALIDATED -> APPROVED -> ACTIVE -> (SUSPENDED | RETIRED)

Gates:
    * every gate in REQUIRED_GATES must pass before APPROVED
    * approval needs two distinct approvers, one of them security
    * an ACTIVE tenant is re-attested every `review_days`; lapsed
      attestation auto-suspends the tenant at query time
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from pathlib import Path
from typing import Any

import yaml

from .audit import AUDIT


class State(str, Enum):
    DRAFT = "draft"
    VALIDATED = "validated"
    APPROVED = "approved"
    ACTIVE = "active"
    SUSPENDED = "suspended"
    RETIRED = "retired"


REQUIRED_GATES = {
    "data_classification_declared": "Highest data class the pipelines touch is declared.",
    "pii_fields_declared": "PII/sensitive columns are enumerated so redaction rules cover them.",
    "read_only_credential": "Credential supplied is read-only and scoped to metadata + logs.",
    "credential_in_vault": "Credential is stored in the org secret manager, not in the manifest.",
    "network_path_approved": "Egress path from the assistant to the platform is approved.",
    "log_retention_agreed": "Retention for normalized failure records is agreed with the owner.",
    "dpia_or_waiver": "DPIA completed, or a documented waiver for non-personal data.",
    "owner_ack_actions": "Owner has acknowledged which action tools may ever be enabled.",
    "rollback_documented": "Rollback procedure documented for each enabled action.",
    "incident_contact": "On-call contact recorded for the application.",
}

VALID_CLASSES = {"public", "internal", "confidential", "restricted"}


@dataclass
class Manifest:
    tenant_id: str
    application: str
    owner: str
    security_contact: str
    data_classification: str
    platforms: list[dict[str, Any]] = field(default_factory=list)
    pii_fields: list[str] = field(default_factory=list)
    enabled_actions: list[str] = field(default_factory=list)
    review_days: int = 90
    gates: dict[str, bool] = field(default_factory=dict)
    approvals: list[dict[str, str]] = field(default_factory=list)
    state: str = State.DRAFT.value
    attested_at: str | None = None

    # ---------------------------------------------------------------- load
    @classmethod
    def load(cls, path: str | Path) -> "Manifest":
        raw = yaml.safe_load(Path(path).read_text())
        allowed = set(cls.__dataclass_fields__)
        return cls(**{k: v for k, v in raw.items() if k in allowed})

    def dump(self, path: str | Path) -> None:
        Path(path).write_text(yaml.safe_dump(asdict(self), sort_keys=False))

    # ------------------------------------------------------------ validate
    def validate(self) -> list[str]:
        """Structural + policy validation. Returns a list of problems."""
        problems: list[str] = []
        if not self.tenant_id.isidentifier():
            problems.append("tenant_id must be a safe identifier (letters, digits, underscore)")
        if self.data_classification not in VALID_CLASSES:
            problems.append(f"data_classification must be one of {sorted(VALID_CLASSES)}")
        if not self.platforms:
            problems.append("at least one platform must be declared")
        for p in self.platforms:
            if "type" not in p or "credential_ref" not in p:
                problems.append(f"platform entry {p} needs 'type' and 'credential_ref'")
            ref = str(p.get("credential_ref", ""))
            if not ref.startswith(("vault://", "akv://", "env://")):
                problems.append(f"credential_ref {ref!r} must be a secret-manager reference, not a literal")
        if self.data_classification == "restricted" and self.enabled_actions:
            problems.append("restricted data may not have write actions enabled")
        for gate in REQUIRED_GATES:
            if gate not in self.gates:
                problems.append(f"missing compliance gate: {gate}")
        if "@" not in self.security_contact:
            problems.append("security_contact must be an email address")
        return problems

    # -------------------------------------------------------------- gating
    def failed_gates(self) -> list[str]:
        return [g for g in REQUIRED_GATES if not self.gates.get(g, False)]

    def approver_check(self) -> list[str]:
        problems = []
        roles = {a.get("role") for a in self.approvals}
        approvers = {a.get("approver") for a in self.approvals}
        if len(approvers) < 2:
            problems.append("two distinct approvers are required")
        if "security" not in roles:
            problems.append("one approval must come from the security role")
        if "owner" not in roles:
            problems.append("one approval must come from the application owner")
        return problems

    def attestation_due(self) -> bool:
        if not self.attested_at:
            return True
        last = datetime.fromisoformat(self.attested_at.replace("Z", "+00:00"))
        return datetime.now(timezone.utc) - last > timedelta(days=self.review_days)

    # ----------------------------------------------------------- promotion
    def promote(self, actor: str) -> tuple[bool, str]:
        problems = self.validate()
        if problems:
            AUDIT.record(actor, "onboarding.validate", self.tenant_id, "denied",
                         problems=problems)
            return False, "; ".join(problems)

        if self.state == State.DRAFT.value:
            self.state = State.VALIDATED.value
            AUDIT.record(actor, "onboarding.promote", self.tenant_id, "allowed",
                         to=self.state)
            return True, "manifest validated"

        if self.state == State.VALIDATED.value:
            blockers = self.failed_gates() + self.approver_check()
            if blockers:
                AUDIT.record(actor, "onboarding.promote", self.tenant_id, "denied",
                             blockers=blockers)
                return False, "; ".join(blockers)
            self.state = State.APPROVED.value
            AUDIT.record(actor, "onboarding.promote", self.tenant_id, "allowed",
                         to=self.state, approvals=self.approvals)
            return True, "approved by security and owner"

        if self.state == State.APPROVED.value:
            self.state = State.ACTIVE.value
            self.attested_at = datetime.now(timezone.utc).isoformat()
            AUDIT.record(actor, "onboarding.activate", self.tenant_id, "allowed")
            return True, "tenant is active; ingest may begin"

        return False, f"no promotion path from state {self.state!r}"


class Registry:
    """The gate every query passes through."""

    def __init__(self, directory: str | Path) -> None:
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)

    def all(self) -> list[Manifest]:
        out = []
        for f in sorted(self.directory.glob("*.y*ml")):
            try:
                out.append(Manifest.load(f))
            except Exception:  # a malformed manifest must not expose data
                continue
        return out

    def get(self, tenant_id: str) -> Manifest | None:
        for m in self.all():
            if m.tenant_id == tenant_id:
                return m
        return None

    def assert_active(self, tenant_id: str, actor: str = "-") -> Manifest:
        m = self.get(tenant_id)
        if m is None:
            AUDIT.record(actor, "tenant.access", tenant_id, "denied", reason="not onboarded")
            raise PermissionError(f"tenant {tenant_id!r} is not onboarded")
        if m.state != State.ACTIVE.value:
            AUDIT.record(actor, "tenant.access", tenant_id, "denied", reason=f"state={m.state}")
            raise PermissionError(f"tenant {tenant_id!r} is {m.state}, not active")
        if m.attestation_due():
            m.state = State.SUSPENDED.value
            AUDIT.record(actor, "tenant.access", tenant_id, "denied",
                         reason="attestation lapsed; auto-suspended")
            raise PermissionError(f"tenant {tenant_id!r} attestation lapsed; re-attest to resume")
        return m

    def action_allowed(self, tenant_id: str, action: str) -> bool:
        m = self.get(tenant_id)
        return bool(m and action in m.enabled_actions)
