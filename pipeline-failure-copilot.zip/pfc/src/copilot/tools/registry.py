"""Allow-listed tool registry.

The Operator can call these and nothing else. There is no generic "run this
command" tool, no eval, no shell. Each tool declares the scope it needs, so
authorisation is data, not scattered if-statements.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from ..observability import log_event
from ..security.rbac import Scope


@dataclass
class Tool:
    name: str
    description: str
    scope: Scope
    handler: Callable[..., dict[str, Any]]
    dry_run_handler: Callable[..., dict[str, Any]] | None = None
    reversible: bool = True
    rollback: str = ""


REGISTRY: dict[str, Tool] = {}


def tool(name: str, description: str, scope: Scope, reversible: bool = True,
         rollback: str = "") -> Callable:
    def deco(fn: Callable[..., dict[str, Any]]) -> Callable[..., dict[str, Any]]:
        REGISTRY[name] = Tool(name, description, scope, fn,
                              reversible=reversible, rollback=rollback)
        return fn
    return deco


# --------------------------------------------------------------------------
# The only four actions that exist. Each is a stub here; in production each
# calls the platform SDK using the CALLER's short-lived, on-behalf-of token.
# --------------------------------------------------------------------------
@tool("rerun", "Re-run a single failed activity.", Scope.ACTION_RERUN,
      rollback="Kill the triggered run; no data is mutated until it completes.")
def rerun(pipeline: str, activity: str, run_id: str, dry_run: bool = True,
          **_: Any) -> dict[str, Any]:
    plan = {"tool": "rerun", "pipeline": pipeline, "activity": activity, "run_id": run_id}
    if dry_run:
        return {**plan, "dry_run": True, "would_affect": [f"{pipeline}.{activity}"]}
    log_event("tool.rerun.execute", **plan)
    return {**plan, "executed": True, "new_run_id": f"{run_id}-r1"}


@tool("backfill", "Backfill a bounded time window for one pipeline.", Scope.ACTION_BACKFILL,
      rollback="Re-run the original window from the retained snapshot.")
def backfill(pipeline: str, window_start: str, window_end: str,
             dry_run: bool = True, **_: Any) -> dict[str, Any]:
    plan = {"tool": "backfill", "pipeline": pipeline,
            "window_start": window_start, "window_end": window_end}
    if dry_run:
        return {**plan, "dry_run": True, "estimated_partitions": 2}
    log_event("tool.backfill.execute", **plan)
    return {**plan, "executed": True, "rows_recovered": 2_100_000}


@tool("scale_cluster", "Change executor memory or worker count for a job.", Scope.ACTION_SCALE,
      rollback="Restore the previous cluster config, retained in the audit entry.")
def scale_cluster(job: str, executor_memory: str | None = None,
                  workers: int | None = None, dry_run: bool = True, **_: Any) -> dict[str, Any]:
    plan = {"tool": "scale_cluster", "job": job,
            "executor_memory": executor_memory, "workers": workers}
    if dry_run:
        return {**plan, "dry_run": True}
    log_event("tool.scale.execute", **plan)
    return {**plan, "executed": True}


@tool("notify", "Post the diagnosis to the owning team's channel.", Scope.READ_METADATA)
def notify(channel: str, message: str, dry_run: bool = True, **_: Any) -> dict[str, Any]:
    plan = {"tool": "notify", "channel": channel, "message": message[:280]}
    return {**plan, "dry_run": True} if dry_run else {**plan, "executed": True}


def get_tool(name: str) -> Tool:
    if name not in REGISTRY:
        raise KeyError(f"tool {name!r} is not on the allow-list; have {sorted(REGISTRY)}")
    return REGISTRY[name]
