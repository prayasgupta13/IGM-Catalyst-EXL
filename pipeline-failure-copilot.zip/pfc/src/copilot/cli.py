"""Command line interface. Every demo the evaluators asked for is a subcommand."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .agents import Copilot
from .config import ROOT, settings
from .eval import run_replay, write_report
from .ingest import bootstrap
from .observability import METRICS
from .security.audit import AUDIT
from .security.onboarding import Manifest, Registry, State
from .security.rbac import Principal

MANIFEST_DIR = ROOT / "onboarding" / "manifests"

DEMO_USERS = {
    "viewer":  Principal("v.viewer", roles=("viewer",), tenants=("billing",)),
    "l1":      Principal("l1.support", roles=("support_l1",), tenants=("billing",)),
    "l2":      Principal("l2.support", roles=("support_l2",), tenants=("billing",), mfa=True),
    "engineer": Principal("p.gupta", roles=("data_engineer",), tenants=("billing",), mfa=True),
    "admin":   Principal("admin", roles=("platform_admin",), tenants=("*",), mfa=True),
}


def _registry() -> Registry:
    return Registry(MANIFEST_DIR)


def cmd_onboard(args) -> int:
    path = Path(args.manifest)
    m = Manifest.load(path)
    print(f"tenant={m.tenant_id} application={m.application} state={m.state}")
    while m.state != State.ACTIVE.value:
        ok, msg = m.promote(args.actor)
        status = "PASS" if ok else "BLOCKED"
        print(f"  [{status}] {msg}")
        if not ok:
            print("\nOnboarding refused. Fix the manifest and re-run.")
            m.dump(path)
            return 1
        print(f"          -> state={m.state}")
    m.dump(path)
    print("\nTenant is ACTIVE. Ingest may begin.")
    return 0


def cmd_ingest(args) -> int:
    counts = bootstrap(str(ROOT / "seed"), args.tenant, _registry())
    print(json.dumps(counts, indent=2))
    return 0


def cmd_ask(args) -> int:
    principal = DEMO_USERS[args.user]
    copilot = Copilot(_registry())
    answer = copilot.ask(args.question, principal, args.tenant)

    if args.json:
        print(json.dumps(answer.to_dict(), indent=2, default=str))
        return 0

    d = answer.diagnosis
    print("\n" + "=" * 78)
    print(f"Q: {answer.question}")
    print(f"   actor={principal.user_id} tenant={answer.tenant} trace={answer.trace_id}")
    print("=" * 78)
    if not answer.target:
        print(answer.message)
        return 0
    t = answer.target
    print(f"\nFAILED RUN   {t.pipeline}.{t.activity}  run={t.run_id}  "
          f"platform={t.platform}  severity={t.severity.value}")
    if d:
        label = "ABSTAINED" if d.abstained else "ROOT CAUSE"
        print(f"\n{label}  (confidence {d.confidence:.2f}, signature {d.signature})")
        print(f"  {d.root_cause}")
        if d.abstained:
            print(f"  reason: {d.reason}")
        print("\nEVIDENCE")
        for e in d.evidence:
            print(f"  - [{e.kind}] {e.ref}\n      {e.detail}")
    if answer.blast_radius:
        print("\nDOWNSTREAM IMPACT")
        for b in answer.blast_radius:
            print(f"  - {b['asset']}  ({b['hops']} hop{'s' if b['hops'] > 1 else ''} away)")
    if answer.recommendations:
        print("\nRECOMMENDED ACTIONS")
        for i, r in enumerate(answer.recommendations, 1):
            print(f"  {i}. {r.action}")
            print(f"     success {r.success_rate:.0%} over {r.observations} prior case(s)"
                  f"{' · tool: ' + r.tool if r.tool else ''}")
            print(f"     {r.rationale}")
    if answer.plan:
        p = answer.plan.to_dict()
        print(f"\nPROPOSED ACTION  (plan_id {p['plan_id']}) — NOT executed")
        print(f"  tool={p['tool']} args={json.dumps(p['args'])}")
        print(f"  dry run: {json.dumps(p['dry_run'])}")
        print(f"  rollback: {p['rollback']}")
        print(f"\n  approve with:  copilot approve --plan {p['plan_id']} --user engineer")
    print("\nREASONING STEPS")
    for s in answer.steps:
        print(f"  · {s}")
    print()
    return 0


def cmd_approve(args) -> int:
    """Demonstrates the five gates. Re-derives the plan, then executes it."""
    principal = DEMO_USERS[args.user]
    copilot = Copilot(_registry())
    answer = copilot.ask(args.question, principal, args.tenant)
    if not answer.plan:
        print("No action was proposed for that question.")
        return 1
    if answer.plan.plan_id != args.plan:
        print(f"plan id mismatch: proposed {answer.plan.plan_id}, you passed {args.plan}")
        return 1
    try:
        result = copilot.approve(answer.plan, principal, args.plan)
        print("EXECUTED:", json.dumps(result, indent=2))
        return 0
    except PermissionError as exc:
        print(f"REFUSED: {exc}")
        print("(this is the system working — see docs/security-compliance.md)")
        return 1


def cmd_replay(args) -> int:
    result = run_replay(str(ROOT / "seed" / "labels.json"), tenant=args.tenant)
    print("\nREPLAY HARNESS")
    print("-" * 60)
    for d in result.details:
        mark = "abstain" if d["abstained"] else ("ok" if d["correct"] else "WRONG")
        print(f"  {d['run_id']:<10} {mark:<8} conf={d['confidence']:.2f}  {d['predicted']}")
    print("-" * 60)
    print(" ", result.summary())
    print("  report:", write_report(result))
    return 0


def cmd_audit(args) -> int:
    ok, msg = AUDIT.verify()
    print(f"audit chain: {'VALID' if ok else 'BROKEN'} — {msg}")
    if args.tail:
        for e in AUDIT.entries()[-args.tail:]:
            print(f"  {e['ts']}  {e['actor']:<12} {e['action']:<28} {e['outcome']}")
    return 0 if ok else 1


def cmd_metrics(args) -> int:
    print(METRICS.prometheus())
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser("copilot", description="Pipeline Failure Copilot")
    sub = p.add_subparsers(dest="cmd", required=True)

    o = sub.add_parser("onboard", help="validate and promote an application manifest")
    o.add_argument("manifest")
    o.add_argument("--actor", default="admin")
    o.set_defaults(fn=cmd_onboard)

    i = sub.add_parser("ingest", help="normalize seed data into the failure store")
    i.add_argument("--tenant", default="billing")
    i.set_defaults(fn=cmd_ingest)

    a = sub.add_parser("ask", help="ask a question in natural language")
    a.add_argument("question")
    a.add_argument("--tenant", default="billing")
    a.add_argument("--user", default="engineer", choices=sorted(DEMO_USERS))
    a.add_argument("--json", action="store_true")
    a.set_defaults(fn=cmd_ask)

    ap = sub.add_parser("approve", help="approve and execute a proposed plan")
    ap.add_argument("--plan", required=True)
    ap.add_argument("--question", required=True)
    ap.add_argument("--tenant", default="billing")
    ap.add_argument("--user", default="engineer", choices=sorted(DEMO_USERS))
    ap.set_defaults(fn=cmd_approve)

    r = sub.add_parser("replay", help="score the assistant against labelled history")
    r.add_argument("--tenant", default="billing")
    r.set_defaults(fn=cmd_replay)

    au = sub.add_parser("audit", help="verify the audit chain")
    au.add_argument("--tail", type=int, default=10)
    au.set_defaults(fn=cmd_audit)

    m = sub.add_parser("metrics", help="print Prometheus metrics")
    m.set_defaults(fn=cmd_metrics)
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return args.fn(args)


if __name__ == "__main__":
    sys.exit(main())
