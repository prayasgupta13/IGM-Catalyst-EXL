"""Ingest: adapters -> redaction -> signature -> store.

This is the only write path into the failure store, so the guarantees
(redaction applied, tenant onboarded, signature assigned) hold everywhere.
"""
from __future__ import annotations

import json
from pathlib import Path

from .adapters import get_adapter
from .agents.signatures import classify
from .observability import METRICS, log_event, span
from .schema import Resolution
from .security.onboarding import Registry
from .store import init, upsert_failures, upsert_resolutions


def ingest_platform(platform: str, fixture: str, tenant: str,
                    registry: Registry, actor: str = "ingest") -> int:
    registry.assert_active(tenant, actor)              # no manifest, no ingest
    with span("ingest.platform", platform=platform, tenant=tenant) as bag:
        adapter = get_adapter(platform, fixture=fixture)
        records = adapter.normalize(tenant=tenant)
        for r in records:
            r.signature, known = classify(r.error_text, r.error_code)
            METRICS.inc("ingest.records", 1, platform=platform,
                        classified=str(known))
            if r.redaction_applied:
                METRICS.inc("ingest.redacted", 1, platform=platform)
        n = upsert_failures(records)
        bag["records"] = n
    log_event("ingest.complete", platform=platform, tenant=tenant, records=n)
    return n


def ingest_resolutions(path: str) -> int:
    payload = json.loads(Path(path).read_text())
    items = [Resolution(**r) for r in payload]
    return upsert_resolutions(items)


def bootstrap(seed_dir: str, tenant: str, registry: Registry) -> dict[str, int]:
    init()
    runs = str(Path(seed_dir) / "runs.json")
    out = {p: ingest_platform(p, runs, tenant, registry)
           for p in ("airflow", "adf", "databricks")}
    out["resolutions"] = ingest_resolutions(str(Path(seed_dir) / "resolutions.json"))
    return out
