"""Observability: traces, metrics and structured logs.

Every agent step opens a span. Every span carries run_id, tenant, actor and
decision metadata, so an auditor can reconstruct exactly what the assistant
saw and why it answered the way it did. OpenTelemetry is used when
installed; otherwise a no-op shim keeps the code path identical so the
repo runs with zero extra infrastructure.
"""
from __future__ import annotations

import json
import logging
import sys
import time
import uuid
from contextlib import contextmanager
from contextvars import ContextVar
from typing import Any, Iterator

from ..config import settings

_trace_id: ContextVar[str] = ContextVar("trace_id", default="-")
_actor: ContextVar[str] = ContextVar("actor", default="-")


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
            "trace_id": _trace_id.get(),
            "actor": _actor.get(),
        }
        if extra := getattr(record, "extra_fields", None):
            payload.update(extra)
        return json.dumps(payload, default=str)


def get_logger(name: str) -> logging.Logger:
    log = logging.getLogger(name)
    if not log.handlers:
        h = logging.StreamHandler(sys.stderr)
        h.setFormatter(JsonFormatter())
        log.addHandler(h)
        log.setLevel(logging.INFO)
        log.propagate = False
    return log


log = get_logger("copilot")


def log_event(msg: str, **fields: Any) -> None:
    log.info(msg, extra={"extra_fields": fields})


# --------------------------------------------------------------------------
# tracing
# --------------------------------------------------------------------------
try:  # pragma: no cover - depends on optional dependency
    from opentelemetry import trace as _otel_trace
    from opentelemetry.sdk.resources import Resource
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor, ConsoleSpanExporter

    _OTEL = True
except Exception:  # pragma: no cover
    _OTEL = False

_tracer = None


def _init_tracer():  # pragma: no cover
    global _tracer
    if _tracer is not None or not (_OTEL and settings.otel_enabled):
        return _tracer
    provider = TracerProvider(resource=Resource.create({"service.name": settings.service_name}))
    if settings.otel_endpoint:
        from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
        provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter(endpoint=settings.otel_endpoint)))
    else:
        provider.add_span_processor(BatchSpanProcessor(ConsoleSpanExporter()))
    _otel_trace.set_tracer_provider(provider)
    _tracer = _otel_trace.get_tracer(settings.service_name)
    return _tracer


@contextmanager
def span(name: str, **attrs: Any) -> Iterator[dict[str, Any]]:
    """Trace one unit of agent work. Always emits a structured log line even
    when OpenTelemetry is not installed, so evidence is never lost."""
    started = time.perf_counter()
    bag: dict[str, Any] = {}
    tracer = _init_tracer()
    if tracer:  # pragma: no cover
        with tracer.start_as_current_span(name) as s:
            for k, v in attrs.items():
                s.set_attribute(k, str(v))
            try:
                yield bag
            finally:
                for k, v in bag.items():
                    s.set_attribute(f"result.{k}", str(v))
    else:
        try:
            yield bag
        finally:
            pass
    elapsed_ms = round((time.perf_counter() - started) * 1000, 2)
    METRICS.observe(f"{name}.latency_ms", elapsed_ms)
    log_event(f"span.{name}", duration_ms=elapsed_ms, **attrs, **bag)


@contextmanager
def request_context(actor: str, trace_id: str | None = None) -> Iterator[str]:
    tid = trace_id or uuid.uuid4().hex[:16]
    t1, t2 = _trace_id.set(tid), _actor.set(actor)
    try:
        yield tid
    finally:
        _trace_id.reset(t1)
        _actor.reset(t2)


def current_trace_id() -> str:
    return _trace_id.get()


# --------------------------------------------------------------------------
# metrics — in-process, Prometheus text format on /metrics
# --------------------------------------------------------------------------
class Metrics:
    def __init__(self) -> None:
        self.counters: dict[str, float] = {}
        self.observations: dict[str, list[float]] = {}

    def inc(self, name: str, value: float = 1.0, **labels: Any) -> None:
        self.counters[self._key(name, labels)] = self.counters.get(self._key(name, labels), 0) + value

    def observe(self, name: str, value: float, **labels: Any) -> None:
        self.observations.setdefault(self._key(name, labels), []).append(value)

    @staticmethod
    def _key(name: str, labels: dict[str, Any]) -> str:
        if not labels:
            return name
        rendered = ",".join(f'{k}="{v}"' for k, v in sorted(labels.items()))
        return f"{name}{{{rendered}}}"

    def snapshot(self) -> dict[str, Any]:
        out: dict[str, Any] = dict(self.counters)
        for key, values in self.observations.items():
            ordered = sorted(values)
            out[f"{key}.count"] = len(ordered)
            out[f"{key}.avg"] = round(sum(ordered) / len(ordered), 2)
            out[f"{key}.p95"] = round(ordered[min(int(len(ordered) * 0.95), len(ordered) - 1)], 2)
        return out

    def prometheus(self) -> str:
        lines = []
        for key, value in self.snapshot().items():
            metric = key.replace(".", "_").replace("@", "_at_")
            lines.append(f"{metric} {value}")
        return "\n".join(lines) + "\n"


METRICS = Metrics()
