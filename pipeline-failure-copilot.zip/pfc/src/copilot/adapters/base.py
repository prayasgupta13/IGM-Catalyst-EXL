"""Adapter contract. This file is the whole cloud-agnostic argument.

To onboard a new orchestrator you implement `fetch_failures` and map its
fields onto FailureRecord. Nothing downstream changes: not the agents,
not the prompts, not the evaluation harness.
"""
from __future__ import annotations

import abc
from typing import Any, Iterable

from ..redaction import redact
from ..schema import FailureRecord


class OrchestratorAdapter(abc.ABC):
    platform: str = "unknown"
    #: fields the adapter promises to populate; validated on registration
    required = ("run_id", "pipeline", "activity", "status", "started_at")

    @abc.abstractmethod
    def fetch_raw(self, since: str | None = None) -> Iterable[dict[str, Any]]:
        """Return raw payloads from the source system."""

    @abc.abstractmethod
    def map_record(self, raw: dict[str, Any]) -> FailureRecord:
        """Map ONE raw payload onto the canonical record."""

    # -- template method: redaction is not optional and not the mapper's job --
    def normalize(self, since: str | None = None, tenant: str = "default") -> list[FailureRecord]:
        out: list[FailureRecord] = []
        for raw in self.fetch_raw(since):
            record = self.map_record(raw)
            result = redact(record.error_text)
            record.error_text = result.text
            record.redaction_applied = result.applied
            record.platform = self.platform
            record.tenant = tenant
            self._validate(record)
            out.append(record)
        return out

    def _validate(self, record: FailureRecord) -> None:
        for f in self.required:
            if getattr(record, f, None) in (None, ""):
                raise ValueError(
                    f"{self.platform} adapter produced a record missing required field {f!r}; "
                    "failing loudly rather than inferring it"
                )


REGISTRY: dict[str, type[OrchestratorAdapter]] = {}


def register(cls: type[OrchestratorAdapter]) -> type[OrchestratorAdapter]:
    REGISTRY[cls.platform] = cls
    return cls


def get_adapter(platform: str, **kwargs: Any) -> OrchestratorAdapter:
    if platform not in REGISTRY:
        raise KeyError(f"no adapter registered for {platform!r}; have {sorted(REGISTRY)}")
    return REGISTRY[platform](**kwargs)
