"""Airflow adapter. Reads from the REST API in production; from a JSON
fixture in dev so the whole system is runnable without credentials."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Iterable

from ..schema import FailureRecord, RunStatus
from .base import OrchestratorAdapter, register

_STATUS = {"failed": RunStatus.FAILED, "success": RunStatus.SUCCESS,
           "running": RunStatus.RUNNING, "up_for_retry": RunStatus.RUNNING}


@register
class AirflowAdapter(OrchestratorAdapter):
    platform = "airflow"

    def __init__(self, fixture: str | None = None, base_url: str | None = None,
                 token: str | None = None) -> None:
        self.fixture = fixture
        self.base_url = base_url
        self.token = token  # never logged, never persisted

    def fetch_raw(self, since: str | None = None) -> Iterable[dict[str, Any]]:
        if self.fixture:
            payload = json.loads(Path(self.fixture).read_text())
            return [r for r in payload if r.get("platform", "airflow") == "airflow"]
        raise NotImplementedError(
            "live Airflow ingest requires base_url + token; see docs/onboarding.md"
        )

    def map_record(self, raw: dict[str, Any]) -> FailureRecord:
        return FailureRecord(
            run_id=str(raw["dag_run_id"]),
            pipeline=raw["dag_id"],
            activity=raw["task_id"],
            platform=self.platform,
            status=_STATUS.get(raw["state"], RunStatus.FAILED),
            started_at=raw["start_date"],
            ended_at=raw.get("end_date"),
            error_code=raw.get("error_code"),
            error_text=raw.get("log_excerpt", ""),
            upstream_deps=raw.get("upstream_task_ids", []),
            downstream_deps=raw.get("downstream_task_ids", []),
            attempt=int(raw.get("try_number", 1)),
            severity=raw.get("severity", "p2"),
            raw_ref=raw.get("log_url"),
        )
