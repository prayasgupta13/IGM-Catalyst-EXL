"""Azure Data Factory adapter — different field names, identical output."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Iterable

from ..schema import FailureRecord, RunStatus
from .base import OrchestratorAdapter, register

_STATUS = {"Failed": RunStatus.FAILED, "Succeeded": RunStatus.SUCCESS,
           "InProgress": RunStatus.RUNNING, "Cancelled": RunStatus.CANCELLED}


@register
class ADFAdapter(OrchestratorAdapter):
    platform = "adf"

    def __init__(self, fixture: str | None = None, subscription_id: str | None = None,
                 factory: str | None = None) -> None:
        self.fixture = fixture
        self.subscription_id = subscription_id
        self.factory = factory

    def fetch_raw(self, since: str | None = None) -> Iterable[dict[str, Any]]:
        if self.fixture:
            payload = json.loads(Path(self.fixture).read_text())
            return [r for r in payload if r.get("platform") == "adf"]
        raise NotImplementedError("live ADF ingest uses the Monitor API; see docs/onboarding.md")

    def map_record(self, raw: dict[str, Any]) -> FailureRecord:
        return FailureRecord(
            run_id=str(raw["runId"]),
            pipeline=raw["pipelineName"],
            activity=raw["activityName"],
            platform=self.platform,
            status=_STATUS.get(raw["status"], RunStatus.FAILED),
            started_at=raw["activityRunStart"],
            ended_at=raw.get("activityRunEnd"),
            error_code=(raw.get("error") or {}).get("errorCode"),
            error_text=(raw.get("error") or {}).get("message", ""),
            upstream_deps=raw.get("dependsOn", []),
            downstream_deps=raw.get("feeds", []),
            attempt=int(raw.get("retryAttempt", 0)) + 1,
            severity=raw.get("severity", "p2"),
            raw_ref=raw.get("logLocation"),
        )
