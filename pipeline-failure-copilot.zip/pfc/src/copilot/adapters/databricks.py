"""Databricks Jobs adapter."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from ..schema import FailureRecord, RunStatus
from .base import OrchestratorAdapter, register

_STATUS = {"FAILED": RunStatus.FAILED, "SUCCESS": RunStatus.SUCCESS,
           "RUNNING": RunStatus.RUNNING, "CANCELED": RunStatus.CANCELLED}


def _ms(v: Any) -> datetime | None:
    return datetime.fromtimestamp(int(v) / 1000, tz=timezone.utc) if v else None


@register
class DatabricksAdapter(OrchestratorAdapter):
    platform = "databricks"

    def __init__(self, fixture: str | None = None, host: str | None = None,
                 token: str | None = None) -> None:
        self.fixture = fixture
        self.host = host
        self.token = token

    def fetch_raw(self, since: str | None = None) -> Iterable[dict[str, Any]]:
        if self.fixture:
            payload = json.loads(Path(self.fixture).read_text())
            return [r for r in payload if r.get("platform") == "databricks"]
        raise NotImplementedError("live ingest uses /api/2.1/jobs/runs/list; see docs/onboarding.md")

    def map_record(self, raw: dict[str, Any]) -> FailureRecord:
        state = raw.get("state", {})
        return FailureRecord(
            run_id=str(raw["run_id"]),
            pipeline=raw["job_name"],
            activity=raw.get("task_key", "main"),
            platform=self.platform,
            status=_STATUS.get(state.get("result_state", "FAILED"), RunStatus.FAILED),
            started_at=_ms(raw["start_time"]),
            ended_at=_ms(raw.get("end_time")),
            error_code=raw.get("error_code"),
            error_text=state.get("state_message", ""),
            upstream_deps=raw.get("depends_on", []),
            downstream_deps=raw.get("feeds", []),
            attempt=int(raw.get("attempt_number", 1)),
            severity=raw.get("severity", "p2"),
            raw_ref=raw.get("run_page_url"),
        )
