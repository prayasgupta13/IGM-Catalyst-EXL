"""SQLite-backed failure and resolution store.

SQLite keeps the repo runnable with no infrastructure. The DDL is plain SQL
and the queries are parameterised, so pointing this at Postgres is a
connection-string change, not a rewrite.
"""
from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterable, Iterator

from ..config import settings
from ..schema import FailureRecord, Resolution

DDL = """
CREATE TABLE IF NOT EXISTS failures (
    key           TEXT PRIMARY KEY,
    run_id        TEXT NOT NULL,
    pipeline      TEXT NOT NULL,
    activity      TEXT NOT NULL,
    platform      TEXT NOT NULL,
    tenant        TEXT NOT NULL,
    status        TEXT NOT NULL,
    started_at    TEXT NOT NULL,
    ended_at      TEXT,
    duration_s    REAL,
    error_code    TEXT,
    error_text    TEXT,
    signature     TEXT,
    severity      TEXT,
    attempt       INTEGER,
    upstream      TEXT,
    downstream    TEXT,
    raw_ref       TEXT,
    redacted      INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_failures_tenant   ON failures(tenant);
CREATE INDEX IF NOT EXISTS ix_failures_pipeline ON failures(pipeline, activity);
CREATE INDEX IF NOT EXISTS ix_failures_sig      ON failures(signature);
CREATE INDEX IF NOT EXISTS ix_failures_started  ON failures(started_at);

CREATE TABLE IF NOT EXISTS resolutions (
    resolution_id TEXT PRIMARY KEY,
    signature     TEXT NOT NULL,
    summary       TEXT,
    action_taken  TEXT,
    resolved_by   TEXT,
    resolved_at   TEXT,
    run_id        TEXT,
    succeeded     INTEGER,
    notes         TEXT
);
CREATE INDEX IF NOT EXISTS ix_res_sig ON resolutions(signature);
"""


@contextmanager
def connect(path: str | None = None) -> Iterator[sqlite3.Connection]:
    p = Path(path or settings.db_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(p)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init(path: str | None = None) -> None:
    with connect(path) as c:
        c.executescript(DDL)


def upsert_failures(records: Iterable[FailureRecord], path: str | None = None) -> int:
    rows = [(
        r.key, r.run_id, r.pipeline, r.activity, r.platform, r.tenant, r.status.value,
        r.started_at.isoformat(), r.ended_at.isoformat() if r.ended_at else None,
        r.duration_s, r.error_code, r.error_text, r.signature, r.severity.value,
        r.attempt, json.dumps(r.upstream_deps), json.dumps(r.downstream_deps),
        r.raw_ref, int(r.redaction_applied),
    ) for r in records]
    with connect(path) as c:
        c.executemany(
            "INSERT INTO failures VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
            "ON CONFLICT(key) DO UPDATE SET signature=excluded.signature, "
            "error_text=excluded.error_text, status=excluded.status", rows)
    return len(rows)


def _to_record(row: sqlite3.Row) -> FailureRecord:
    return FailureRecord(
        run_id=row["run_id"], pipeline=row["pipeline"], activity=row["activity"],
        platform=row["platform"], tenant=row["tenant"], status=row["status"],
        started_at=row["started_at"], ended_at=row["ended_at"],
        duration_s=row["duration_s"], error_code=row["error_code"],
        error_text=row["error_text"] or "", signature=row["signature"],
        severity=row["severity"], attempt=row["attempt"],
        upstream_deps=json.loads(row["upstream"] or "[]"),
        downstream_deps=json.loads(row["downstream"] or "[]"),
        raw_ref=row["raw_ref"], redaction_applied=bool(row["redacted"]),
    )


def query_failures(tenant: str | None = None, pipeline: str | None = None,
                   activity: str | None = None, signature: str | None = None,
                   run_id: str | None = None, limit: int = 50,
                   path: str | None = None) -> list[FailureRecord]:
    clauses, params = ["status = 'failed'"], []
    for col, val in (("tenant", tenant), ("pipeline", pipeline),
                     ("activity", activity), ("signature", signature), ("run_id", run_id)):
        if val:
            clauses.append(f"{col} = ?")
            params.append(val)
    sql = f"SELECT * FROM failures WHERE {' AND '.join(clauses)} ORDER BY started_at DESC LIMIT ?"
    params.append(limit)
    with connect(path) as c:
        return [_to_record(r) for r in c.execute(sql, params).fetchall()]


def search_failures(text: str, tenant: str | None = None, limit: int = 20,
                    path: str | None = None) -> list[FailureRecord]:
    """Cheap keyword pre-filter over pipeline/activity/error text."""
    like = f"%{text.lower()}%"
    sql = ("SELECT * FROM failures WHERE status='failed' AND ("
           "lower(pipeline) LIKE ? OR lower(activity) LIKE ? OR lower(error_text) LIKE ? "
           "OR lower(coalesce(error_code,'')) LIKE ?)")
    params: list[Any] = [like, like, like, like]
    if tenant:
        sql += " AND tenant = ?"
        params.append(tenant)
    sql += " ORDER BY started_at DESC LIMIT ?"
    params.append(limit)
    with connect(path) as c:
        return [_to_record(r) for r in c.execute(sql, params).fetchall()]


def upsert_resolutions(items: Iterable[Resolution], path: str | None = None) -> int:
    rows = [(r.resolution_id, r.signature, r.summary, r.action_taken, r.resolved_by,
             r.resolved_at.isoformat(), r.run_id, int(r.succeeded), r.notes) for r in items]
    with connect(path) as c:
        c.executemany("INSERT OR REPLACE INTO resolutions VALUES (?,?,?,?,?,?,?,?,?)", rows)
    return len(rows)


def resolutions_for(signature: str, path: str | None = None) -> list[Resolution]:
    with connect(path) as c:
        rows = c.execute("SELECT * FROM resolutions WHERE signature = ? ORDER BY resolved_at DESC",
                         (signature,)).fetchall()
    return [Resolution(
        resolution_id=r["resolution_id"], signature=r["signature"], summary=r["summary"],
        action_taken=r["action_taken"], resolved_by=r["resolved_by"],
        resolved_at=r["resolved_at"], run_id=r["run_id"],
        succeeded=bool(r["succeeded"]), notes=r["notes"] or "") for r in rows]


def stats(path: str | None = None) -> dict[str, Any]:
    with connect(path) as c:
        total = c.execute("SELECT COUNT(*) n FROM failures WHERE status='failed'").fetchone()["n"]
        signed = c.execute("SELECT COUNT(*) n FROM failures WHERE signature IS NOT NULL").fetchone()["n"]
        res = c.execute("SELECT COUNT(*) n FROM resolutions").fetchone()["n"]
        top = c.execute("SELECT signature, COUNT(*) n FROM failures WHERE signature IS NOT NULL "
                        "GROUP BY signature ORDER BY n DESC LIMIT 5").fetchall()
    return {"failures": total, "signed": signed, "resolutions": res,
            "top_signatures": [{"signature": r["signature"], "count": r["n"]} for r in top]}
