# Demo Script — 6 minutes

Run `make install && source .venv/bin/activate` beforehand. Keep two terminals:
one for commands, one tailing `copilot metrics`.

| # | Say this | Run this | Point at |
|---|---|---|---|
| 1 | "Nothing is visible to the assistant until the application is onboarded. Here is a manifest that fails our policy." | `copilot onboard onboarding/manifests/inventory_blocked.yaml` | Three refusals: literal secret, restricted data with write actions, bad security contact. |
| 2 | "Here is a compliant one. Ten gates, two approvers, one of them security." | `copilot onboard onboarding/manifests/billing.yaml` | The three-step promotion to ACTIVE. |
| 3 | "Three platforms, three different schemas, one canonical record. Secrets stripped before storage." | `copilot ingest` | The counts. Mention the adapter is ~60 lines. |
| 4 | "Now the question the business case asks for." | `copilot ask "Why did the customer billing load fail last night and can we recover it?"` | **Evidence block** — every claim cited. **Lineage** — the real origin is upstream. **Blast radius** — what the owner cares about. **Dry run + plan id** — nothing has executed. |
| 5 | "Least privilege applies to content, not just endpoints." | `copilot ask "why did billing fail" --user viewer` | `[withheld: principal lacks read:logs]`. |
| 6 | "Four gates, demonstrated." | the four `approve` commands in the README | Refusals for feature switch, RBAC scope, and wrong plan id — then success. |
| 7 | "Every attempt, allowed or denied, is hash-chained." | `copilot audit --tail 10` | `VALID — verified N entries`, and the denied row. |
| 8 | "And we score ourselves against what the on-call engineer actually concluded." | `copilot replay` | precision@1, and the **abstain** row. Land on `false_confidence=0`. |

**Closing line:** "The engineer reviewed a decision. They did not read a log — and
every step of that decision is reproducible from the trace id."

## If asked "is this real or a mock?"

Real: the canonical schema, all three adapter mappings, redaction, signature
classification, lineage traversal, RBAC, the five gates, the hash-chained audit,
the replay harness, the API, 37 tests.

Stubbed: the final platform SDK call inside each action tool, and `fetch_raw`
reads a fixture instead of a live endpoint. Both are named in the README's
Known Limitations, and each is a single method.
