# Architecture

## The one idea

Every orchestrator's run metadata is normalized into a single canonical
`FailureRecord` (`src/copilot/schema.py`). Everything above that line —
retrieval, signatures, agents, evaluation — only ever sees the canonical shape.

Onboarding a new platform is therefore an adapter (~60 lines), not a new
assistant.

## Flow

```
 pipeline logs ─┐
 execution hist ├─> Adapter ─> redact ─> classify ─> FailureRecord ─> store (SQLite/Postgres)
 error messages ┘                                                        │
                                                                         ▼
   question ──> Retriever ──> Diagnostician ──> Recommender ──> Operator ──> platform
                  scoped        signature        ranked by      5 gates,
                  query         first, then      observed       dry-run,
                                generation       success rate   approval
                                     │                              │
                                     └──────── evidence ────────────┘
                                                                         │
                                           resolution written back ──────┘
```

## Why the order inside Diagnostician matters

Signature match over history runs **before** any generation. The model is used to
*phrase* a conclusion that retrieval already supports; it is never the source of
the conclusion. That is what makes the answer reproducible and the cost bounded,
and it is why a novel failure abstains instead of inventing a cause.

## Confidence is arithmetic, not a model score

`diagnostician._score()` is a transparent formula: known signature (+0.30),
prior occurrences (up to +0.36), recorded resolutions (up to +0.28), lineage
corroboration (+0.08). An auditor can recompute it by hand. Below
`CONFIDENCE_THRESHOLD` (0.55) the assistant abstains.

## The planning loop

`agents/orchestrator.py` is what makes this agentic rather than a single prompt:
retrieve → lineage → diagnose → **re-plan on thin evidence** → recommend →
propose. The re-plan step widens the corpus before abstaining, and both outcomes
are recorded in `reasoning_steps` on the answer.

## Graded autonomy

| Phase | Setting | Behaviour |
|---|---|---|
| 1 | default | explain only; no tool can execute |
| 2 | default | + recommendations from the knowledge base |
| 3 | `ALLOW_ACTIONS=true` | propose-and-approve; every action human-gated |
| — | `ALLOW_AUTO_REMEDIATE=true` | reserved for signature-matched failures with a proven fix; off by default |

## Swapping components

| Component | Interface | To replace |
|---|---|---|
| Orchestrator | `OrchestratorAdapter` | implement `fetch_raw` + `map_record` |
| Model | `LLMClient` | implement `_complete` |
| Store | plain SQL in `store/db.py` | change the connection string |
| Lineage backend | `FileEmitter` | swap for an HTTP transport |
| Tracing | `span()` | set `OTEL_EXPORTER_OTLP_ENDPOINT` |

None of these touch the agents.
