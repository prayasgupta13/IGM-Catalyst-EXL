# Application Onboarding

> This is the process the evaluators asked for. It is enforced in code
> (`src/copilot/security/onboarding.py`), not described in a wiki page.
> **No pipeline is visible to the assistant until its application reaches
> `ACTIVE`.**

## Why onboarding is a gate, not paperwork

The assistant reads production operational data. The blast radius of getting
that wrong is an organisation-wide data incident, so access is granted per
*application*, by an approved manifest, with an expiry.

## Lifecycle

```
DRAFT ──validate──> VALIDATED ──gates + 2 approvals──> APPROVED ──activate──> ACTIVE
                                                                                │
                                              attestation lapses (default 90d)  │
                                                                                ▼
                                                                           SUSPENDED
```

Each transition writes an audit entry. A tenant whose attestation has lapsed is
auto-suspended **at query time**, not by a nightly job — so a lapsed review
cannot leave data exposed until the batch runs.

## Step 1 — the requesting team writes a manifest

`onboarding/manifests/<tenant>.yaml`. See `billing.yaml` for a complete example.

| Field | Why it is mandatory |
|---|---|
| `tenant_id` | Isolation boundary. Every query, record and audit entry is scoped to it. |
| `data_classification` | `restricted` forbids write actions entirely. |
| `platforms[].credential_ref` | Must be a `vault://`, `akv://` or `env://` reference. A literal secret fails validation. |
| `platforms[].scope` | Read-only for Phase 1 and 2. |
| `pii_fields` | Declared so redaction coverage is provable, not assumed. |
| `enabled_actions` | The action classes the owner has agreed may *ever* be enabled. Empty by default. |
| `review_days` | Re-attestation interval. |

## Step 2 — automated validation

```bash
copilot onboard onboarding/manifests/billing.yaml
```

Validation rejects, among others:

- a literal credential in the manifest instead of a secret-manager reference
- `restricted` data classification combined with any enabled write action
- a missing compliance gate
- a `security_contact` that is not an email address
- a `tenant_id` that is not a safe identifier

The non-compliant example `inventory_blocked.yaml` is included so you can watch
the refusal:

```bash
copilot onboard onboarding/manifests/inventory_blocked.yaml   # exits 1
```

## Step 3 — compliance gates

All ten must be `true` before approval. They map to the org controls a security
reviewer will ask about:

| Gate | Control it evidences |
|---|---|
| `data_classification_declared` | Data handling standard |
| `pii_fields_declared` | Privacy / DPIA |
| `read_only_credential` | Least privilege |
| `credential_in_vault` | Secrets management |
| `network_path_approved` | Network segmentation / egress review |
| `log_retention_agreed` | Records retention schedule |
| `dpia_or_waiver` | Privacy impact assessment |
| `owner_ack_actions` | Change management |
| `rollback_documented` | Operational resilience |
| `incident_contact` | Incident response |

## Step 4 — dual approval

Two **distinct** approvers are required, and one must hold the `security` role,
one the `owner` role. A single approver — even an admin — cannot self-approve.

## Step 5 — activation and ingest

Only now will `copilot ingest` accept data for the tenant. `Registry.assert_active()`
is called on the ingest path *and* on every query, so an offboarded or suspended
tenant stops being readable immediately.

## Offboarding

Set `state: retired` and re-run. Ingest and queries refuse instantly. Retained
failure records are deleted per the agreed `log_retention_agreed` schedule; the
audit trail is retained, since it is the evidence that the deletion happened.

## Adding a new orchestrator to an onboarded application

1. Implement an adapter (~60 lines) — see `src/copilot/adapters/adf.py`.
2. Add a `platforms:` entry with its `credential_ref`.
3. Re-run `copilot onboard` — this is a manifest change, so it needs re-approval.

Nothing else changes: agents, prompts, retrieval and the evaluation harness are
untouched. That is the cloud-agnostic constraint holding in practice.
