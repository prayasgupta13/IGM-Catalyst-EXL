# Lineage

Lineage is used for two things a log-reading chatbot cannot do.

## 1. Finding the *origin*, not the symptom

`LineageGraph.root_candidates()` walks upstream from the failing activity and
returns upstream activities that **also failed inside the same incident window**
(default 24h). The window matters: an unrelated failure six weeks ago on the same
upstream node is not tonight's cause, and the test
`test_old_upstream_failure_is_not_a_root_candidate` pins that behaviour.

In the seeded scenario the billing load fails with schema drift, but the true
origin is the CRM ingest throttling 3 hours earlier. The assistant reports the
upstream failure as lineage evidence and the confidence score is nudged up by the
corroboration.

## 2. Answering "what does this affect?"

`blast_radius()` walks downstream transitively, returning each asset with its hop
distance. This is the question the *pipeline owner* asks, and it is why the
assistant is useful to someone who will never open Airflow:

```
customer_billing_load.billing_agg      (1 hop)
customer_billing_load.revenue_mart     (1 hop)
revenue_mart_refresh.build_mart        (2 hops)
revenue_mart_refresh.exec_dashboard    (3 hops)
```

## Where edges come from

1. **Adapter dependency fields** — every adapter populates `upstream_deps` and `downstream_deps` from the orchestrator's own dependency model. Zero extra integration.
2. **OpenLineage events** — `add_openlineage_event()` consumes the standard RunEvent shape, so an existing Marquez / Purview / Unity Catalog feed enriches the graph with column- and dataset-level edges.

## The assistant emits lineage too

When the Operator executes an approved action it emits an OpenLineage
`COMPLETE` event tagged with the actor and `plan_id`
(`lineage/openlineage.py`). The assistant's own writes therefore appear in the
same lineage graph as every other producer. **Nothing it does is invisible to the
platform.**

Swapping the `FileEmitter` for an HTTP transport against a real backend is a
one-class change; callers are untouched.
