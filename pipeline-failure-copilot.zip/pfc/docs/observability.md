# Observability

Three signals, all emitted from `src/copilot/observability/telemetry.py`.

## Traces

Every agent step opens a span through the `span()` context manager. A single
`ask` produces this tree:

```
copilot.ask                 tenant, actor
├── retriever.retrieve      records, by_run_id, log_text_withheld
├── diagnostician.diagnose   signature, confidence, outcome
│   └── llm.complete         provider, model, input_tokens, output_tokens
├── recommender.rank         recommendations
└── operator.propose         tool, plan_id
```

OpenTelemetry is used when installed and exports to `OTEL_EXPORTER_OTLP_ENDPOINT`
(Jaeger, Tempo, App Insights). When it is absent the same attributes are emitted
as structured logs, so **evidence is never lost because a dependency is missing**.

## Structured logs

JSON on stderr, one object per event, every line carrying `trace_id` and `actor`:

```json
{"ts":"2026-09-07T10:45:40+0000","level":"INFO","msg":"span.diagnostician.diagnose",
 "trace_id":"525dd75ad8be42b6","actor":"p.gupta","duration_ms":1.13,
 "run_id":"4471","outcome":"diagnosed",
 "signature":"schema_drift:type_mismatch:timestamp","confidence":0.9}
```

Logs go to **stderr** so `--json` output on stdout stays machine-parseable.

## Metrics

Prometheus text format at `GET /metrics` or `copilot metrics`.

| Metric | Why it is tracked |
|---|---|
| `retriever_queries{matched}` | Retrieval hit rate |
| `diagnosis_total{outcome}` | matched / clustered / abstained mix |
| `copilot_escalations` | How often the assistant declines — the calibration signal |
| `recommendations_total` | Coverage of the playbook |
| `actions_total{outcome}` | executed / denied / failed |
| `ingest_records{platform,classified}` | Share of failures auto-classified |
| `ingest_redacted{platform}` | Redaction is firing, per platform |
| `llm_calls`, `llm_input_tokens`, `llm_output_tokens` | Unit cost per incident |
| `*_latency_ms` (count/avg/p95) | Per-agent latency |

## The four SLIs to put on a dashboard

1. **Precision@1** — from the replay harness, re-run on every merge.
2. **False-confidence rate** — answered confidently and was wrong. Target: zero.
3. **Auto-classified share** — `ingest_records{classified="True"}` over total; this is knowledge reuse, trending up.
4. **Cost per incident** — `llm_*_tokens` divided by incidents answered.

## Correlating an answer back to its evidence

Every `Answer` carries a `trace_id`. Given a user complaint about a specific
answer, one grep over the logs yields every retrieval, the signature, the
confidence, the token counts and the audit entries for the same trace.
