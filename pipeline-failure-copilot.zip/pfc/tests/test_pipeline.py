"""End-to-end and correctness tests for the agent pipeline."""
from __future__ import annotations

import pytest

from copilot.adapters import get_adapter
from copilot.agents.signatures import classify
from copilot.lineage import LineageGraph
from copilot.schema import FailureRecord


class TestAdapters:
    @pytest.mark.parametrize("platform,expected", [
        ("airflow", "customer_billing_load"),
        ("adf", "crm_ingest"),
        ("databricks", "revenue_mart_refresh"),
    ])
    def test_every_adapter_emits_the_same_shape(self, seed_runs, platform, expected):
        records = get_adapter(platform, fixture=seed_runs).normalize(tenant="billing")
        assert records, f"{platform} produced nothing"
        assert all(isinstance(r, FailureRecord) for r in records)
        assert any(r.pipeline == expected for r in records)
        for r in records:
            assert r.platform == platform and r.tenant == "billing"
            assert r.started_at is not None and r.run_id

    def test_adapter_redacts_before_storage(self, seed_runs):
        records = get_adapter("airflow", fixture=seed_runs).normalize(tenant="billing")
        blob = " ".join(r.error_text for r in records)
        assert "Str0ngPass" not in blob and "ops@exl.com" not in blob

    def test_adapter_fails_loudly_on_missing_field(self, seed_runs):
        adapter = get_adapter("airflow", fixture=seed_runs)
        bad = FailureRecord(run_id="", pipeline="p", activity="a", platform="airflow",
                            status="failed", started_at="2026-01-01T00:00:00Z")
        with pytest.raises(ValueError, match="missing required field"):
            adapter._validate(bad)


class TestSignatures:
    @pytest.mark.parametrize("text,expected", [
        ("expected timestamp, got string", "schema_drift:type_mismatch:timestamp"),
        ("Request limit exceeded (429)", "throttling:rate_limit:429"),
        ("Container killed by YARN for exceeding memory limits", "resource:oom:executor"),
        ("chosen as the deadlock victim", "db:deadlock"),
        ("connection timed out after 30s", "network:timeout"),
    ])
    def test_known_patterns_classify(self, text, expected):
        sig, known = classify(text)
        assert known and sig == expected

    def test_novel_error_clusters_but_is_not_claimed_as_known(self):
        sig, known = classify("Gremlin ate the parquet footer, id 0xDEAD at 2026-01-01T00:00:00Z")
        assert not known and sig.startswith("unclassified:")

    def test_fingerprint_is_stable_across_noise(self):
        a, _ = classify("Gremlin ate the footer, id 0xDEAD at 2026-01-01T00:00:00Z run 41")
        b, _ = classify("Gremlin ate the footer, id 0xBEEF at 2026-02-02T11:11:11Z run 99")
        assert a == b, "signatures must survive timestamps, hex and counters"


class TestLineage:
    def test_blast_radius_finds_transitive_downstream(self, graph):
        impacted = {n for n, _ in graph.blast_radius("customer_billing_load", "load_billing_facts")}
        assert "customer_billing_load.billing_agg" in impacted
        assert "revenue_mart_refresh.build_mart" in impacted   # 2 hops

    def test_root_candidate_prefers_same_window_upstream(self, records, graph):
        target = next(r for r in records if r.run_id == "4471")
        roots = graph.root_candidates(target, records)
        assert roots and roots[0].run_id == "af-88213"

    def test_old_upstream_failure_is_not_a_root_candidate(self, records, graph):
        target = next(r for r in records if r.run_id == "4471")
        roots = graph.root_candidates(target, records, window_hours=1)
        assert all(r.run_id != "af-84110" for r in roots)


class TestEndToEnd:
    def test_ask_produces_cited_diagnosis_and_a_proposal(self, live_copilot, engineer):
        answer = live_copilot.ask("Why did the customer billing load fail last night?",
                                  engineer, "billing")
        d = answer.diagnosis
        assert d and not d.abstained
        assert d.signature == "schema_drift:type_mismatch:timestamp"
        assert d.evidence, "every diagnosis must carry evidence"
        assert answer.recommendations
        assert answer.plan is not None
        assert answer.plan.dry_run_result.get("dry_run") is True, "must be a dry run"

    def test_metadata_only_principal_never_sees_log_text(self, live_copilot, viewer):
        answer = live_copilot.ask("why did billing fail", viewer, "billing")
        assert "withheld" in answer.target.error_text

    def test_abstains_when_history_is_thin(self, live_copilot, engineer):
        answer = live_copilot.ask("inventory sync upsert_stock deadlock", engineer, "billing")
        assert answer.diagnosis.confidence < 0.6

    def test_replay_reports_no_false_confidence(self, seeded_db):
        from copilot.eval import run_replay
        from copilot.config import ROOT
        result = run_replay(str(ROOT / "seed" / "labels.json"), tenant="billing")
        assert result.cases == 8
        assert result.false_confidence == 0, "confidently wrong is the failure that matters"
        assert result.precision_at_1 >= 0.9
