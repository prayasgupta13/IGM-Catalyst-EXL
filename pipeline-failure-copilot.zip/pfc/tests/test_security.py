"""Security tests. These are the evidence, not the claim."""
from __future__ import annotations

import pytest

from copilot.redaction import assert_clean, redact
from copilot.security.audit import AuditLog
from copilot.security.onboarding import Manifest
from copilot.security.rbac import Principal, Scope, authorize

ENGINEER = Principal("p.gupta", ("data_engineer",), ("billing",), mfa=True)
L1 = Principal("l1", ("support_l1",), ("billing",))
OUTSIDER = Principal("x", ("data_engineer",), ("other_app",), mfa=True)


class TestRedaction:
    def test_strips_common_secrets(self):
        out = redact("password=hunter2 user ops@exl.com from 10.1.2.3").text
        assert "hunter2" not in out and "ops@exl.com" not in out and "10.1.2.3" not in out

    def test_is_idempotent(self):
        once = redact("token=abcd1234 password=x").text
        assert redact(once).text == once

    def test_model_boundary_guard_rejects_raw_text(self):
        with pytest.raises(ValueError):
            assert_clean("client_secret=abc123xyz")

    def test_model_boundary_guard_accepts_redacted_text(self):
        assert_clean(redact("client_secret=abc123xyz").text)


class TestRBAC:
    def test_read_scope_granted(self):
        assert authorize(L1, Scope.READ_LOGS, "billing").allowed

    def test_read_does_not_imply_write(self):
        assert not authorize(L1, Scope.ACTION_BACKFILL, "billing", approved=True).allowed

    def test_write_requires_mfa(self):
        no_mfa = Principal("p", ("data_engineer",), ("billing",), mfa=False)
        d = authorize(no_mfa, Scope.ACTION_BACKFILL, "billing", approved=True)
        assert not d.allowed and "MFA" in d.reason

    def test_write_requires_explicit_approval(self):
        d = authorize(ENGINEER, Scope.ACTION_BACKFILL, "billing", approved=False)
        assert not d.allowed and "approval" in d.reason

    def test_tenant_isolation(self):
        assert not authorize(OUTSIDER, Scope.READ_METADATA, "billing").allowed

    def test_deny_by_default_for_unknown_role(self):
        nobody = Principal("n", ("made_up_role",), ("billing",))
        assert not authorize(nobody, Scope.READ_METADATA, "billing").allowed


class TestAuditChain:
    def test_chain_verifies(self, tmp_path):
        log = AuditLog(str(tmp_path / "a.log"))
        log.record("p", "act", "billing", "executed", rows=10)
        log.record("p", "act2", "billing", "denied")
        ok, _ = log.verify()
        assert ok

    def test_tamper_is_detected(self, tmp_path):
        path = tmp_path / "a.log"
        log = AuditLog(str(path))
        log.record("p", "act", "billing", "executed", rows=10)
        log.record("p", "act2", "billing", "executed", rows=20)
        path.write_text(path.read_text().replace('"rows": 10', '"rows": 999'))
        ok, msg = log.verify()
        assert not ok and "modified" in msg

    def test_deletion_is_detected(self, tmp_path):
        path = tmp_path / "a.log"
        log = AuditLog(str(path))
        for i in range(3):
            log.record("p", f"act{i}", "billing", "executed")
        lines = path.read_text().splitlines()
        path.write_text("\n".join([lines[0], lines[2]]) + "\n")
        ok, _ = log.verify()
        assert not ok


class TestOnboarding:
    def test_compliant_manifest_reaches_active(self, manifest_path):
        m = Manifest.load(manifest_path)
        for _ in range(3):
            ok, msg = m.promote("admin")
            assert ok, msg
        assert m.state == "active"

    def test_literal_secret_is_rejected(self, blocked_manifest_path):
        m = Manifest.load(blocked_manifest_path)
        problems = m.validate()
        assert any("secret-manager reference" in p for p in problems)

    def test_restricted_data_forbids_write_actions(self, blocked_manifest_path):
        m = Manifest.load(blocked_manifest_path)
        assert any("restricted data" in p for p in m.validate())

    def test_single_approver_is_rejected(self, blocked_manifest_path):
        m = Manifest.load(blocked_manifest_path)
        assert "two distinct approvers are required" in m.approver_check()

    def test_unonboarded_tenant_is_denied(self, registry):
        with pytest.raises(PermissionError):
            registry.assert_active("never_onboarded")
