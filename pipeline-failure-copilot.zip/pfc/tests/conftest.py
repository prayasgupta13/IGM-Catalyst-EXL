from __future__ import annotations

import shutil
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[1]


@pytest.fixture
def manifest_path(tmp_path):
    dst = tmp_path / "billing.yaml"
    shutil.copy(REPO / "onboarding" / "manifests" / "billing.yaml", dst)
    # reset to draft so the promotion path is exercised from the start
    text = dst.read_text().replace("state: active", "state: draft")
    dst.write_text(text)
    return dst


@pytest.fixture
def blocked_manifest_path(tmp_path):
    dst = tmp_path / "inventory.yaml"
    shutil.copy(REPO / "onboarding" / "manifests" / "inventory_blocked.yaml", dst)
    return dst


@pytest.fixture
def registry(tmp_path):
    from copilot.security.onboarding import Registry
    return Registry(tmp_path / "manifests")


@pytest.fixture
def seed_runs():
    return str(REPO / "seed" / "runs.json")


@pytest.fixture
def records(seed_runs):
    from copilot.adapters import get_adapter
    out = []
    for p in ("airflow", "adf", "databricks"):
        out += get_adapter(p, fixture=seed_runs).normalize(tenant="billing")
    return out


@pytest.fixture
def graph(records):
    from copilot.lineage import LineageGraph
    return LineageGraph.from_records(records)


@pytest.fixture
def seeded_db(tmp_path, monkeypatch):
    """A fully ingested, isolated database for one test."""
    import dataclasses
    from copilot import config
    db = tmp_path / "t.db"
    isolated = dataclasses.replace(config.settings, db_path=str(db),
                                   audit_path=str(tmp_path / "audit.log"))
    monkeypatch.setattr(config, "settings", isolated)
    for module in ("copilot.store.db", "copilot.agents.diagnostician",
                   "copilot.agents.operator", "copilot.llm.client"):
        import importlib
        monkeypatch.setattr(importlib.import_module(module), "settings", isolated,
                            raising=False)
    from copilot.agents.signatures import classify
    from copilot.adapters import get_adapter
    from copilot.store import init, upsert_failures, upsert_resolutions
    from copilot.schema import Resolution
    import json
    init(str(db))
    for p in ("airflow", "adf", "databricks"):
        recs = get_adapter(p, fixture=str(REPO / "seed" / "runs.json")).normalize(tenant="billing")
        for r in recs:
            r.signature, _ = classify(r.error_text, r.error_code)
        upsert_failures(recs, path=str(db))
    items = [Resolution(**r) for r in json.loads((REPO / "seed" / "resolutions.json").read_text())]
    upsert_resolutions(items, path=str(db))
    return str(db)


@pytest.fixture
def active_registry(tmp_path, manifest_path):
    from copilot.security.onboarding import Manifest, Registry
    d = tmp_path / "manifests"
    d.mkdir(exist_ok=True)
    m = Manifest.load(manifest_path)
    for _ in range(3):
        m.promote("test")
    m.dump(d / "billing.yaml")
    return Registry(d)


@pytest.fixture
def live_copilot(seeded_db, active_registry):
    from copilot.agents import Copilot
    return Copilot(active_registry)


@pytest.fixture
def engineer():
    from copilot.security.rbac import Principal
    return Principal("p.gupta", ("data_engineer",), ("billing",), mfa=True)


@pytest.fixture
def viewer():
    from copilot.security.rbac import Principal
    return Principal("v.viewer", ("viewer",), ("billing",))
