# Agentic AI Assistant for Intelligent Pipeline Failure Analysis

**EXL IGM Catalyst — Team 10** · Prayas Gupta · Anupam Vishwakarma · Vignesh G

A working implementation, not a prototype sketch. Query pipeline executions in
natural language, get a **cited** root cause, a **ranked** fix, and — behind five
gates and a human approval — the fix applied.

```bash
make install && source .venv/bin/activate && make demo
```

---

## What the previous round asked for

> *"Real technical implementation for production grade system related to
> observability, lineage, access controls needs more evidences. Also this
> presentation doesn't clearly tell the application onboarding process which is
> a very important part from the security and Org compliance policies."*

Each item, and where the evidence is:

| Asked for | Implemented in | Proven by | Try it |
|---|---|---|---|
| **Observability** | `observability/telemetry.py` — OTel spans per agent step, JSON logs with `trace_id`, Prometheus metrics | [docs/observability.md](docs/observability.md) | `make metrics`, traces in Jaeger via `docker compose up` |
| **Lineage** | `lineage/graph.py` — upstream root-cause attribution + downstream blast radius; OpenLineage consumed *and* emitted | [docs/lineage.md](docs/lineage.md) · `TestLineage` | `make ask` — see DOWNSTREAM IMPACT |
| **Access controls** | `security/rbac.py` (no standing privilege, deny by default, re-checked at execution), `security/audit.py` (hash-chained), `agents/operator.py` (five gates) | [docs/security-compliance.md](docs/security-compliance.md) · `TestRBAC`, `TestAuditChain` | `make audit`, and the gate walkthrough below |
| **Application onboarding** | `security/onboarding.py` — manifest, 10 compliance gates, dual approval, 90-day re-attestation, auto-suspend on lapse | [docs/onboarding.md](docs/onboarding.md) · `TestOnboarding` | `make onboard` |

---

## Quick start

```bash
git clone <your-repo-url> pipeline-failure-copilot
cd pipeline-failure-copilot

make install
source .venv/bin/activate

make demo          # onboard → ingest → ask → replay → audit
```

No API key, no cloud account, no database server. The default model provider is
`mock`: deterministic, offline, and deliberately incapable of inventing a root
cause — which proves the grounding comes from retrieval, not from the model.

To use a real model: `export LLM_PROVIDER=anthropic ANTHROPIC_API_KEY=sk-ant-...`

---

## The evaluator walkthrough

### 1. Onboarding refuses a non-compliant application

```bash
copilot onboard onboarding/manifests/inventory_blocked.yaml
```

```
[BLOCKED] credential_ref 'user=svc_etl;password=Str0ngPass!' must be a
          secret-manager reference, not a literal;
          restricted data may not have write actions enabled;
          security_contact must be an email address
```

Then approve a compliant one — validation, ten gates, dual approval, activation:

```bash
copilot onboard onboarding/manifests/billing.yaml
```

### 2. Ingest normalizes three different platforms into one shape

```bash
copilot ingest      # {"airflow": 4, "adf": 2, "databricks": 2, "resolutions": 5}
```

Secrets and PII are stripped **before** anything is persisted.

### 3. Ask

```bash
copilot ask "Why did the customer billing load fail last night and can we recover it?"
```

Returns the failing run, a root cause at confidence 0.90 with six pieces of
cited evidence, the four downstream assets at risk, a fix ranked by observed
success rate, and a **dry-run** action plan awaiting approval.

Note the lineage line: the local error is schema drift, but the assistant
reports that the *origin* is an upstream CRM throttle three hours earlier.

### 4. Access control, demonstrated rather than asserted

```bash
copilot ask "why did billing fail" --user viewer
#   log text replaced with [withheld: principal lacks read:logs]

copilot approve --plan <id> --question "..." --user engineer
#   REFUSED: action execution is disabled (ALLOW_ACTIONS=false)     ← gate 1

ALLOW_ACTIONS=true copilot approve --plan <id> --question "..." --user l2
#   REFUSED: role set does not grant this scope                     ← gate 4

ALLOW_ACTIONS=true copilot approve --plan wrong-id --question "..." --user engineer
#   plan id mismatch                                                ← gate 3

ALLOW_ACTIONS=true copilot approve --plan <id> --question "..." --user engineer
#   EXECUTED — and an OpenLineage event is emitted for the write
```

### 5. Every one of those attempts is in the tamper-evident log

```bash
copilot audit --tail 10
# audit chain: VALID — verified 36 entries
#   ... l2.support   action.execute:backfill   denied
#   ... p.gupta      action.execute:backfill   executed
```

### 6. Quality is measured, not claimed

```bash
copilot replay
```

```
4471       ok       conf=0.90  schema_drift:type_mismatch:timestamp
...
4468       abstain  conf=0.30  db:deadlock
------------------------------------------------------------
cases=8 precision@1=100.00% abstained=12.50% false_confidence=0.00%
```

The deadlock case **abstains** — no prior history, no recorded fix. That is the
system working. `false_confidence` (answered confidently and was wrong) is the
metric to look at first; CI fails the build if it is ever above zero.

---

## Architecture in one paragraph

Every orchestrator's run metadata is normalized into one canonical
`FailureRecord`. Everything above that line — retrieval, signature clustering,
the four agents, the evaluation harness — only ever sees the canonical shape, so
onboarding a new platform is a ~60-line adapter rather than a new assistant.
Inside the Diagnostician, deterministic signature matching over history runs
**before** any generation; the model phrases a conclusion that retrieval already
supports, and abstains when it does not. Full detail in
[docs/architecture.md](docs/architecture.md).

```
 logs ─┐
 history ├─> Adapter ─> redact ─> classify ─> FailureRecord ─> store
 errors ─┘                                                       │
                                                                 ▼
 question ─> Retriever ─> Diagnostician ─> Recommender ─> Operator ─> platform
              scoped       signature        ranked by     5 gates,
              query        first            success rate  dry-run, approval
                                │                             │
                                └───────── evidence ──────────┘
                                                                 │
                            resolution written back to memory ───┘
```

## Layout

```
src/copilot/
  schema.py            canonical FailureRecord — the ingestion contract
  redaction.py         idempotent secret/PII stripping at ingest
  config.py            env-driven settings; graded autonomy switches
  ingest.py            the only write path into the store
  cli.py               every demo below is a subcommand
  adapters/            airflow, adf, databricks — same output shape
  agents/              retriever, diagnostician, recommender, operator, orchestrator
  security/            rbac, hash-chained audit, onboarding registry
  observability/       spans, structured logs, Prometheus metrics
  lineage/             dependency graph, blast radius, OpenLineage
  llm/                 provider abstraction + model-boundary guard
  tools/               the four allow-listed actions
  eval/                replay harness
  api/                 FastAPI surface
onboarding/manifests/  billing.yaml (compliant), inventory_blocked.yaml (refused)
seed/                  runs, resolutions, labels — a runnable scenario
docs/                  architecture, onboarding, security, observability, lineage
tests/                 37 tests; security and correctness
```

## Graded autonomy

| Phase | Setting | Behaviour |
|---|---|---|
| 1 | default | explain only — no tool can execute |
| 2 | default | + fixes ranked from the knowledge base |
| 3 | `ALLOW_ACTIONS=true` | propose-and-approve, every action human-gated |
| — | `ALLOW_AUTO_REMEDIATE=true` | signature-matched failures with a proven fix; off by default |

## Known limitations

Stated because a reviewer will find them anyway:

- **Adapters read fixtures, not live APIs.** The mapping logic and the contract are real; wiring `fetch_raw` to the Airflow REST / ADF Monitor / Databricks Jobs APIs is the Phase 1 task, and each is a single method.
- **The knowledge base starts empty.** The business case gives us logs, execution history and error messages — not runbooks or resolved tickets. The seed resolutions stand in for what Phase 1 captures as the team resolves real failures.
- **Retrieval is keyword + signature, not embeddings.** Deliberate: it is deterministic, auditable and free. A vector index slots in behind the same `retrieve()` interface.
- **Action tools are stubs** that return realistic payloads. Every gate around them is real and tested; only the final platform SDK call is stubbed.

## Testing

```bash
pytest                    # 37 tests
pytest tests/test_security.py -v
ruff check src tests
```

CI runs the suite **and** the replay harness on every push, failing the build if
precision@1 drops below 90% or any answer is confidently wrong.
