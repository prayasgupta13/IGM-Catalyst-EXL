"""Turn a noisy error into a stable signature.

This is the single most important piece of engineering in the solution, because
it is what makes "repeated analysis of similar failures" stop being repeated.
A signature match is a dictionary lookup, not an LLM call.

Rules first (deterministic, auditable, free). Anything unmatched still gets a
fingerprint so it can cluster, but is flagged `matched=False` so the
diagnostician knows not to claim familiarity it does not have.
"""
from __future__ import annotations

import hashlib
import re

# (signature, matches-in-error-message-or-code, human label)
RULES: list[tuple[str, re.Pattern[str], str]] = [
    ("schema_drift.type_mismatch.timestamp",
     re.compile(r"cannot cast string to timestamp|expected timestamp.{0,20}got string"
                r"|data type mismatch.{0,60}timestamp", re.I),
     "A source column changed type and no longer casts to timestamp"),

    ("schema_drift.missing_column",
     re.compile(r"cannot resolve ['\"]?\w+['\"]?(?!.{0,60}data type mismatch)"
                r"|column .{0,30}(does not exist|not found)", re.I),
     "A column the pipeline expects is no longer present in the source"),

    ("throttling.rate_limit.429",
     re.compile(r"REQUEST_LIMIT_EXCEEDED|HTTP 429|\brate limit\b|too many requests"
                r"|Throttled", re.I),
     "The source API rejected the request for exceeding its rate limit"),

    ("resource.oom.executor",
     re.compile(r"exceeding memory limits|ExecutorLostFailure|OutOfMemory|\bOOM\b", re.I),
     "An executor was killed for using more memory than allocated"),

    ("resource.disk_spill",
     re.compile(r"No space left on device|disk quota exceeded", re.I),
     "The job exhausted local disk"),

    ("db.deadlock",
     re.compile(r"deadlock(ed)? on lock resources|deadlock victim", re.I),
     "The database chose this transaction as a deadlock victim"),

    ("auth.credential_expired",
     re.compile(r"token (has )?expired|invalid client secret|\b(401|403)\b.{0,30}"
                r"(unauthorized|forbidden)", re.I),
     "The credential the pipeline uses is no longer valid"),

    ("network.timeout",
     re.compile(r"connection timed out|read timed? out|socket timeout|ETIMEDOUT", re.I),
     "A network call did not return within the timeout"),

    ("upstream.missing_data",
     re.compile(r"(source (file|table)|path) (not found|does not exist)|no files matched", re.I),
     "The upstream data the pipeline reads was not there"),
]

# Fall back to a fingerprint that survives run-specific noise, so two
# occurrences of the same novel error still cluster together.
_NOISE = [
    (re.compile(r"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}\S*", re.I), "<ts>"),
    (re.compile(r"\b0x[0-9a-fA-F]+\b"), "<hex>"),
    (re.compile(r"\[REDACTED:[A-Z_]+\]"), "<redacted>"),
    (re.compile(r"'[^']{1,40}'"), "<literal>"),
    (re.compile(r"\b\d[\d,._]*\b"), "<n>"),
    (re.compile(r"\s+"), " "),
]


def fingerprint(text: str) -> str:
    """Strip run-specific noise, THEN lowercase.

    Order matters: lowercasing first would break the timestamp pattern (the
    'T' separator), and two runs of the same novel error would fingerprint
    differently — which is exactly the clustering we need.
    """
    norm = text or ""
    for pattern, repl in _NOISE:
        norm = pattern.sub(repl, norm)
    return "unclassified." + hashlib.sha1(norm.strip().lower()[:300].encode()).hexdigest()[:8]


def classify(error_message: str, error_code: str | None = None,
             log_window: str = "") -> tuple[str, bool, str]:
    """Return (signature, matched_known_rule, human_label).

    Order of evidence: the structured error message first, then the error code,
    then the log window. The log window is checked last because it is the
    noisiest of the three inputs.
    """
    for haystack in (f"{error_code or ''} {error_message or ''}", log_window):
        if not haystack.strip():
            continue
        for signature, pattern, label in RULES:
            if pattern.search(haystack):
                return signature, True, label
    return fingerprint(error_message or log_window), False, "No known pattern matched"
