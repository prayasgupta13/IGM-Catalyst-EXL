"""orders_export — a real, runnable pipeline job.

This is not a stub. It reads inputs/raw_data/orders.json, casts the columns to
their target types, and writes a CSV. It writes its own JSON log file, its own
execution-history row and its own error-message row into inputs/ — exactly the
three inputs the assistant reads for every other platform.

    Strict mode (default)   : casts order_ts with ONE format. Three rows in the
                              source use the legacy dd/MM/yyyy format, so the
                              job fails with a timestamp cast error.
    Fixed mode (--apply-fix): coerces both formats, then writes the CSV.

The point of the demo: the assistant diagnoses the strict failure using history
from ADF/Airflow/Databricks that share the same signature, proposes the fix,
and the engineer approves the rerun. Same signature, real job, real output file.
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "inputs" / "raw_data" / "orders.json"
LOG_DIR = ROOT / "inputs" / "pipeline_logs" / "local_demo"
HISTORY = ROOT / "inputs" / "execution_history" / "local_demo.json"
ERRORS = ROOT / "inputs" / "error_messages" / "local_demo.json"
OUT_DIR = ROOT / "outputs" / "demo_job"

PIPELINE = "orders_export"
ACTIVITY = "json_to_csv"
PLATFORM = "local_demo"

STRICT_FORMAT = "%Y-%m-%dT%H:%M:%SZ"
LEGACY_FORMAT = "%d/%m/%Y %H:%M:%S"

COLUMNS = ["order_id", "customer_id", "order_ts", "amount", "currency", "status"]


class JobLog:
    """Writes the same JSONL shape the other platforms emit."""

    def __init__(self, run_id: str) -> None:
        self.run_id = run_id
        self.lines: list[dict] = []
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        self.path = LOG_DIR / f"local_demo_{PIPELINE}_{run_id}.jsonl"

    def write(self, level: str, message: str) -> None:
        self.lines.append({
            "ts": datetime.now(timezone.utc).isoformat(timespec="milliseconds"
                                                       ).replace("+00:00", "Z"),
            "level": level,
            "job_name": PIPELINE,
            "task": ACTIVITY,
            "run_id": self.run_id,
            "message": message,
        })
        print(f"  [{level}] {message}")

    def flush(self) -> None:
        self.path.write_text("\n".join(json.dumps(l) for l in self.lines) + "\n")


def _append_json(path: Path, row: dict) -> None:
    rows = json.loads(path.read_text()) if path.exists() else []
    rows = [r for r in rows if r.get("run_id") != row.get("run_id")]
    rows.append(row)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(rows, indent=2))


def cast_timestamp(value: str, apply_fix: bool) -> datetime:
    """The whole demo turns on this function.

    Strict: one format only — a source that drifted to dd/MM/yyyy blows up.
    Fixed:  try the target format, fall back to the legacy one, then normalise.
    """
    try:
        return datetime.strptime(value, STRICT_FORMAT)
    except ValueError:
        if not apply_fix:
            raise TypeError(
                f"cannot resolve 'order_ts' due to data type mismatch: "
                f"cannot cast string to timestamp (value={value!r}, "
                f"expected format {STRICT_FORMAT})") from None
        return datetime.strptime(value, LEGACY_FORMAT)


def run(apply_fix: bool = False, run_id: str | None = None) -> dict:
    run_id = run_id or f"demo-{uuid.uuid4().hex[:6]}"
    log = JobLog(run_id)
    started = datetime.now(timezone.utc)
    t0 = time.perf_counter()

    mode = "FIXED (dual-format cast)" if apply_fix else "STRICT (single-format cast)"
    log.write("INFO", f"Job {PIPELINE}.{ACTIVITY} starting. run_id={run_id}")
    log.write("INFO", f"Cast mode: {mode}")
    log.write("INFO", f"Reading source file {SOURCE.name}")

    rows = json.loads(SOURCE.read_text())
    log.write("INFO", f"Read {len(rows)} records from source")

    converted: list[dict] = []
    coerced = 0
    try:
        for i, r in enumerate(rows, 1):
            ts = cast_timestamp(r["order_ts"], apply_fix)
            if "/" in r["order_ts"]:
                coerced += 1
                log.write("WARNING",
                          f"Row {i} ({r['order_id']}): order_ts used the legacy "
                          f"dd/MM/yyyy format — coerced to ISO-8601")
            converted.append({**r,
                              "order_ts": ts.strftime("%Y-%m-%d %H:%M:%S"),
                              "amount": f"{float(r['amount']):.2f}"})
    except TypeError as exc:
        elapsed = time.perf_counter() - t0
        ended = datetime.now(timezone.utc)
        log.write("ERROR", str(exc))
        log.write("ERROR", f"Job aborted after {len(converted)} of {len(rows)} rows")
        log.write("INFO", "Marking run as FAILED")
        log.flush()

        _append_json(HISTORY, {
            "run_id": run_id, "platform": PLATFORM, "pipeline": PIPELINE,
            "activity": ACTIVITY, "status": "failed",
            "started_at": started.isoformat(timespec="seconds").replace("+00:00", "Z"),
            "ended_at": ended.isoformat(timespec="seconds").replace("+00:00", "Z"),
            "attempt": 1, "max_attempts": 1, "rows_processed": len(converted),
            "upstream": [], "downstream": ["orders_mart.refresh"],
            "sla_minutes": 15,
            "log_file": f"inputs/pipeline_logs/{PLATFORM}/{log.path.name}",
        })
        _append_json(ERRORS, {
            "run_id": run_id, "error_code": "TYPE_CAST_FAILED",
            "error_class": "TypeError",
            "message": str(exc).split(" (value=")[0],
            "component": "orders_export", "stack_head": "at cast_timestamp",
            "raised_at": ended.isoformat(timespec="seconds").replace("+00:00", "Z"),
        })
        return {"run_id": run_id, "status": "failed", "error": str(exc),
                "rows_written": 0, "log_file": str(log.path), "duration_s": elapsed}

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    out_path = OUT_DIR / f"orders_{run_id}.csv"
    with out_path.open("w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=COLUMNS)
        writer.writeheader()
        writer.writerows(converted)

    elapsed = time.perf_counter() - t0
    ended = datetime.now(timezone.utc)
    log.write("INFO", f"Coerced {coerced} legacy timestamp(s) to ISO-8601")
    log.write("INFO", f"Wrote {len(converted)} rows to {out_path.name}")
    log.write("INFO", "Marking run as SUCCEEDED")
    log.flush()

    _append_json(HISTORY, {
        "run_id": run_id, "platform": PLATFORM, "pipeline": PIPELINE,
        "activity": ACTIVITY, "status": "success",
        "started_at": started.isoformat(timespec="seconds").replace("+00:00", "Z"),
        "ended_at": ended.isoformat(timespec="seconds").replace("+00:00", "Z"),
        "attempt": 1, "max_attempts": 1, "rows_processed": len(converted),
        "upstream": [], "downstream": ["orders_mart.refresh"],
        "sla_minutes": 15,
        "log_file": f"inputs/pipeline_logs/{PLATFORM}/{log.path.name}",
    })
    return {"run_id": run_id, "status": "success", "rows_written": len(converted),
            "coerced": coerced, "output_file": str(out_path.relative_to(ROOT)),
            "log_file": str(log.path), "duration_s": elapsed}


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--apply-fix", action="store_true",
                    help="coerce the legacy dd/MM/yyyy timestamps instead of failing")
    ap.add_argument("--run-id", default=None)
    args = ap.parse_args()
    result = run(apply_fix=args.apply_fix, run_id=args.run_id)
    print("\n" + json.dumps(result, indent=2))
    sys.exit(0 if result["status"] == "success" else 1)
