"""The canonical record.

Three inputs go in — pipeline logs, execution history, error messages — and
exactly this comes out. Every agent reads only this shape, which is how the
cloud-agnostic constraint is satisfied: a new platform is a new parser, not a
new assistant.

Think of it as the fact table in a small star schema:

    fact_failure  (one row per failed run attempt)
      ├── from execution history : run_id, pipeline, activity, status, timings, deps
      ├── from error messages    : error_code, error_class, error_message
      └── from pipeline logs     : log_window (redacted), log_file
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any


def to_utc(value: Any) -> datetime | None:
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    return datetime.fromisoformat(str(value).replace("Z", "+00:00"))


@dataclass
class FailureRecord:
    # --- identity -----------------------------------------------------------
    run_id: str
    platform: str
    pipeline: str
    activity: str

    # --- from execution history --------------------------------------------
    status: str = "failed"
    started_at: datetime | None = None
    ended_at: datetime | None = None
    duration_s: float | None = None
    attempt: int = 1
    max_attempts: int = 1
    rows_processed: int = 0
    upstream: list[str] = field(default_factory=list)
    downstream: list[str] = field(default_factory=list)
    sla_minutes: int | None = None

    # --- from error messages ------------------------------------------------
    error_code: str | None = None
    error_class: str | None = None
    error_message: str = ""

    # --- from pipeline logs -------------------------------------------------
    log_file: str | None = None
    log_window: str = ""            # ALWAYS redacted, always windowed
    log_lines_total: int = 0
    redacted_counts: dict[str, int] = field(default_factory=dict)

    # --- derived ------------------------------------------------------------
    signature: str | None = None
    exhausted_retries: bool = False
    breached_sla: bool = False

    def __post_init__(self) -> None:
        self.started_at = to_utc(self.started_at)
        self.ended_at = to_utc(self.ended_at)
        if self.duration_s is None and self.started_at and self.ended_at:
            self.duration_s = (self.ended_at - self.started_at).total_seconds()
        self.exhausted_retries = self.attempt >= self.max_attempts
        if self.sla_minutes and self.duration_s:
            self.breached_sla = self.duration_s > self.sla_minutes * 60

    @property
    def node(self) -> str:
        """Graph node id, used to join upstream/downstream references."""
        return f"{self.pipeline}.{self.activity}"

    def to_row(self) -> dict[str, Any]:
        d = asdict(self)
        d["started_at"] = self.started_at.isoformat() if self.started_at else None
        d["ended_at"] = self.ended_at.isoformat() if self.ended_at else None
        return d


@dataclass
class Evidence:
    """Constraint 2: nothing is asserted without one of these."""
    source: str          # execution_history | error_message | pipeline_log | resolution | lineage
    ref: str
    detail: str

    def to_dict(self) -> dict[str, str]:
        return asdict(self)


@dataclass
class Diagnosis:
    run_id: str
    signature: str
    root_cause: str
    confidence: float
    evidence: list[Evidence] = field(default_factory=list)
    abstained: bool = False
    abstain_reason: str = ""
    matched_rule: bool = False
    #: [(label, contribution)] — the exact arithmetic behind `confidence`.
    #: Recorded at scoring time so nothing downstream has to reconstruct it
    #: from the (capped) evidence list and get a different answer.
    score_parts: list[tuple[str, float]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {**asdict(self), "confidence": round(self.confidence, 3),
                "evidence": [e.to_dict() for e in self.evidence],
                "score_parts": [{"label": l, "value": round(v, 3)}
                                for l, v in self.score_parts]}


@dataclass
class Fix:
    action: str
    tool: str | None
    tool_args: dict[str, Any]
    success_rate: float
    attempts_seen: int
    median_ttr_min: float | None
    rationale: str
    evidence: list[Evidence] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {**asdict(self), "success_rate": round(self.success_rate, 3),
                "evidence": [e.to_dict() for e in self.evidence]}
