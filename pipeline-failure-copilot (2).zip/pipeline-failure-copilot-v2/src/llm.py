"""Model abstraction.

Two things enforced here rather than left to prompt discipline:
  * guard() runs on every prompt, so unredacted production data cannot leave
  * the system prompt forbids inventing facts, and the mock provider is
    physically incapable of it — it only reformats the evidence it was given

The model NEVER decides the root cause. Retrieval and signature matching do
that. The model only phrases it. That is what makes the answer reproducible.
"""
from __future__ import annotations

from dataclasses import dataclass

from .config import load
from .security import guard

SYSTEM = (
    "You are a data platform failure assistant for data engineers. "
    "You may ONLY restate the facts listed in the EVIDENCE block. "
    "Never invent a column, table, run id, metric or cause. "
    "If the evidence is insufficient, say so plainly. "
    "Answer in two sentences, plain English, no bullet points."
)


@dataclass
class Completion:
    text: str
    provider: str
    input_chars: int
    output_chars: int


class MockLLM:
    """Deterministic, offline, free. Used by default and in tests.

    It composes the answer from the evidence lines, which proves that the
    grounding comes from retrieval rather than from model knowledge.
    """
    name = "mock"

    def complete(self, prompt: str) -> Completion:
        facts = [l[2:].strip() for l in prompt.splitlines() if l.startswith("- ")]
        if not facts:
            text = "There is not enough evidence to state a cause."
        else:
            text = facts[0]
            if len(facts) > 1:
                text += " " + facts[1]
        return Completion(text, self.name, len(prompt), len(text))


class AnthropicLLM:  # pragma: no cover — needs a key
    name = "anthropic"

    def __init__(self) -> None:
        import os
        from anthropic import Anthropic
        self.client = Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
        self.model = load()["llm"]["model"]

    def complete(self, prompt: str) -> Completion:
        msg = self.client.messages.create(
            model=self.model, max_tokens=load()["llm"]["max_tokens"],
            system=SYSTEM, messages=[{"role": "user", "content": prompt}])
        text = "".join(b.text for b in msg.content if b.type == "text")
        return Completion(text, self.name, len(prompt), len(text))


def get_llm():
    if load()["llm"]["provider"] == "anthropic":
        try:
            return AnthropicLLM()
        except Exception as exc:
            print(f"  ! anthropic unavailable ({exc}); using mock")
    return MockLLM()


def summarize(evidence_lines: list[str]) -> Completion:
    """Constraint 1 boundary + constraint 2 grounding, in one place."""
    prompt = "EVIDENCE:\n" + "\n".join(f"- {l}" for l in evidence_lines)
    guard(prompt)          # nothing unredacted leaves this process
    guard(SYSTEM)
    return get_llm().complete(prompt)
