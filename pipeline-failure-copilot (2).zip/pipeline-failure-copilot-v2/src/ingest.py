"""ETL: walk inputs/ folder by folder, produce one fact table.

    inputs/pipeline_logs/<source>/*.jsonl   ─┐
    inputs/execution_history/<source>.json   ├─> normalize ─> classify ─> fact_failure
    inputs/error_messages/<source>.json     ─┘

Adding a source system means adding a folder + a parser + a config block.
This file does not change.
"""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any

from .config import ROOT, load, path, sources
from .contracts import FailureRecord
from .parsers import for_source
from .signatures import classify

DDL = """
CREATE TABLE IF NOT EXISTS fact_failure (
    run_id TEXT PRIMARY KEY, platform TEXT, pipeline TEXT, activity TEXT,
    status TEXT, started_at TEXT, ended_at TEXT, duration_s REAL,
    attempt INTEGER, max_attempts INTEGER, rows_processed INTEGER,
    upstream TEXT, downstream TEXT, sla_minutes INTEGER,
    error_code TEXT, error_class TEXT, error_message TEXT,
    log_file TEXT, log_window TEXT, log_lines_total INTEGER,
    redacted_counts TEXT, signature TEXT,
    exhausted_retries INTEGER, breached_sla INTEGER
);
CREATE INDEX IF NOT EXISTS ix_sig ON fact_failure(signature);
CREATE INDEX IF NOT EXISTS ix_pipe ON fact_failure(pipeline, activity);
"""
COLUMNS = ["run_id", "platform", "pipeline", "activity", "status", "started_at",
           "ended_at", "duration_s", "attempt", "max_attempts", "rows_processed",
           "upstream", "downstream", "sla_minutes", "error_code", "error_class",
           "error_message", "log_file", "log_window", "log_lines_total",
           "redacted_counts", "signature", "exhausted_retries", "breached_sla"]


def connect() -> sqlite3.Connection:
    db = path("outputs", "warehouse")
    db.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db)
    conn.row_factory = sqlite3.Row
    return conn


def _read(p: Path) -> list[dict[str, Any]]:
    return json.loads(p.read_text()) if p.exists() else []


def build(verbose: bool = True) -> tuple[list[FailureRecord], dict[str, Any]]:
    logs_root = path("inputs", "pipeline_logs")
    hist_root = path("inputs", "execution_history")
    err_root = path("inputs", "error_messages")

    records: list[FailureRecord] = []
    per_source: dict[str, dict[str, int]] = {}

    for source, spec in sources().items():
        history = _read(hist_root / f"{source}.json")
        errors = {e["run_id"]: e for e in _read(err_root / f"{source}.json")}

        parser = for_source(spec["parser"])
        parsed: dict[str, dict[str, Any]] = {}
        folder = logs_root / spec["log_folder"]
        if parser and folder.exists():
            for f in sorted(folder.glob("*.jsonl")):
                out = parser.parse(f)
                if out:
                    parsed[out["run_id"]] = out

        failed = [h for h in history if h["status"] == "failed"]
        for run in failed:
            err = errors.get(run["run_id"], {})
            log = parsed.get(run["run_id"], {})
            rec = FailureRecord(
                run_id=run["run_id"], platform=run["platform"],
                pipeline=run["pipeline"], activity=run["activity"],
                status=run["status"], started_at=run.get("started_at"),
                ended_at=run.get("ended_at"), attempt=run.get("attempt", 1),
                max_attempts=run.get("max_attempts", 1),
                rows_processed=run.get("rows_processed", 0),
                upstream=run.get("upstream", []), downstream=run.get("downstream", []),
                sla_minutes=run.get("sla_minutes"),
                error_code=err.get("error_code"), error_class=err.get("error_class"),
                error_message=err.get("message", ""),
                log_file=log.get("log_file"), log_window=log.get("log_window", ""),
                log_lines_total=log.get("log_lines_total", 0),
                redacted_counts=log.get("redacted_counts", {}),
            )
            rec.signature, _m, _l = classify(rec.error_message, rec.error_code,
                                             rec.log_window)
            records.append(rec)

        per_source[source] = {"runs": len(history), "failed": len(failed),
                              "log_files": len(parsed)}
        if verbose:
            print(f"  {spec['label']:<32} {len(history):>3} runs  "
                  f"{len(failed):>2} failed  {len(parsed):>2} log file(s)")

    return records, per_source


def write(records: list[FailureRecord]) -> int:
    conn = connect()
    conn.executescript(DDL)
    rows = []
    for r in records:
        d = r.to_row()
        d["upstream"] = json.dumps(d["upstream"])
        d["downstream"] = json.dumps(d["downstream"])
        d["redacted_counts"] = json.dumps(d["redacted_counts"])
        d["exhausted_retries"] = int(d["exhausted_retries"])
        d["breached_sla"] = int(d["breached_sla"])
        rows.append(tuple(d[c] for c in COLUMNS))
    conn.executemany(
        f"INSERT OR REPLACE INTO fact_failure VALUES ({','.join('?' * len(COLUMNS))})",
        rows)
    conn.commit()
    conn.close()
    return len(rows)


def run(verbose: bool = True) -> dict[str, Any]:
    if verbose:
        print("Reading inputs/ folder by folder:")
    records, per_source = build(verbose)
    n = write(records)
    sigs: dict[str, int] = {}
    for r in records:
        sigs[r.signature] = sigs.get(r.signature, 0) + 1
    unclassified = sum(v for k, v in sigs.items() if k.startswith("unclassified."))
    return {"rows": n, "per_source": per_source,
            "signatures": dict(sorted(sigs.items(), key=lambda kv: -kv[1])),
            "auto_classified_pct": round(100 * (n - unclassified) / n, 1) if n else 0.0}
