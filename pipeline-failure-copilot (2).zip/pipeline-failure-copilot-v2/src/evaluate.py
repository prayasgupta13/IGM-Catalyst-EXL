"""Replay harness — how a data engineer proves this works before trusting it.

Take failures you already resolved, replay them through the assistant, and
compare its signature against what you actually concluded.

Four numbers:
    precision@1      of the runs it answered, how many were right
    abstention_rate  how often it correctly declined
    false_confidence answered confidently AND was wrong   <-- the one that matters
    mean_latency_ms

false_confidence is the number to watch. An assistant that is 80% right and
never confidently wrong is safer to put in front of on-call than one that is
90% right and bluffs the rest.
"""
from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from .agents.diagnostician import diagnose
from .agents.retriever import _row_to_record
from .config import ROOT
from .ingest import connect

LABELS = ROOT / "inputs" / "labels.json"


@dataclass
class Result:
    cases: int = 0
    correct: int = 0
    wrong: int = 0
    abstained: int = 0
    mean_latency_ms: float = 0.0
    rows: list[dict[str, Any]] = field(default_factory=list)

    @property
    def answered(self) -> int:
        return self.cases - self.abstained

    @property
    def precision_at_1(self) -> float:
        return self.correct / self.answered if self.answered else 0.0

    @property
    def abstention_rate(self) -> float:
        return self.abstained / self.cases if self.cases else 0.0

    @property
    def false_confidence_rate(self) -> float:
        return self.wrong / self.cases if self.cases else 0.0

    def summary(self) -> str:
        return (f"cases={self.cases}  precision@1={self.precision_at_1:.0%}  "
                f"abstained={self.abstention_rate:.0%}  "
                f"false_confidence={self.false_confidence_rate:.0%}  "
                f"mean_latency={self.mean_latency_ms:.1f}ms")

    def to_dict(self) -> dict[str, Any]:
        return {**asdict(self), "precision_at_1": self.precision_at_1,
                "abstention_rate": self.abstention_rate,
                "false_confidence_rate": self.false_confidence_rate}


def run(labels_path: Path = LABELS) -> Result:
    labels = json.loads(labels_path.read_text())
    conn = connect()
    res = Result()
    latencies = []

    for case in labels:
        row = conn.execute("SELECT * FROM fact_failure WHERE run_id = ?",
                           (case["run_id"],)).fetchone()
        if row is None:
            continue
        record = _row_to_record(row)
        t0 = time.perf_counter()
        d = diagnose(record)
        latencies.append((time.perf_counter() - t0) * 1000)

        hit = d.signature == case["expected_signature"]
        if d.abstained:
            res.abstained += 1
            verdict = "abstain"
        elif hit:
            res.correct += 1
            verdict = "correct"
        else:
            res.wrong += 1
            verdict = "WRONG"

        res.cases += 1
        res.rows.append({"run_id": record.run_id, "verdict": verdict,
                         "expected": case["expected_signature"],
                         "predicted": d.signature, "confidence": d.confidence})
    conn.close()
    res.mean_latency_ms = sum(latencies) / len(latencies) if latencies else 0.0
    return res
