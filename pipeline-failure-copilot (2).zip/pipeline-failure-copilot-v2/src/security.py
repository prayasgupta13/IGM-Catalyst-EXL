"""Constraints 1 and 4, implemented.

  Constraint 1 — Secure handling of production data
      redact()      : strips secrets/PII from log text at INGEST
      guard()       : asserts nothing sensitive reaches the model boundary
      window()      : only the lines around the error, never the whole file

  Constraint 4 — Valid roles to perform operational actions
      Principal / can() / check_action()
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from .config import load

_cfg = load()
_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    (p["name"], re.compile(p["regex"]))
    for p in _cfg["security"]["redaction"]["patterns"]
]


# ---------------------------------------------------------------------------
# Constraint 1 — production data
# ---------------------------------------------------------------------------
def redact(text: str | None) -> tuple[str, dict[str, int]]:
    """Return (clean_text, {pattern_name: hits}).

    Idempotent by design: running it over already-redacted text must not
    re-fire, because stored log windows are re-checked at the model boundary.
    """
    if not text or not _cfg["security"]["redaction"]["enabled"]:
        return text or "", {}
    out, hits = text, {}
    for name, pattern in _PATTERNS:
        out, n = pattern.subn(f"[REDACTED:{name}]", out)
        if n:
            hits[name] = hits.get(name, 0) + n
    return out, hits


def guard(text: str) -> None:
    """Raise before anything unredacted can leave the process."""
    _, hits = redact(text)
    if hits:
        raise ValueError(f"unredacted data at model boundary: {sorted(hits)}")


def window(lines: list[str], first_error_idx: int) -> str:
    """Slice the log around the first ERROR line.

    A 40 MB Spark log is neither affordable nor safe to hand to a model. We
    take a few lines either side of the first error and cap the characters.
    """
    w = _cfg["security"]["log_window"]
    lo = max(0, first_error_idx - w["lines_before_error"])
    hi = min(len(lines), first_error_idx + w["lines_after_error"] + 1)
    return "\n".join(lines[lo:hi])[: w["max_chars"]]


# ---------------------------------------------------------------------------
# Constraint 4 — roles
# ---------------------------------------------------------------------------
ROLES: dict[str, list[str]] = _cfg["rbac"]["roles"]
ACTIONS: dict[str, dict[str, Any]] = _cfg["rbac"]["actions"]


class NotPermitted(PermissionError):
    """Raised at execution time, never swallowed."""


@dataclass(frozen=True)
class Principal:
    user: str
    role: str
    approved_by: str | None = None      # set when a human clicks Approve

    @property
    def permissions(self) -> list[str]:
        return ROLES.get(self.role, [])

    def can(self, permission: str) -> bool:
        return permission in self.permissions


@dataclass
class Verdict:
    allowed: bool
    reason: str
    tool: str = ""
    user: str = ""
    checks: list[str] = field(default_factory=list)

    def raise_if_denied(self) -> None:
        if not self.allowed:
            raise NotPermitted(f"{self.user} cannot run {self.tool}: {self.reason}")


def check_action(principal: Principal, tool: str) -> Verdict:
    """Four checks, in order, each recorded so the refusal is explainable."""
    spec = ACTIONS.get(tool)
    ex = _cfg["rbac"]["execution"]
    v = Verdict(True, "permitted", tool=tool, user=principal.user)

    if spec is None:
        return Verdict(False, f"{tool!r} is not in the configured action list",
                       tool, principal.user, ["allowlist:FAIL"])
    v.checks.append("allowlist:OK")

    if not ex["enabled"]:
        return Verdict(False, "action execution is disabled (rbac.execution.enabled=false)",
                       tool, principal.user, v.checks + ["execution_switch:FAIL"])
    v.checks.append("execution_switch:OK")

    if not principal.can(spec["permission"]):
        return Verdict(False, f"role {principal.role!r} lacks {spec['permission']!r}",
                       tool, principal.user, v.checks + ["permission:FAIL"])
    v.checks.append("permission:OK")

    if ex["require_approval"] and not principal.approved_by:
        return Verdict(False, "no human approval recorded for this plan",
                       tool, principal.user, v.checks + ["approval:FAIL"])
    v.checks.append("approval:OK")
    return v
