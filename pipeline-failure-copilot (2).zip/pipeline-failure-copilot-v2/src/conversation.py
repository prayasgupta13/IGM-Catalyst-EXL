"""Multi-turn conversation layer.

The business case names "effective conversational experience" as a success
criterion, and that means more than a text box over a search index. Two
properties matter:

  1. Follow-ups resolve against context, not the database.
     "what about upstream?" does not re-run retrieval, re-classify the error
     or call the model. It answers from the diagnosis already in the session.
     That is what makes turn 2 cost ~0ms instead of a full agent pass.

  2. The assistant knows what it is talking about.
     Pronouns ("it", "that one", "the same job") bind to the run in focus.
     A genuinely new question rebinds the focus and says so.

Intent classification is deterministic keyword matching, not an LLM call.
For a bounded set of operational follow-ups that is more reliable, free, and
auditable — and it degrades gracefully: anything unrecognised is treated as
a new question rather than guessed at.
"""
from __future__ import annotations

import re
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from .agents import Answer, approve_and_run, ask
from .execution_log import record
from .ingest import connect
from .knowledge import stats_for
from .security import Principal


class Intent(str, Enum):
    NEW_QUESTION = "new_question"
    EXPLAIN_CONFIDENCE = "explain_confidence"
    SHOW_LOG = "show_log"
    UPSTREAM = "upstream"
    DOWNSTREAM = "downstream"
    HISTORY = "history"
    FIXES = "fixes"
    RERUN = "rerun"
    EVIDENCE = "evidence"
    SOURCES = "sources"
    HELP = "help"


#: ordered — first match wins, so specific patterns sit above general ones
INTENT_RULES: list[tuple[Intent, re.Pattern[str]]] = [
    (Intent.HELP, re.compile(r"^\s*(help|what can you do|how does this work)\s*\??$", re.I)),
    (Intent.EXPLAIN_CONFIDENCE, re.compile(
        r"\b(how (sure|confident)|why (that|this) confidence|explain the (confidence|score)"
        r"|how did you (get|calculate|work out)|are you sure)\b", re.I)),
    (Intent.SHOW_LOG, re.compile(
        r"\b(show|see|view|give|pull)?\s*(me\s+)?(the\s+)?(raw\s+)?log(s| file| window)?\b", re.I)),
    (Intent.UPSTREAM, re.compile(
        r"\b(upstream|what caused it|root of|the origin|what broke first|source job)\b", re.I)),
    (Intent.DOWNSTREAM, re.compile(
        r"\b(downstream|impact|affected|what does (it|this) affect|blast radius"
        r"|who('s| is) affected|consumers)\b", re.I)),
    (Intent.FIXES, re.compile(
        r"\b(fix(es|ed)?|how was it (fixed|resolved)|what worked|remediat|what should i do"
        r"|recommend)\b", re.I)),
    (Intent.HISTORY, re.compile(
        r"\b(happened before|seen (this|it) before|history|how often|previous(ly)?"
        r"|last time|recur|again)\b", re.I)),
    (Intent.RERUN, re.compile(
        r"\b(re-?run|retry|trigger|execute|run it( again)?|apply (the )?fix|go ahead"
        r"|do it|approve)\b", re.I)),
    (Intent.EVIDENCE, re.compile(
        r"\b(evidence|proof|where did (that|this) come from|cite|how do you know)\b", re.I)),
    (Intent.SOURCES, re.compile(
        r"\b(what (sources|systems|platforms)|which (sources|systems)|what can you (see|read))\b",
        re.I)),
]

#: a message with one of these and nothing else is a follow-up, not a new query
_PRONOUN_ONLY = re.compile(
    r"^\s*(and\s+)?(what about|how about|and|ok|okay|then)?\s*"
    r"(it|that|this|the same|those|them)?\s*\??\s*$", re.I)


def classify_intent(text: str, has_context: bool) -> Intent:
    """Deterministic. Unrecognised text becomes a new question, never a guess."""
    if not has_context:
        return Intent.HELP if INTENT_RULES[0][1].search(text) else Intent.NEW_QUESTION
    for intent, pattern in INTENT_RULES:
        if pattern.search(text):
            return intent
    return Intent.NEW_QUESTION


@dataclass
class Turn:
    role: str                       # "user" | "assistant"
    text: str
    intent: str = ""
    cards: list[dict[str, Any]] = field(default_factory=list)
    duration_ms: float = 0.0
    used_context: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {"role": self.role, "text": self.text, "intent": self.intent,
                "cards": self.cards, "duration_ms": self.duration_ms,
                "used_context": self.used_context}


@dataclass
class Session:
    session_id: str = field(default_factory=lambda: f"S-{uuid.uuid4().hex[:8]}")
    turns: list[Turn] = field(default_factory=list)
    answer: Answer | None = None         # the run currently in focus
    role: str = "data_engineer"

    @property
    def has_context(self) -> bool:
        return self.answer is not None and self.answer.record_ is not None

    @property
    def focus(self) -> str:
        if not self.has_context:
            return ""
        r = self.answer.record_
        return f"{r.pipeline}.{r.activity} (run {r.run_id})"


SESSIONS: dict[str, Session] = {}


def get_session(session_id: str | None, role: str = "data_engineer") -> Session:
    if session_id and session_id in SESSIONS:
        s = SESSIONS[session_id]
        s.role = role
        return s
    s = Session(role=role)
    SESSIONS[s.session_id] = s
    return s


# ---------------------------------------------------------------------------
# follow-up handlers — each answers from the session, most touch no database
# ---------------------------------------------------------------------------
def _confidence_breakdown(session: Session) -> Turn:
    d = session.answer.diagnosis
    return Turn("assistant",
                f"Confidence is {d.confidence}, and it is arithmetic rather than a "
                f"model score — you can recompute it by hand:",
                cards=[{"type": "confidence", "total": d.confidence,
                        "threshold": 0.55, "abstained": d.abstained,
                        "parts": [{"label": l, "value": v} for l, v in d.score_parts]}],
                used_context=True)


def _show_log(session: Session, principal: Principal) -> Turn:
    r = session.answer.record_
    if not principal.can("read:logs"):
        return Turn("assistant",
                    f"Your role ({principal.role}) does not hold `read:logs`, so the "
                    f"log text is withheld. The diagnosis above is still available — "
                    f"least privilege applies to content, not just to endpoints.",
                    used_context=True)
    lines = (r.log_window or "").splitlines()
    if not lines:
        return Turn("assistant",
                    f"No log file was retained for run {r.run_id}. The diagnosis came "
                    f"from execution history and the error message alone — which is "
                    f"the normal case once log retention expires.", used_context=True)
    return Turn("assistant",
                f"Here is the redacted window around the first error in "
                f"`{r.log_file}`. Only the lines either side of the error are kept — "
                f"never the whole file.",
                cards=[{"type": "log", "run_id": r.run_id, "status": "failed",
                        "lines": lines, "redacted": r.redacted_counts}],
                used_context=True)


def _upstream(session: Session) -> Turn:
    d, r = session.answer.diagnosis, session.answer.record_
    lineage = [e for e in d.evidence if e.source == "lineage"]
    if lineage:
        return Turn("assistant",
                    f"Yes — {lineage[0].detail}. That is the origin; the error you see "
                    f"on {r.pipeline} is the symptom. Fixing only {r.activity} would "
                    f"leave the real cause in place.",
                    cards=[{"type": "evidence", "items": [e.to_dict() for e in lineage]}],
                    used_context=True)
    if not r.upstream:
        return Turn("assistant",
                    f"{r.pipeline}.{r.activity} has no upstream dependencies recorded, "
                    f"so this failure originates here.", used_context=True)
    return Turn("assistant",
                f"Its upstream dependencies are {', '.join(r.upstream)}, but none of "
                f"them failed in the same window — so the cause is local to "
                f"{r.activity}, not inherited.", used_context=True)


def _downstream(session: Session) -> Turn:
    impact = session.answer.impact
    r = session.answer.record_
    if not impact:
        return Turn("assistant",
                    f"Nothing downstream is recorded for {r.pipeline}.{r.activity}, so "
                    f"this failure does not propagate.", used_context=True)
    return Turn("assistant",
                f"{len(impact)} asset(s) sit downstream of this run and are now stale "
                f"or blocked:",
                cards=[{"type": "impact", "items": impact}], used_context=True)


def _history(session: Session) -> Turn:
    d, r = session.answer.diagnosis, session.answer.record_
    conn = connect()
    rows = conn.execute(
        "SELECT run_id, pipeline, activity, platform, started_at FROM fact_failure "
        "WHERE signature = ? ORDER BY started_at DESC LIMIT 8",
        (d.signature,)).fetchall()
    conn.close()
    others = [dict(x) for x in rows if x["run_id"] != r.run_id]
    if not others:
        return Turn("assistant",
                    f"This is the first time `{d.signature}` has been seen. There is no "
                    f"history to lean on, which is why the confidence is lower — and why "
                    f"whatever resolves it gets written back.", used_context=True)
    platforms = sorted({o["platform"] for o in others})
    return Turn("assistant",
                f"Yes — `{d.signature}` has occurred {len(others)} other time(s), across "
                f"{len(platforms)} source system(s) ({', '.join(platforms)}). Same "
                f"signature, different platforms: that is the knowledge reuse the "
                f"business case asks for.",
                cards=[{"type": "history", "items": others}], used_context=True)


def _fixes(session: Session) -> Turn:
    d = session.answer.diagnosis
    stats = stats_for(d.signature)
    if not stats["actions"]:
        return Turn("assistant",
                    f"Nothing has been recorded as a fix for `{d.signature}` yet.",
                    used_context=True)
    best = stats["actions"][0]
    worst = stats["actions"][-1]
    text = (f"{len(stats['actions'])} distinct action(s) have been tried for this "
            f"signature. The ranking is observed success rate, not opinion — "
            f"\"{best['action']}\" worked {best['successes']} of {best['attempts']} "
            f"time(s).")
    if worst["success_rate"] == 0 and worst is not best:
        text += (f" Note that \"{worst['action']}\" is recorded as having failed, "
                 f"which is why it ranks last rather than being hidden.")
    return Turn("assistant", text,
                cards=[{"type": "fixes",
                        "items": [f.to_dict() for f in session.answer.fixes]}],
                used_context=True)


def _evidence(session: Session) -> Turn:
    d = session.answer.diagnosis
    sources = sorted({e.source for e in d.evidence})
    return Turn("assistant",
                f"Every claim traces back to one of the three inputs. This diagnosis "
                f"rests on {len(d.evidence)} item(s) across {len(sources)} source "
                f"type(s): {', '.join(s.replace('_', ' ') for s in sources)}.",
                cards=[{"type": "evidence",
                        "items": [e.to_dict() for e in d.evidence]}],
                used_context=True)


def _rerun(session: Session) -> Turn:
    plan = session.answer.plan
    if plan is None:
        return Turn("assistant",
                    "No corrective action was proposed for this run, so there is "
                    "nothing to trigger.", used_context=True)
    if not plan.can_execute:
        return Turn("assistant",
                    f"I can show you the plan, but I cannot execute it. "
                    f"{plan.blocked_reason} The steps below are for review only.",
                    cards=[{"type": "preview", "plan": plan.to_dict(),
                            "executable": False}], used_context=True)
    return Turn("assistant",
                "Here is exactly what will happen. Nothing runs until you approve it.",
                cards=[{"type": "preview", "plan": plan.to_dict(),
                        "executable": True}], used_context=True)


def _sources() -> Turn:
    from .config import sources as src_cfg
    items = [{"id": k, "label": v["label"], "can_rerun": bool(v.get("can_rerun")),
              "folder": f"inputs/pipeline_logs/{v['log_folder']}"}
             for k, v in src_cfg().items()]
    return Turn("assistant",
                "I read three inputs — pipeline logs, execution history and error "
                "messages — for each of these source systems:",
                cards=[{"type": "sources", "items": items}])


def _help(session: Session) -> Turn:
    lines = [
        "Ask about any failed run in plain English, then follow up naturally.",
        "",
        "**Opening questions** — \"why did orders_export fail\", "
        "\"what happened with crm_ingest\", \"revenue mart build failure\"",
        "",
        "**Follow-ups** (these use the run already in focus, no new lookup):",
        "· \"how confident are you?\" — the confidence arithmetic, broken down",
        "· \"show me the log\" — the redacted window around the error",
        "· \"what caused it upstream?\" — lineage, the origin vs the symptom",
        "· \"what does this affect?\" — downstream blast radius",
        "· \"has this happened before?\" — history across all source systems",
        "· \"how was it fixed?\" — ranked by observed success rate",
        "· \"re-run it\" — preview the exact actions, then approve",
    ]
    if session.has_context:
        lines += ["", f"Currently in focus: **{session.focus}**"]
    return Turn("assistant", "\n".join(lines))


# ---------------------------------------------------------------------------
def respond(session: Session, message: str, principal: Principal) -> Turn:
    """One user message in, one assistant turn out."""
    t0 = time.perf_counter()
    session.turns.append(Turn("user", message))

    intent = classify_intent(message, session.has_context)

    # A bare pronoun with context is never a new question.
    if intent is Intent.NEW_QUESTION and session.has_context and _PRONOUN_ONLY.match(message):
        intent = Intent.EVIDENCE

    if intent is Intent.NEW_QUESTION:
        answer = ask(message, principal)
        session.answer = answer
        if answer.record_ is None:
            turn = Turn("assistant",
                        "I could not find a failed run matching that. Try naming the "
                        "pipeline — for example \"why did orders_export fail\" — or ask "
                        "\"what sources can you see?\".")
        else:
            r, d = answer.record_, answer.diagnosis
            lead = (f"`{r.pipeline}.{r.activity}` (run {r.run_id}) on "
                    f"{r.platform} failed. ")
            turn = Turn("assistant", lead + (d.root_cause if d else ""),
                        cards=[{"type": "diagnosis", "answer": answer.to_dict()}])
    elif intent is Intent.HELP:
        turn = _help(session)
    elif intent is Intent.SOURCES:
        turn = _sources()
    elif intent is Intent.EXPLAIN_CONFIDENCE:
        turn = _confidence_breakdown(session)
    elif intent is Intent.SHOW_LOG:
        turn = _show_log(session, principal)
    elif intent is Intent.UPSTREAM:
        turn = _upstream(session)
    elif intent is Intent.DOWNSTREAM:
        turn = _downstream(session)
    elif intent is Intent.HISTORY:
        turn = _history(session)
    elif intent is Intent.FIXES:
        turn = _fixes(session)
    elif intent is Intent.EVIDENCE:
        turn = _evidence(session)
    elif intent is Intent.RERUN:
        turn = _rerun(session)
    else:  # pragma: no cover - exhaustive above
        turn = _help(session)

    turn.intent = intent.value
    turn.duration_ms = round((time.perf_counter() - t0) * 1000, 1)
    session.turns.append(turn)

    # A new question is logged by the agent loop itself; follow-ups are logged
    # here, so the CSV shows the true cost of a conversation.
    if intent is not Intent.NEW_QUESTION:
        r = session.answer.record_ if session.has_context else None
        record("follow_up", user=principal.user, role=principal.role,
               question=message, run_id=r.run_id if r else "",
               pipeline=r.pipeline if r else "", activity=r.activity if r else "",
               source_system=r.platform if r else "",
               signature=session.answer.diagnosis.signature
               if session.has_context and session.answer.diagnosis else "",
               outcome=intent.value, duration_ms=turn.duration_ms,
               notes="answered from session context")
    return turn


def approve(session: Session, principal: Principal) -> Turn:
    """The user clicked Approve on a previewed plan."""
    t0 = time.perf_counter()
    try:
        result = approve_and_run(session.answer, principal)
    except PermissionError as exc:
        return Turn("assistant",
                    f"Refused: {exc}. That is the role check working — switch to a "
                    f"role holding the required permission and try again.",
                    intent="approve_refused",
                    duration_ms=round((time.perf_counter() - t0) * 1000, 1),
                    used_context=True)

    from . import ingest
    ingest.run(verbose=False)          # read the new log back in

    lines: list[str] = []
    from .parsers import for_source
    from .config import ROOT
    folder = ROOT / "inputs" / "pipeline_logs" / "local_demo"
    for f in folder.glob(f"*{result.get('run_id','')}*.jsonl"):
        lines = (for_source("local_demo").parse(f).get("log_window", "")).splitlines()

    turn = Turn("assistant",
                f"Done. The job re-ran as `{result['run_id']}` and succeeded — "
                f"{result['rows_written']} rows written, {result.get('coerced', 0)} "
                f"timestamp(s) coerced.",
                cards=[{"type": "result", "result": result, "lines": lines}],
                intent="approve_executed", used_context=True,
                duration_ms=round((time.perf_counter() - t0) * 1000, 1))
    session.turns.append(turn)
    return turn
