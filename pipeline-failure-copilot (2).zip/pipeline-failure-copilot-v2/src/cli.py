"""CLI — same capabilities as the web UI, for scripting and CI."""
from __future__ import annotations

import argparse
import json
import sys

from . import ingest as ingest_mod
from .agents import approve_and_run, ask as ask_agent
from .execution_log import summary
from .security import Principal

USERS = {"viewer": ("v.viewer", "viewer"), "l1": ("l1.support", "support_l1"),
         "l2": ("l2.support", "support_l2"),
         "engineer": ("p.gupta", "data_engineer"), "lead": ("team.lead", "lead")}


def _p(name: str, approved: bool = False) -> Principal:
    user, role = USERS[name]
    return Principal(user, role, approved_by=user if approved else None)


def cmd_ingest(a) -> int:
    out = ingest_mod.run()
    print(f"\n  rows: {out['rows']}  ·  auto-classified: {out['auto_classified_pct']}%")
    for sig, n in out["signatures"].items():
        print(f"      {n} x {sig}")
    return 0


def cmd_demo_fail(a) -> int:
    from .demo_job import job
    r = job.run(apply_fix=False, run_id=a.run_id)
    print(json.dumps(r, indent=2))
    return 0


def cmd_ask(a) -> int:
    ans = ask_agent(a.question, _p(a.user))
    if a.json:
        print(json.dumps(ans.to_dict(), indent=2, default=str))
        return 0
    r, d = ans.record_, ans.diagnosis
    print("\n" + "=" * 74)
    print(f"Q: {ans.question}    [{ans.actor} / {ans.role}]")
    print("=" * 74)
    if not r:
        print("\nNo failed runs matched.")
        return 0
    print(f"\nFAILED RUN  {r.pipeline}.{r.activity}  run={r.run_id}  source={r.platform}")
    if d:
        print(f"\n{'ABSTAINED' if d.abstained else 'ROOT CAUSE'}  "
              f"confidence {d.confidence}  signature {d.signature}")
        print(f"  {d.root_cause}")
        print("\nEVIDENCE")
        for e in d.evidence:
            print(f"  [{e.source:<18}] {e.detail}")
    if ans.fixes:
        print("\nRECOMMENDED FIXES")
        for i, f in enumerate(ans.fixes, 1):
            print(f"  {i}. {f.action}  ({f.success_rate:.0%} over {f.attempts_seen})")
    if ans.plan:
        print(f"\nPROPOSED ACTION  tool={ans.plan.tool}  "
              f"executable={ans.plan.can_execute}")
        for s in ans.plan.preview:
            print(f"    • {s}")
        if ans.plan.can_execute:
            print(f"\n  Approve:  python -m src.cli approve --question "
                  f"\"{ans.question}\" --user engineer")
    print(f"\n  execution_id {ans.execution_id} · logged to the execution CSV\n")
    return 0


def cmd_approve(a) -> int:
    p = _p(a.user, approved=True)
    ans = ask_agent(a.question, p)
    if not ans.plan:
        print("No plan proposed.")
        return 1
    print("\nPREVIEW — what will happen:")
    for s in ans.plan.preview:
        print(f"  • {s}")
    try:
        r = approve_and_run(ans, p)
        print("\nEXECUTED:", json.dumps(r, indent=2, default=str))
        return 0
    except PermissionError as exc:
        print(f"\nREFUSED: {exc}")
        return 1


def cmd_executions(a) -> int:
    print(json.dumps(summary(), indent=2))
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser("copilot")
    sub = ap.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("ingest"); s.set_defaults(fn=cmd_ingest)
    s = sub.add_parser("demo-fail", help="run the demo job in strict mode so it fails")
    s.add_argument("--run-id", default=None); s.set_defaults(fn=cmd_demo_fail)
    s = sub.add_parser("ask"); s.add_argument("question")
    s.add_argument("--user", default="engineer", choices=sorted(USERS))
    s.add_argument("--json", action="store_true"); s.set_defaults(fn=cmd_ask)
    s = sub.add_parser("approve"); s.add_argument("--question", required=True)
    s.add_argument("--user", default="engineer", choices=sorted(USERS))
    s.set_defaults(fn=cmd_approve)
    s = sub.add_parser("executions"); s.set_defaults(fn=cmd_executions)

    args = ap.parse_args(argv)
    return args.fn(args)


if __name__ == "__main__":
    sys.exit(main())
