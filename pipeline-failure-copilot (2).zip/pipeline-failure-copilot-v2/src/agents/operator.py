"""AGENT 4 — Operator. Proposes, then (on approval) actually reruns.

Two kinds of target:

  can_rerun: false   ADF, Airflow, Databricks. No live API is wired up, so the
                     Operator produces the plan and stops. It says so plainly
                     rather than pretending.

  can_rerun: true    The local demo job. The Operator imports the job module
                     and really executes it, producing a new log file, a new
                     execution-history row and a real CSV.

Four gates apply to both, in order, each recorded in the execution CSV.
"""
from __future__ import annotations

import hashlib
import importlib
import json
import time
from dataclasses import dataclass, field
from typing import Any

from ..config import ROOT, sources
from ..security import Principal, check_action

ROLLBACK = {
    "rerun": "Kill the triggered run. Output is written to a new file; the "
             "previous output is untouched.",
    "backfill": "Re-run the original window from the retained partition snapshot.",
    "scale_cluster": "Restore the previous cluster config, recorded in the plan.",
    "notify": "No data effect.",
}


@dataclass
class Plan:
    tool: str
    args: dict[str, Any]
    rationale: str
    source: str
    can_execute: bool
    preview: list[str] = field(default_factory=list)
    blocked_reason: str = ""

    @property
    def plan_id(self) -> str:
        body = json.dumps({"tool": self.tool, "args": self.args, "source": self.source},
                          sort_keys=True, default=str)
        return hashlib.sha256(body.encode()).hexdigest()[:12]

    def to_dict(self) -> dict[str, Any]:
        return {"plan_id": self.plan_id, "tool": self.tool, "args": self.args,
                "rationale": self.rationale, "source": self.source,
                "can_execute": self.can_execute, "preview": self.preview,
                "blocked_reason": self.blocked_reason,
                "rollback": ROLLBACK.get(self.tool, "No rollback documented.")}


def build_preview(tool: str, args: dict[str, Any], source: str) -> list[str]:
    """Requirement 5: show exactly what would happen BEFORE anything runs."""
    spec = sources().get(source, {})
    steps: list[str] = []
    if source == "local_demo":
        steps = [
            "Apply the fix: enable dual-format timestamp parsing "
            "(ISO-8601 and legacy dd/MM/yyyy).",
            f"Re-execute {args.get('pipeline')}.{args.get('activity')} against "
            "the same source file — the source is not modified.",
            "Write a NEW CSV to outputs/demo_job/ with a new run id. "
            "Previous output files are left untouched.",
            "Emit a new JSON log file and a new execution-history row so the "
            "assistant can read the result back.",
            "Append the outcome to the knowledge base so the next occurrence "
            "of this signature is answered from memory.",
        ]
    elif tool == "rerun":
        steps = [
            f"Would call the {spec.get('label', source)} API to re-trigger "
            f"{args.get('pipeline')}.{args.get('activity')}.",
            f"Config change to apply: "
            f"{ {k: v for k, v in args.items() if k not in {'pipeline','activity','run_id'}} or 'none'}",
            "No data is mutated until the triggered run completes.",
        ]
    elif tool == "backfill":
        steps = [
            f"Would re-process {args.get('pipeline')} for the window "
            f"{args.get('window_start')} to {args.get('window_end')}.",
            "Target partitions are overwritten; the prior snapshot is retained "
            "for rollback.",
        ]
    elif tool == "scale_cluster":
        steps = [
            f"Would set executor memory to {args.get('executor_memory')} on "
            f"{args.get('job')}.",
            f"Would repartition on {args.get('repartition_key')} to address skew.",
            "Cluster restart required; no data is mutated by this action alone.",
        ]
    else:
        steps = [f"Would post a summary to {args.get('channel', 'the owning team')}."]

    if not spec.get("can_rerun", False) and tool != "notify":
        steps.append(
            f"NOT EXECUTABLE: no live {spec.get('label', source)} integration is "
            "configured. The plan is produced for review only.")
    return steps


def propose(tool: str, args: dict[str, Any], rationale: str, source: str) -> Plan:
    spec = sources().get(source, {})
    can = bool(spec.get("can_rerun", False)) or tool == "notify"
    return Plan(tool=tool, args=args, rationale=rationale, source=source,
                can_execute=can, preview=build_preview(tool, args, source),
                blocked_reason="" if can else
                f"No live integration configured for {spec.get('label', source)}.")


def execute(plan: Plan, principal: Principal, approval_token: str) -> dict[str, Any]:
    """Gates, then real execution. Raises PermissionError with the gate name."""
    if approval_token != plan.plan_id:
        raise PermissionError("gate 1 (plan binding): approval token does not "
                              "match this plan — approvals cannot be replayed")

    verdict = check_action(principal, plan.tool)
    if not verdict.allowed:
        raise PermissionError(f"gate {len(verdict.checks)}: {verdict.reason}")

    if not plan.can_execute:
        raise PermissionError(f"gate 5 (integration): {plan.blocked_reason}")

    spec = sources()[plan.source]
    module = importlib.import_module(spec["rerun_module"])
    t0 = time.perf_counter()
    result = module.run(apply_fix=bool(plan.args.get("apply_fix", True)))
    result["duration_ms"] = round((time.perf_counter() - t0) * 1000, 1)
    result["gates_passed"] = verdict.checks + ["integration:OK"]
    return result
