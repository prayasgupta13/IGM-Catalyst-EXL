"""The agent loop, wired to the execution CSV.

    Query -> Identify -> Summarize -> Recommend -> Preview -> (approve) -> Trigger

Every pass through writes a row to outputs/executions/copilot_executions.csv.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

from ..config import sources
from ..contracts import Diagnosis, FailureRecord, Fix
from ..execution_log import record
from ..ingest import connect
from ..security import Principal
from .diagnostician import diagnose
from .operator import Plan, execute, propose
from .recommender import recommend
from .retriever import retrieve


@dataclass
class Answer:
    question: str
    actor: str
    role: str
    execution_id: str = ""
    record_: FailureRecord | None = None
    diagnosis: Diagnosis | None = None
    fixes: list[Fix] = field(default_factory=list)
    plan: Plan | None = None
    impact: list[str] = field(default_factory=list)
    steps: list[str] = field(default_factory=list)
    duration_ms: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        r = self.record_
        return {
            "execution_id": self.execution_id,
            "question": self.question,
            "actor": self.actor, "role": self.role,
            "duration_ms": self.duration_ms,
            "run": ({**r.to_row(),
                     "source_label": sources().get(r.platform, {}).get("label", r.platform)}
                    if r else None),
            "diagnosis": self.diagnosis.to_dict() if self.diagnosis else None,
            "fixes": [f.to_dict() for f in self.fixes],
            "plan": self.plan.to_dict() if self.plan else None,
            "impact": self.impact,
            "steps": self.steps,
        }


def _downstream(rec: FailureRecord, max_hops: int = 3) -> list[str]:
    import json as _json
    conn = connect()
    seen, out, frontier, hop = {rec.node}, [], list(rec.downstream), 1
    while frontier and hop <= max_hops:
        nxt = []
        for node in frontier:
            if node in seen:
                continue
            seen.add(node)
            out.append(f"{node} ({hop} hop{'s' if hop > 1 else ''})")
            pipe, _, act = node.partition(".")
            for row in conn.execute(
                    "SELECT downstream FROM fact_failure WHERE pipeline=? AND activity=? LIMIT 1",
                    (pipe, act)).fetchall():
                nxt += _json.loads(row["downstream"] or "[]")
        frontier, hop = nxt, hop + 1
    conn.close()
    return out


def ask(question: str, principal: Principal) -> Answer:
    t0 = time.perf_counter()
    ans = Answer(question=question, actor=principal.user, role=principal.role)

    records, query = retrieve(question, principal)
    ans.steps.append(
        f"Retriever: matched {len(records)} failed run(s)"
        + (f" by run_id={query.run_id}" if query.run_id
           else f" on terms {query.terms}" if query.terms else " (most recent)"))
    if not records:
        ans.duration_ms = round((time.perf_counter() - t0) * 1000, 1)
        ans.execution_id = record("query", user=principal.user, role=principal.role,
                                  question=question, outcome="no_match",
                                  duration_ms=ans.duration_ms)
        return ans

    rec = records[0]
    ans.record_ = rec

    diagnosis = diagnose(rec)
    ans.steps.append(f"Diagnostician: signature={diagnosis.signature} "
                     f"confidence={diagnosis.confidence}")
    if diagnosis.abstained:
        ans.steps.append("Confidence below threshold — abstaining and escalating")
    ans.diagnosis = diagnosis

    ans.impact = _downstream(rec)
    if ans.impact:
        ans.steps.append(f"Lineage: {len(ans.impact)} downstream asset(s) at risk")

    ans.fixes = recommend(diagnosis, rec)
    ans.steps.append(f"Recommender: ranked {len(ans.fixes)} action(s) by observed "
                     "success rate")

    top = ans.fixes[0] if ans.fixes else None
    if top and top.tool:
        args = dict(top.tool_args)
        if rec.platform == "local_demo":
            args = {"pipeline": rec.pipeline, "activity": rec.activity,
                    "run_id": rec.run_id, "apply_fix": True}
        ans.plan = propose(top.tool, args, top.rationale, rec.platform)
        ans.steps.append(
            f"Operator: previewed {top.tool} — "
            + ("awaiting approval" if ans.plan.can_execute
               else "no live integration, review only"))

    ans.duration_ms = round((time.perf_counter() - t0) * 1000, 1)
    ans.execution_id = record(
        "query", user=principal.user, role=principal.role, question=question,
        source_system=rec.platform, pipeline=rec.pipeline, activity=rec.activity,
        run_id=rec.run_id, signature=diagnosis.signature,
        confidence=diagnosis.confidence, abstained=diagnosis.abstained,
        evidence_count=len(diagnosis.evidence),
        recommended_action=top.action if top else "",
        action_tool=top.tool if top else "", outcome="answered",
        duration_ms=ans.duration_ms)
    return ans


def approve_and_run(answer: Answer, principal: Principal) -> dict[str, Any]:
    """Requirement 5/6: the user approved the previewed plan — now run it."""
    plan = answer.plan
    if plan is None:
        raise PermissionError("no plan was proposed for this question")
    rec = answer.record_
    base = dict(user=principal.user, role=principal.role, question=answer.question,
                source_system=plan.source, pipeline=rec.pipeline if rec else "",
                activity=rec.activity if rec else "", run_id=rec.run_id if rec else "",
                signature=answer.diagnosis.signature if answer.diagnosis else "",
                action_tool=plan.tool, decision="approved")
    try:
        result = execute(plan, principal, plan.plan_id)
    except PermissionError as exc:
        record("action_refused", outcome=str(exc), **base)
        raise

    record("action_executed", outcome=result.get("status", "executed"),
           duration_ms=result.get("duration_ms", ""),
           rows_affected=result.get("rows_written", ""),
           output_file=result.get("output_file", ""),
           notes=f"gates: {'|'.join(result.get('gates_passed', []))}", **base)

    if result.get("status") == "success":
        from ..knowledge import record_outcome
        entry = record_outcome(
            signature=answer.diagnosis.signature, run_id=rec.run_id if rec else "",
            action=answer.fixes[0].action if answer.fixes else plan.tool,
            tool=plan.tool, outcome="success", resolved_by=principal.user,
            time_to_resolve_min=round(result.get("duration_ms", 0) / 60000, 3),
            notes="applied and rerun via copilot")
        result["knowledge_entry"] = entry["resolution_id"]
    return result
