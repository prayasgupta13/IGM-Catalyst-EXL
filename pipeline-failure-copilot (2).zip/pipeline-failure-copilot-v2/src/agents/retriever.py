"""AGENT 1 — Retriever.  Journey step: "Query".

Turns a data engineer's plain-English question into a scoped SQL query over
fact_failure. Two rules:

  * never SELECT the whole table into context — we return the matching runs only
  * never return log_window to a principal without read:logs (constraint 4
    applied to CONTENT, not just to endpoints)
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass

from ..contracts import FailureRecord
from ..ingest import connect
from ..security import Principal

_STOPWORDS = {
    "why", "did", "the", "my", "our", "fail", "failed", "failing", "last", "night",
    "yesterday", "today", "what", "how", "can", "we", "it", "is", "was", "and",
    "for", "a", "an", "of", "to", "on", "in", "run", "job", "show", "me", "get",
    "recover", "fix", "happened", "wrong", "with", "there", "any",
}
_RUN_ID = re.compile(r"\b(?:run|run[_ ]?id|dag[_ ]?run)\s*#?\s*([A-Za-z0-9._-]{3,})\b", re.I)
_BARE_ID = re.compile(r"\b(?:\d{4,}|[a-z]{2,3}-\d{4,})\b", re.I)


@dataclass
class Query:
    raw: str
    run_id: str | None
    terms: list[str]
    sql: str
    params: list[str]


def _row_to_record(row) -> FailureRecord:
    return FailureRecord(
        run_id=row["run_id"], platform=row["platform"], pipeline=row["pipeline"],
        activity=row["activity"], status=row["status"],
        started_at=row["started_at"], ended_at=row["ended_at"],
        duration_s=row["duration_s"], attempt=row["attempt"],
        max_attempts=row["max_attempts"], rows_processed=row["rows_processed"],
        upstream=json.loads(row["upstream"] or "[]"),
        downstream=json.loads(row["downstream"] or "[]"),
        sla_minutes=row["sla_minutes"], error_code=row["error_code"],
        error_class=row["error_class"], error_message=row["error_message"] or "",
        log_file=row["log_file"], log_window=row["log_window"] or "",
        log_lines_total=row["log_lines_total"],
        redacted_counts=json.loads(row["redacted_counts"] or "{}"),
        signature=row["signature"],
    )


def build_query(question: str) -> Query:
    """Plain English -> parameterised SQL. No string interpolation, ever."""
    run_id = None
    if m := _RUN_ID.search(question):
        run_id = m.group(1)
    elif m := _BARE_ID.search(question):
        run_id = m.group(0)

    terms = [w for w in re.findall(r"[a-z_][a-z_0-9]{2,}", question.lower())
             if w not in _STOPWORDS][:5]

    if run_id:
        return Query(question, run_id, terms,
                     "SELECT * FROM fact_failure WHERE run_id = ?", [run_id])

    if terms:
        clauses = " OR ".join(
            ["lower(pipeline) LIKE ?", "lower(activity) LIKE ?",
             "lower(error_message) LIKE ?", "lower(signature) LIKE ?"] * len(terms))
        params = [f"%{t}%" for t in terms for _ in range(4)]
        return Query(question, None, terms,
                     f"SELECT * FROM fact_failure WHERE {clauses} "
                     "ORDER BY started_at DESC LIMIT 10", params)

    return Query(question, None, [],
                 "SELECT * FROM fact_failure ORDER BY started_at DESC LIMIT 10", [])


def retrieve(question: str, principal: Principal) -> tuple[list[FailureRecord], Query]:
    q = build_query(question)
    conn = connect()
    rows = conn.execute(q.sql, q.params).fetchall()
    conn.close()

    records = [_row_to_record(r) for r in rows]

    # Constraint 4, applied to content: no read:logs, no log text.
    if not principal.can("read:logs"):
        for r in records:
            r.log_window = "[withheld — your role does not grant read:logs]"
            r.log_file = None
    return records, q
