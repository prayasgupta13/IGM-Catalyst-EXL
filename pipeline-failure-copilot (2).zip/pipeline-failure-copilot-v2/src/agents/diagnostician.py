"""AGENT 2 — Diagnostician.  Journey steps: "Identify root cause" + "Summarize".

Order of operations is the whole accuracy argument:

    1. classify the error into a signature      (deterministic, free)
    2. look up how often we have seen it        (SQL over execution history)
    3. check whether an UPSTREAM run failed first (lineage from the deps)
    4. gather evidence from all three inputs
    5. score confidence with a formula an auditor can recompute by hand
    6. ONLY THEN ask the model to phrase it

If the score is below the configured threshold, we abstain. A wrong root cause
costs a data engineer more time than no root cause.
"""
from __future__ import annotations

from datetime import timedelta

from ..config import load
from ..contracts import Diagnosis, Evidence, FailureRecord
from ..ingest import connect
from ..knowledge import for_signature
from ..llm import summarize
from ..signatures import classify

_cfg = load()["explainability"]


def _prior_occurrences(signature: str, exclude_run: str) -> list[dict]:
    conn = connect()
    rows = conn.execute(
        "SELECT run_id, pipeline, activity, started_at FROM fact_failure "
        "WHERE signature = ? AND run_id != ? ORDER BY started_at DESC LIMIT 5",
        (signature, exclude_run)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def _upstream_failure(record: FailureRecord, window_hours: int = 24) -> dict | None:
    """Did something upstream fail first, in the same incident window?

    This is the difference between 'the task that errored' and 'the thing that
    broke'. Without it, the engineer fixes the symptom.
    """
    if not record.upstream or not record.started_at:
        return None
    lo = (record.started_at - timedelta(hours=window_hours)).isoformat()
    hi = record.started_at.isoformat()
    conn = connect()
    placeholders = ",".join("?" * len(record.upstream))
    rows = conn.execute(
        f"SELECT run_id, pipeline, activity, started_at, error_code, signature "
        f"FROM fact_failure "
        f"WHERE (pipeline || '.' || activity) IN ({placeholders}) "
        f"AND started_at BETWEEN ? AND ? ORDER BY started_at DESC LIMIT 1",
        (*record.upstream, lo, hi)).fetchall()
    conn.close()
    return dict(rows[0]) if rows else None


def score_breakdown(matched_rule: bool, priors: int, resolutions: int,
                    upstream: bool, has_log: bool) -> list[tuple[str, float]]:
    """The arithmetic, itemised. score() is just the sum of this."""
    parts = [
        ("Known signature matched a rule" if matched_rule
         else "Unrecognised error, clustered by fingerprint",
         0.30 if matched_rule else 0.08),
        (f"{priors} prior occurrence(s) of this signature", min(priors, 3) * 0.10),
        (f"{resolutions} recorded fix(es) for it", min(resolutions, 2) * 0.12),
        ("Upstream failure corroborates the cause", 0.08 if upstream else 0.0),
        ("Log window available for this run", 0.05 if has_log else 0.0),
    ]
    return [(label, round(value, 3)) for label, value in parts if value > 0]


def score(matched_rule: bool, priors: int, resolutions: int,
          upstream: bool, has_log: bool) -> float:
    """Transparent confidence. No hidden model score — recompute it by hand.

        known signature      +0.30      (or +0.08 for a clustered unknown)
        each prior occurrence +0.10     capped at 3
        each known resolution +0.12     capped at 2
        upstream corroboration +0.08
        log window available   +0.05
    """
    s = 0.30 if matched_rule else 0.08
    s += min(priors, 3) * 0.10
    s += min(resolutions, 2) * 0.12
    s += 0.08 if upstream else 0.0
    s += 0.05 if has_log else 0.0
    return round(min(s, 0.97), 3)


def diagnose(record: FailureRecord) -> Diagnosis:
    signature, matched, label = classify(
        record.error_message, record.error_code, record.log_window)
    record.signature = signature

    evidence: list[Evidence] = []

    # --- evidence from INPUT 2: execution history --------------------------
    hist = (f"{record.pipeline}.{record.activity} failed at "
            f"{record.started_at:%Y-%m-%d %H:%M} UTC on attempt "
            f"{record.attempt} of {record.max_attempts}")
    if record.exhausted_retries:
        hist += " — retries exhausted, so this is not a transient blip"
    evidence.append(Evidence("execution_history", f"run {record.run_id}", hist))

    # --- evidence from INPUT 3: error message ------------------------------
    if record.error_message:
        evidence.append(Evidence(
            "error_message", record.error_code or "uncoded",
            f"{label}: {record.error_message}"))

    # --- evidence from INPUT 1: pipeline log window ------------------------
    has_log = bool(record.log_window) and "withheld" not in record.log_window
    if has_log:
        error_lines = [l for l in record.log_window.splitlines()
                       if "[ERROR]" in l or "[Error]" in l or "[WARN" in l]
        if error_lines:
            evidence.append(Evidence(
                "pipeline_log", record.log_file or "log",
                error_lines[0].strip()[:220]))

    # --- lineage: did something upstream fail first? -----------------------
    upstream = _upstream_failure(record)
    if upstream:
        evidence.append(Evidence(
            "lineage", f"run {upstream['run_id']}",
            f"upstream {upstream['pipeline']}.{upstream['activity']} failed first "
            f"at {upstream['started_at'][11:16]} UTC ({upstream['error_code']})"))

    # --- history of the same signature -------------------------------------
    priors = _prior_occurrences(signature, record.run_id)
    for p in priors[:2]:
        evidence.append(Evidence(
            "execution_history", f"run {p['run_id']}",
            f"same signature on {p['started_at'][:10]}"))

    resolutions = for_signature(signature)
    for r in resolutions[:2]:
        evidence.append(Evidence(
            "resolution", r["resolution_id"],
            f"{r['action']} — {r['outcome']} ({r['resolved_by']})"))

    conf = score(matched, len(priors), len(resolutions), bool(upstream), has_log)
    parts = score_breakdown(matched, len(priors), len(resolutions),
                            bool(upstream), has_log)

    # --- constraint 2: no evidence, no answer ------------------------------
    if _cfg["require_evidence"] and len(evidence) < _cfg["min_evidence_items"]:
        return Diagnosis(record.run_id, signature,
                         "Not enough evidence to state a root cause.", conf,
                         evidence, abstained=True,
                         abstain_reason="fewer evidence items than the configured minimum",
                         score_parts=parts)

    if conf < _cfg["confidence_threshold"]:
        return Diagnosis(
            record.run_id, signature,
            "Not enough evidence to state a root cause with confidence.", conf,
            evidence, abstained=True, matched_rule=matched,
            abstain_reason=(
                f"confidence {conf} is below the {_cfg['confidence_threshold']} threshold: "
                f"{len(priors)} prior occurrence(s), {len(resolutions)} recorded fix(es). "
                "Escalating is cheaper than guessing."),
            score_parts=parts)

    # --- constraint 2: the model only PHRASES what evidence supports -------
    facts = [e.detail for e in evidence]
    if upstream:
        facts.insert(0, f"The origin is upstream: {upstream['pipeline']}."
                        f"{upstream['activity']} failed before this activity did.")
    text = summarize(facts).text

    return Diagnosis(record.run_id, signature, text, conf, evidence,
                     matched_rule=matched, score_parts=parts)
