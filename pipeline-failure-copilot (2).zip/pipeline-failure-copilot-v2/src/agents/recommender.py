"""AGENT 3 — Recommender.  Journey step: "Recommend fixes".

Ranking is computed from the knowledge base, never asserted by the model:

    success_rate  = successes / attempts   for that action on that signature
    tie-break     = how many attempts back it up

Failed attempts are in the data too, which is why 'rerun with no config change'
correctly sinks below 'reduce parallelism' for the throttling signature.
"""
from __future__ import annotations

from typing import Any

from ..contracts import Diagnosis, Evidence, FailureRecord, Fix
from ..knowledge import stats_for

# Maps a signature to the tool + arguments an action would use. Adding a
# playbook entry is data, not code paths.
PLAYBOOK: dict[str, dict[str, Any]] = {
    "schema_drift.type_mismatch.timestamp": {
        "tool": "backfill",
        "args": lambda r: {"pipeline": r.pipeline, "activity": r.activity,
                           "window_start": r.started_at.isoformat(),
                           "window_end": (r.ended_at or r.started_at).isoformat()},
    },
    "throttling.rate_limit.429": {
        "tool": "rerun",
        "args": lambda r: {"pipeline": r.pipeline, "activity": r.activity,
                           "run_id": r.run_id, "parallel_copies": 4},
    },
    "resource.oom.executor": {
        "tool": "scale_cluster",
        "args": lambda r: {"job": r.pipeline, "executor_memory": "28g",
                           "repartition_key": "customer_id"},
    },
    "db.deadlock": {
        "tool": "rerun",
        "args": lambda r: {"pipeline": r.pipeline, "activity": r.activity,
                           "run_id": r.run_id},
    },
}


# When the failing run belongs to a source we can actually re-execute, the
# fix is the concrete one for THAT job, not the generic playbook entry.
LOCAL_FIXES: dict[str, dict[str, Any]] = {
    "schema_drift.type_mismatch.timestamp": {
        "action": "Enable dual-format timestamp parsing, then re-run the job",
        "tool": "rerun",
        "detail": "The source emits both ISO-8601 and legacy dd/MM/yyyy values. "
                  "Coerce both instead of failing on the second.",
    },
}


def recommend(diagnosis: Diagnosis, record: FailureRecord, top_n: int = 3) -> list[Fix]:
    if diagnosis.abstained:
        return [Fix(
            action="Escalate to the pipeline owner with this diagnosis attached",
            tool="notify", tool_args={"channel": f"#{record.pipeline}",
                                      "summary": diagnosis.abstain_reason},
            success_rate=0.0, attempts_seen=0, median_ttr_min=None,
            rationale="No confident diagnosis, so no fix is proposed. Whatever "
                      "resolves this will be captured, making the next occurrence cheaper.",
            evidence=[])]

    stats = stats_for(diagnosis.signature)
    play = PLAYBOOK.get(diagnosis.signature)
    fixes: list[Fix] = []

    # A runnable source gets its own concrete fix first — history still backs it.
    local = LOCAL_FIXES.get(diagnosis.signature) if record.platform == "local_demo" else None
    if local:
        prior = stats["actions"][0] if stats["actions"] else None
        fixes.append(Fix(
            action=local["action"], tool=local["tool"],
            tool_args={"pipeline": record.pipeline, "activity": record.activity,
                       "run_id": record.run_id, "apply_fix": True},
            success_rate=prior["success_rate"] if prior else 0.0,
            attempts_seen=prior["attempts"] if prior else 0,
            median_ttr_min=prior["median_ttr_min"] if prior else None,
            rationale=(local["detail"] + (
                f" The same signature was resolved by a cast fix "
                f"{prior['successes']} of {prior['attempts']} time(s) on other "
                f"platforms." if prior else "")),
            evidence=[Evidence("resolution", ref, local["action"])
                      for ref in (prior["refs"][:2] if prior else [])]))

    for a in stats["actions"]:
        tool = a["tool"] or (play["tool"] if play else None)
        args = play["args"](record) if play else {}
        rationale = (f"Worked {a['successes']} of {a['attempts']} time(s) on this "
                     f"signature. Last tried {a['last_seen'][:10]} by {a['last_by']}.")
        if a["median_ttr_min"]:
            rationale += f" Median time to resolve: {a['median_ttr_min']:.0f} min."
        if a["notes"]:
            rationale += f" Note: {a['notes']}"
        fixes.append(Fix(
            action=a["action"], tool=tool, tool_args=args,
            success_rate=a["success_rate"], attempts_seen=a["attempts"],
            median_ttr_min=a["median_ttr_min"], rationale=rationale,
            evidence=[Evidence("resolution", ref, a["action"]) for ref in a["refs"]]))

    if not fixes:
        fixes.append(Fix(
            action="No recorded fix for this signature — first occurrence",
            tool="notify", tool_args={"channel": f"#{record.pipeline}",
                                      "summary": diagnosis.root_cause},
            success_rate=0.0, attempts_seen=0, median_ttr_min=None,
            rationale="This signature has no history yet. Once resolved, the "
                      "outcome is written back and the next occurrence is answered "
                      "from memory.",
            evidence=[]))
    # The learning loop can record the same action text the local fix uses;
    # keep the first (richest) occurrence so the list never repeats itself.
    seen: set[str] = set()
    deduped: list[Fix] = []
    for f in fixes:
        key = f.action.strip().lower()
        if key not in seen:
            seen.add(key)
            deduped.append(f)
    return deduped[:top_n]
