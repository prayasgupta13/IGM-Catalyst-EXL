"""The learning loop — the answer to 'limited knowledge reuse'.

The business case gives us logs, execution history and error messages. It does
NOT give us a runbook library or a resolved-ticket export. So the knowledge base
has to build itself: every failure resolved through the assistant is appended
here with its outcome, and the next occurrence of that signature is answered
from memory instead of re-reasoned.

Stored as JSON so a data engineer can read, diff and version-control it. Swap
for a table when it outgrows a file — the interface is three functions.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from statistics import median
from typing import Any

from .config import path


def _file() -> Path:
    p = path("knowledge", "resolutions")
    p.parent.mkdir(parents=True, exist_ok=True)
    if not p.exists():
        p.write_text("[]")
    return p


def all_resolutions() -> list[dict[str, Any]]:
    return json.loads(_file().read_text())


def for_signature(signature: str) -> list[dict[str, Any]]:
    """Everything we have ever tried for this signature, newest first."""
    rows = [r for r in all_resolutions() if r["signature"] == signature]
    return sorted(rows, key=lambda r: r["resolved_at"], reverse=True)


def stats_for(signature: str) -> dict[str, Any]:
    """Aggregate by action, so the recommender can rank on observed evidence."""
    rows = for_signature(signature)
    by_action: dict[str, list[dict[str, Any]]] = {}
    for r in rows:
        by_action.setdefault(r["action"], []).append(r)

    out = []
    for action, items in by_action.items():
        wins = [i for i in items if i["outcome"] == "success"]
        ttrs = [i["time_to_resolve_min"] for i in wins if i.get("time_to_resolve_min")]
        out.append({
            "action": action,
            "tool": items[0].get("action_tool"),
            "attempts": len(items),
            "successes": len(wins),
            "success_rate": len(wins) / len(items),
            "median_ttr_min": median(ttrs) if ttrs else None,
            "last_seen": items[0]["resolved_at"],
            "last_by": items[0]["resolved_by"],
            "refs": [i["resolution_id"] for i in items[:3]],
            "notes": next((i["notes"] for i in items if i.get("notes")), ""),
        })
    # best success rate first; break ties on how much evidence backs it
    out.sort(key=lambda a: (a["success_rate"], a["attempts"]), reverse=True)
    return {"signature": signature, "total_records": len(rows), "actions": out}


def record_outcome(signature: str, run_id: str, action: str, tool: str | None,
                   outcome: str, resolved_by: str,
                   time_to_resolve_min: float | None = None,
                   notes: str = "") -> dict[str, Any]:
    """Write back. This is the step that makes the system cheaper over time.

    Note that FAILED attempts are recorded too — that is what lets the
    recommender rank 'rerun with no change' below 'reduce parallelism'.
    """
    rows = all_resolutions()
    entry = {
        "resolution_id": f"RES-{len(rows) + 1:04d}",
        "signature": signature,
        "run_id": run_id,
        "action": action,
        "action_tool": tool,
        "outcome": outcome,
        "resolved_by": resolved_by,
        "resolved_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "time_to_resolve_min": time_to_resolve_min,
        "notes": notes,
    }
    rows.append(entry)
    _file().write_text(json.dumps(rows, indent=2))
    return entry


def coverage() -> dict[str, Any]:
    """How much of the failure population the knowledge base can now answer."""
    rows = all_resolutions()
    sigs = {r["signature"] for r in rows}
    return {"resolutions": len(rows), "signatures_covered": len(sigs),
            "covered": sorted(sigs)}
