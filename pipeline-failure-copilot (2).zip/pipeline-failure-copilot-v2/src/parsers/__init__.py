from .base import REGISTRY, LogParser  # noqa: F401
from . import adf, airflow, databricks, local_demo  # noqa: F401  (populates REGISTRY)


def for_source(source: str) -> LogParser | None:
    """Look the parser up by source id — folders decide, not filenames."""
    return REGISTRY.get(source)
