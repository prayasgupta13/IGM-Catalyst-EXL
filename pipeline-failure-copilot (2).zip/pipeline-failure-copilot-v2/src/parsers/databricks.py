"""Databricks job logs: `source` distinguishes driver from executor, and the
useful error is often on an executor line before the driver's summary."""
from __future__ import annotations

from typing import Any

from .base import LogParser, register


@register
class DatabricksParser(LogParser):
    platform = "databricks"

    def run_key(self, line: dict[str, Any]) -> str:
        return str(line.get("run_id", ""))

    def is_error(self, line: dict[str, Any]) -> bool:
        return str(line.get("level", "")).upper() in {"ERROR", "FATAL"}
