"""Airflow task logs: run_id lives in `run_id`, severity in `level`."""
from __future__ import annotations

from typing import Any

from .base import LogParser, register


@register
class AirflowParser(LogParser):
    platform = "airflow"

    def run_key(self, line: dict[str, Any]) -> str:
        return str(line.get("run_id", ""))

    def is_error(self, line: dict[str, Any]) -> bool:
        return str(line.get("level", "")).upper() in {"ERROR", "CRITICAL", "FATAL"}
