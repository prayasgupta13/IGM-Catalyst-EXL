"""ADF activity logs: run id is `runId`, severity words are capitalised
('Error' not 'ERROR'), and there is a `category` instead of a logger."""
from __future__ import annotations

from typing import Any

from .base import LogParser, register


@register
class ADFParser(LogParser):
    platform = "adf"

    def run_key(self, line: dict[str, Any]) -> str:
        return str(line.get("runId", ""))

    def is_error(self, line: dict[str, Any]) -> bool:
        return str(line.get("level", "")).lower() in {"error", "critical"}
