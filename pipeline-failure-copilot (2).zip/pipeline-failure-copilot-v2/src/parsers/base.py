"""Log parser contract.

Each platform writes JSON logs with different field names. A parser's only job
is to answer three questions about a log file:

    which run is this?        -> run_key()
    which lines are errors?   -> is_error()
    what did the line say?    -> message()

Everything after that — windowing, redaction, joining to execution history —
is common code. That is why onboarding a new orchestrator is ~30 lines.
"""
from __future__ import annotations

import abc
import json
from pathlib import Path
from typing import Any, Iterator

from ..security import redact, window


class LogParser(abc.ABC):
    platform: str = "unknown"

    # ---- the three platform-specific bits ---------------------------------
    @abc.abstractmethod
    def run_key(self, line: dict[str, Any]) -> str: ...

    @abc.abstractmethod
    def is_error(self, line: dict[str, Any]) -> bool: ...

    def message(self, line: dict[str, Any]) -> str:
        return str(line.get("message", ""))

    def timestamp(self, line: dict[str, Any]) -> str:
        return str(line.get("ts", ""))

    # ---- common: everyone gets windowing + redaction for free -------------
    @staticmethod
    def read_jsonl(path: str | Path) -> list[dict[str, Any]]:
        out = []
        for i, raw in enumerate(Path(path).read_text().splitlines(), 1):
            if not raw.strip():
                continue
            try:
                out.append(json.loads(raw))
            except json.JSONDecodeError:
                # A malformed line is skipped loudly, never silently inferred.
                print(f"  ! {Path(path).name}:{i} is not valid JSON — skipped")
        return out

    @staticmethod
    def _relative(path: str | Path) -> str:
        """Store repo-relative paths — an absolute path leaks the host layout
        into the warehouse and into anything the assistant renders."""
        from ..config import ROOT
        p = Path(path).resolve()
        try:
            return str(p.relative_to(ROOT))
        except ValueError:
            return p.name

    def parse(self, path: str | Path) -> dict[str, Any]:
        """Return {run_id, log_window (redacted), lines_total, redacted_counts}."""
        lines = self.read_jsonl(path)
        if not lines:
            return {}

        rendered = [f"{self.timestamp(l)} [{l.get('level', '?')}] {self.message(l)}"
                    for l in lines]
        first_error = next((i for i, l in enumerate(lines) if self.is_error(l)),
                           len(lines) - 1)

        # window BEFORE redact: cheaper, and the window is what we keep
        raw_window = window(rendered, first_error)
        clean, hits = redact(raw_window)

        return {
            "run_id": self.run_key(lines[0]),
            "platform": self.platform,
            "log_window": clean,
            "log_lines_total": len(lines),
            "redacted_counts": hits,
            "log_file": self._relative(path),
        }


REGISTRY: dict[str, LogParser] = {}


def register(cls: type[LogParser]) -> type[LogParser]:
    REGISTRY[cls.platform] = cls()
    return cls
