"""Parser for the local demo job.

Proof that constraint 3 is real: the demo job is a fourth 'platform' and
onboarding it took exactly this file plus one block in config.yaml. No agent,
prompt, schema or evaluation change.
"""
from __future__ import annotations

from typing import Any

from .base import LogParser, register


@register
class LocalDemoParser(LogParser):
    platform = "local_demo"

    def run_key(self, line: dict[str, Any]) -> str:
        return str(line.get("run_id", ""))

    def is_error(self, line: dict[str, Any]) -> bool:
        return str(line.get("level", "")).upper() in {"ERROR", "FATAL"}
