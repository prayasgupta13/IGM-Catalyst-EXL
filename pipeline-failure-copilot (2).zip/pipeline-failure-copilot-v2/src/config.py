"""Config loader. One YAML file; paths resolve against the repo root."""
from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[1]
CONFIG_PATH = Path(os.getenv("COPILOT_CONFIG", ROOT / "config" / "config.yaml"))


@lru_cache(maxsize=1)
def load() -> dict[str, Any]:
    cfg = yaml.safe_load(CONFIG_PATH.read_text())
    if v := os.getenv("COPILOT_EXECUTION_ENABLED"):
        cfg["rbac"]["execution"]["enabled"] = v.lower() in {"1", "true", "yes"}
    if v := os.getenv("COPILOT_LLM_PROVIDER"):
        cfg["llm"]["provider"] = v
    return cfg


def path(section: str, key: str) -> Path:
    return ROOT / str(load()[section][key])


def sources() -> dict[str, dict[str, Any]]:
    return load()["sources"]
