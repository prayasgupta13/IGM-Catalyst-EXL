"""Requirement 7 — every execution captured to CSV.

One row per thing the assistant did: a question answered, an action previewed,
an action approved and run. Open it in Excel; it is the operational record of
the assistant's own behaviour.

Columns are chosen so the CSV answers the business-case metrics directly:
MTTR contributions, abstention rate, which signatures recur, who approved what.
"""
from __future__ import annotations

import csv
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import path

FIELDS = [
    "execution_id", "timestamp_utc", "event_type", "user", "role",
    "question", "source_system", "pipeline", "activity", "run_id",
    "signature", "confidence", "abstained",
    "evidence_count", "recommended_action", "action_tool",
    "decision", "outcome", "duration_ms", "rows_affected", "output_file", "notes",
]


def _file() -> Path:
    p = path("outputs", "execution_log")
    p.parent.mkdir(parents=True, exist_ok=True)
    if not p.exists():
        with p.open("w", newline="") as fh:
            csv.DictWriter(fh, fieldnames=FIELDS).writeheader()
    return p


def record(event_type: str, **fields: Any) -> str:
    """Append one row. Unknown keys are dropped, missing ones blank."""
    execution_id = fields.pop("execution_id", None) or f"EX-{uuid.uuid4().hex[:8]}"
    row = {k: "" for k in FIELDS}
    row.update({k: v for k, v in fields.items() if k in FIELDS})
    row["execution_id"] = execution_id
    row["event_type"] = event_type
    row["timestamp_utc"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    with _file().open("a", newline="") as fh:
        csv.DictWriter(fh, fieldnames=FIELDS).writerow(row)
    return execution_id


def read_all() -> list[dict[str, str]]:
    p = _file()
    with p.open(newline="") as fh:
        return list(csv.DictReader(fh))


def summary() -> dict[str, Any]:
    """The numbers the business case asks for, computed from this CSV."""
    rows = read_all()
    queries = [r for r in rows if r["event_type"] == "query"]
    executed = [r for r in rows if r["event_type"] == "action_executed"]
    refused = [r for r in rows if r["event_type"] == "action_refused"]
    abstained = [r for r in queries if r["abstained"] == "True"]
    latencies = [float(r["duration_ms"]) for r in queries if r["duration_ms"]]
    sigs: dict[str, int] = {}
    for r in queries:
        if r["signature"]:
            sigs[r["signature"]] = sigs.get(r["signature"], 0) + 1
    return {
        "total_executions": len(rows),
        "questions_answered": len(queries),
        "abstained": len(abstained),
        "abstention_rate": round(len(abstained) / len(queries), 3) if queries else 0.0,
        "actions_executed": len(executed),
        "actions_refused": len(refused),
        "mean_answer_ms": round(sum(latencies) / len(latencies), 1) if latencies else 0.0,
        "signatures_seen": dict(sorted(sigs.items(), key=lambda kv: -kv[1])),
        "csv_path": str(_file()),
    }
