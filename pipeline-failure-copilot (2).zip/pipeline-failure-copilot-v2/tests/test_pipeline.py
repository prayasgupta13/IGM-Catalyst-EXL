"""End-to-end tests over the three inputs."""
from __future__ import annotations

import pytest


class TestIngestion:
    def test_joins_all_three_inputs(self, warehouse):
        row = warehouse.execute(
            "SELECT * FROM fact_failure WHERE run_id='4471'").fetchone()
        assert row["pipeline"] == "customer_billing_load"      # execution history
        assert row["error_code"] == "SPARK_ANALYSIS_EXCEPTION"  # error messages
        assert "AnalysisException" in row["log_window"]         # pipeline logs

    def test_run_without_a_log_file_still_produces_a_record(self, warehouse):
        row = warehouse.execute("SELECT * FROM fact_failure WHERE run_id='4102'").fetchone()
        assert row is not None and row["log_file"] is None
        assert row["signature"] == "schema_drift.type_mismatch.timestamp"

    def test_only_failed_runs_are_loaded(self, warehouse):
        statuses = {r["status"] for r in
                    warehouse.execute("SELECT DISTINCT status FROM fact_failure")}
        assert statuses == {"failed"}

    def test_derived_flags_are_computed(self, warehouse):
        row = warehouse.execute("SELECT * FROM fact_failure WHERE run_id='af-88213'").fetchone()
        assert row["exhausted_retries"] == 1   # attempt 4 of 4
        assert row["breached_sla"] == 0        # 31 min against a 45 min SLA


class TestSignatures:
    @pytest.mark.parametrize("message,code,expected", [
        ("cannot cast string to timestamp", "SPARK_ANALYSIS_EXCEPTION",
         "schema_drift.type_mismatch.timestamp"),
        ("REQUEST_LIMIT_EXCEEDED (HTTP 429)", "UserErrorSalesforceThrottled",
         "throttling.rate_limit.429"),
        ("Container killed by YARN for exceeding memory limits", "EXECUTOR_LOST",
         "resource.oom.executor"),
        ("was deadlocked on lock resources", "SQL_DEADLOCK", "db.deadlock"),
    ])
    def test_known_errors_classify(self, message, code, expected):
        from src.signatures import classify
        sig, matched, _ = classify(message, code)
        assert matched and sig == expected

    def test_fingerprint_survives_run_specific_noise(self):
        from src.signatures import classify
        a, _, _ = classify("Widget exploded id 0xAA at 2026-01-01T00:00:00Z after 41 rows")
        b, _, _ = classify("Widget exploded id 0xBB at 2026-02-02T11:11:11Z after 993 rows")
        assert a == b, "two occurrences of the same novel error must cluster"


class TestRecommender:
    def test_ranks_by_observed_success_not_by_recency(self):
        from src.knowledge import stats_for
        actions = stats_for("throttling.rate_limit.429")["actions"]
        assert actions[0]["success_rate"] == 1.0
        assert "parallelCopies" in actions[0]["action"]
        assert actions[-1]["success_rate"] == 0.0, "a failed fix must rank last"

    def test_failed_attempts_are_kept_in_the_knowledge_base(self):
        from src.knowledge import for_signature
        outcomes = {r["outcome"] for r in for_signature("resource.oom.executor")}
        assert "failed" in outcomes, "we keep what did NOT work — that is the ranking signal"


class TestLearningLoop:
    def test_write_back_makes_the_next_occurrence_cheaper(self, tmp_path, monkeypatch):
        import json
        from src import knowledge
        store = tmp_path / "res.json"
        store.write_text("[]")
        monkeypatch.setattr(knowledge, "_file", lambda: store)

        assert knowledge.stats_for("novel.signature")["total_records"] == 0
        knowledge.record_outcome("novel.signature", "9999", "Bounce the cluster",
                                 "rerun", "success", "p.gupta", 30)
        stats = knowledge.stats_for("novel.signature")
        assert stats["total_records"] == 1
        assert stats["actions"][0]["success_rate"] == 1.0


class TestEndToEnd:
    def test_flagship_question(self, engineer):
        from src.agents import ask
        ans = ask("Why did the customer billing load fail last night?", engineer)
        assert ans.record_.run_id == "4471"
        assert ans.diagnosis.signature == "schema_drift.type_mismatch.timestamp"
        assert not ans.diagnosis.abstained
        assert ans.fixes[0].success_rate == 1.0
        assert ans.plan is not None
        assert ans.plan.preview, "the proposal must show what would happen"
        assert not ans.plan.can_execute, "no live Airflow integration is configured"

    def test_demo_job_can_be_rerun_end_to_end(self, engineer_approved):
        """Requirement 5+6: preview, approve, real re-run, success log."""
        from src.agents import approve_and_run, ask
        ans = ask("why did orders_export fail", engineer_approved)
        assert ans.plan.can_execute, "the demo source must be executable"
        assert len(ans.plan.preview) >= 3, "the user must see what will happen"
        result = approve_and_run(ans, engineer_approved)
        assert result["status"] == "success"
        assert result["rows_written"] == 10 and result["coerced"] == 3
        assert result["output_file"].endswith(".csv")
        assert result.get("knowledge_entry"), "the outcome must be written back"

    def test_every_execution_lands_in_the_csv(self, engineer):
        from src.agents import ask
        from src.execution_log import read_all
        before = len(read_all())
        ask("why did orders_export fail", engineer)
        assert len(read_all()) == before + 1

    def test_lineage_points_upstream(self, engineer):
        from src.agents import ask
        ans = ask("Why did the customer billing load fail last night?", engineer)
        lineage = [e for e in ans.diagnosis.evidence if e.source == "lineage"]
        assert lineage and "crm_ingest" in lineage[0].detail

    def test_downstream_impact_is_transitive(self, engineer):
        from src.agents import ask
        ans = ask("Why did the customer billing load fail last night?", engineer)
        assert any("exec_dashboard" in i for i in ans.impact), "must walk >1 hop"

    def test_replay_has_no_false_confidence(self):
        from src.evaluate import run
        r = run()
        assert r.cases >= 10
        assert r.wrong == 0, "confidently wrong is the failure mode that matters"
        assert r.precision_at_1 >= 0.9
