"""Success criterion: effective conversational experience.

The two properties that make a conversation useful operationally:
follow-ups bind to the run in focus, and they cost almost nothing because
they answer from context rather than re-running the agent loop.
"""
from __future__ import annotations

import pytest

from src.conversation import Intent, classify_intent, get_session, respond
from src.security import Principal

ENGINEER = Principal("p.gupta", "data_engineer")
VIEWER = Principal("v.viewer", "viewer")


@pytest.fixture
def chat():
    return get_session(None)


@pytest.fixture
def chat_with_focus(chat):
    respond(chat, "why did orders_export fail", ENGINEER)
    return chat


class TestIntentRouting:
    @pytest.mark.parametrize("text,expected", [
        ("how confident are you?", Intent.EXPLAIN_CONFIDENCE),
        ("show me the log", Intent.SHOW_LOG),
        ("what caused it upstream?", Intent.UPSTREAM),
        ("what does this affect?", Intent.DOWNSTREAM),
        ("has this happened before?", Intent.HISTORY),
        ("how was it fixed?", Intent.FIXES),
        ("re-run it", Intent.RERUN),
        ("where did that come from?", Intent.EVIDENCE),
    ])
    def test_follow_ups_route_correctly(self, text, expected):
        assert classify_intent(text, has_context=True) is expected

    def test_fix_wording_outranks_history_wording(self):
        """'how was it fixed last time' contains both cues — fixes must win."""
        assert classify_intent("how was it fixed last time?", True) is Intent.FIXES

    def test_without_context_everything_is_a_new_question(self):
        assert classify_intent("how confident are you?", False) is Intent.NEW_QUESTION

    def test_unrecognised_text_becomes_a_new_question_not_a_guess(self):
        assert classify_intent("what about the warehouse capacity", True) is Intent.NEW_QUESTION


class TestContextBinding:
    def test_first_question_sets_the_focus(self, chat):
        respond(chat, "why did orders_export fail", ENGINEER)
        assert chat.has_context
        assert "orders_export" in chat.focus

    def test_follow_up_keeps_the_same_run_in_focus(self, chat_with_focus):
        before = chat_with_focus.answer.record_.run_id
        respond(chat_with_focus, "has this happened before?", ENGINEER)
        assert chat_with_focus.answer.record_.run_id == before

    def test_a_new_question_rebinds_the_focus(self, chat_with_focus):
        respond(chat_with_focus, "why did the customer billing load fail", ENGINEER)
        assert chat_with_focus.answer.record_.run_id == "4471"

    def test_bare_pronoun_is_never_treated_as_a_new_search(self, chat_with_focus):
        turn = respond(chat_with_focus, "that", ENGINEER)
        assert turn.used_context and turn.intent != Intent.NEW_QUESTION.value


class TestFollowUpsAreCheap:
    def test_follow_ups_answer_from_context(self, chat_with_focus):
        for msg in ["how confident are you?", "what does this affect?",
                    "has this happened before?", "how was it fixed?"]:
            turn = respond(chat_with_focus, msg, ENGINEER)
            assert turn.used_context, f"{msg} should not re-run retrieval"

    def test_confidence_breakdown_sums_to_the_stated_score(self, chat_with_focus):
        turn = respond(chat_with_focus, "how confident are you?", ENGINEER)
        card = turn.cards[0]
        assert abs(sum(p["value"] for p in card["parts"]) - card["total"]) < 0.02


class TestConstraintsHoldInConversation:
    def test_viewer_is_refused_the_log_mid_conversation(self, chat):
        respond(chat, "why did orders_export fail", VIEWER)
        turn = respond(chat, "show me the log", VIEWER)
        assert "read:logs" in turn.text

    def test_rerun_follow_up_previews_rather_than_executing(self, chat_with_focus):
        turn = respond(chat_with_focus, "re-run it", ENGINEER)
        card = turn.cards[0]
        assert card["type"] == "preview"
        assert card["plan"]["preview"], "the user must see the steps first"

    def test_read_only_source_says_so_in_conversation(self, chat):
        respond(chat, "why did the customer billing load fail", ENGINEER)
        turn = respond(chat, "re-run it", ENGINEER)
        assert "cannot execute" in turn.text.lower() or not turn.cards[0]["executable"]


class TestExecutionLogging:
    def test_follow_ups_are_logged_with_their_intent(self, chat_with_focus):
        from src.execution_log import read_all
        before = len(read_all())
        respond(chat_with_focus, "has this happened before?", ENGINEER)
        rows = read_all()
        assert len(rows) == before + 1
        assert rows[-1]["event_type"] == "follow_up"
        assert rows[-1]["outcome"] == "history"
