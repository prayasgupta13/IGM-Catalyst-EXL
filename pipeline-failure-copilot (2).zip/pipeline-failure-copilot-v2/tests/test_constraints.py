"""One test class per constraint from the business case slide."""
from __future__ import annotations

import pytest

from src.parsers import for_source
from src.security import Principal, check_action, guard, redact, window
from src.signatures import classify


class TestConstraint1_SecureProductionData:
    def test_jdbc_connection_string_is_stripped(self):
        clean, hits = redact("jdbc:sqlserver://crm-prod:1433;user=svc;password=S3cret!;")
        assert "S3cret" not in clean and "crm-prod" not in clean
        assert "JDBC_CONN" in hits

    def test_bearer_token_is_stripped(self):
        clean, hits = redact("Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.abcdefgh.sig123")
        assert "eyJ" not in clean and hits

    def test_email_and_ip_are_stripped(self):
        clean, _ = redact("paging oncall-data@exl.com from 10.2.3.4")
        assert "@exl.com" not in clean and "10.2.3.4" not in clean

    def test_redaction_is_idempotent(self):
        once, _ = redact("password=hunter2 token=abc123def")
        twice, _ = redact(once)
        assert once == twice, "stored windows are re-checked; re-running must not re-fire"

    def test_model_boundary_guard_blocks_raw_secrets(self):
        with pytest.raises(ValueError, match="unredacted"):
            guard("password=hunter2")

    def test_model_boundary_guard_passes_clean_text(self):
        clean, _ = redact("password=hunter2")
        guard(clean)

    def test_log_window_does_not_load_the_whole_file(self):
        lines = [f"line {i}" for i in range(500)]
        out = window(lines, first_error_idx=250)
        assert len(out.splitlines()) <= 6
        assert "line 250" in out and "line 0" not in out

    def test_ingested_log_window_contains_no_raw_secret(self):
        out = for_source("airflow").parse(
            "inputs/pipeline_logs/airflow/airflow_customer_billing_load_4471.jsonl")
        assert "Str0ngP@ssw0rd" not in out["log_window"]
        assert "@exl.com" not in out["log_window"]


class TestConstraint2_ExplainableResponses:
    def test_every_answer_carries_evidence(self, engineer):
        from src.agents import ask
        ans = ask("Why did the customer billing load fail last night?", engineer)
        assert ans.diagnosis.evidence, "an answer with no evidence must not be produced"
        assert len(ans.diagnosis.evidence) >= 2

    def test_evidence_spans_all_three_inputs(self, engineer):
        from src.agents import ask
        ans = ask("Why did the customer billing load fail last night?", engineer)
        sources = {e.source for e in ans.diagnosis.evidence}
        assert {"execution_history", "error_message", "pipeline_log"} <= sources

    def test_confidence_formula_is_reproducible_by_hand(self):
        from src.agents.diagnostician import score
        # known signature .30 + 3 priors (.30) + 2 resolutions (.24) + upstream .08 + log .05
        assert score(True, 3, 2, True, True) == 0.97
        assert score(False, 0, 0, False, False) == 0.08

    def test_abstains_rather_than_guessing(self, engineer):
        from src.agents import ask
        ans = ask("inventory sync upsert_stock deadlock", engineer)
        assert ans.diagnosis.abstained
        assert "threshold" in ans.diagnosis.abstain_reason

    def test_novel_error_is_not_claimed_as_known(self):
        sig, matched, _ = classify("Gremlin ate the parquet footer 0xDEAD")
        assert not matched and sig.startswith("unclassified.")


class TestConstraint3_CloudAgnostic:
    @pytest.mark.parametrize("source,filename,expected_run", [
        ("airflow", "airflow_customer_billing_load_4471.jsonl", "4471"),
        ("adf", "adf_crm_ingest_af-88213.jsonl", "af-88213"),
        ("databricks", "databricks_revenue_mart_992301.jsonl", "992301"),
    ])
    def test_every_platform_yields_the_same_shape(self, source, filename, expected_run):
        out = for_source(source).parse(f"inputs/pipeline_logs/{source}/{filename}")
        assert set(out) == {"run_id", "platform", "log_window", "log_lines_total",
                            "redacted_counts", "log_file"}
        assert out["run_id"] == expected_run

    def test_platforms_use_different_field_names(self):
        """The whole point: airflow says run_id, ADF says runId, and the agents
        never learn either."""
        from src.parsers import REGISTRY
        assert REGISTRY["airflow"].run_key({"run_id": "1"}) == "1"
        assert REGISTRY["adf"].run_key({"runId": "1"}) == "1"

    def test_severity_casing_differs_per_platform(self):
        from src.parsers import REGISTRY
        assert REGISTRY["airflow"].is_error({"level": "ERROR"})
        assert REGISTRY["adf"].is_error({"level": "Error"})

    def test_fact_table_rows_are_platform_uniform(self, warehouse):
        rows = warehouse.execute(
            "SELECT platform, COUNT(*) n FROM fact_failure GROUP BY platform").fetchall()
        assert {"airflow", "adf", "databricks"} <= {r["platform"] for r in rows}

    def test_the_demo_job_onboarded_as_a_fourth_source(self):
        """A whole new 'platform' cost one parser file + one config block."""
        from src.config import sources
        assert "local_demo" in sources()
        assert for_source("local_demo") is not None


class TestConstraint4_ValidRoles:
    def test_read_role_cannot_backfill(self, execution_on):
        v = check_action(Principal("l2", "support_l2", approved_by="l2"), "backfill")
        assert not v.allowed and "lacks" in v.reason

    def test_engineer_can_backfill_when_approved(self, execution_on):
        v = check_action(Principal("p", "data_engineer", approved_by="p"), "backfill")
        assert v.allowed

    def test_action_requires_explicit_approval(self, execution_on):
        v = check_action(Principal("p", "data_engineer"), "backfill")
        assert not v.allowed and "approval" in v.reason

    def test_execution_switch_off_blocks_everything(self, execution_off):
        v = check_action(Principal("p", "data_engineer", approved_by="p"), "backfill")
        assert not v.allowed and "disabled" in v.reason

    def test_unknown_tool_is_refused(self, execution_on):
        v = check_action(Principal("p", "data_engineer", approved_by="p"), "rm_minus_rf")
        assert not v.allowed and "not in the configured action list" in v.reason

    def test_approval_token_cannot_be_replayed(self, execution_on):
        from src.agents.operator import Plan, execute
        plan = Plan("rerun", {"pipeline": "p", "activity": "a"}, "because",
                    source="local_demo", can_execute=True)
        with pytest.raises(PermissionError, match="does not match"):
            execute(plan, Principal("p", "data_engineer", approved_by="p"), "wrong-token")

    def test_read_only_source_cannot_be_rerun(self, execution_on):
        """Honest boundary: no live ADF integration means no execution, ever."""
        from src.agents.operator import execute, propose
        plan = propose("rerun", {"pipeline": "crm_ingest", "activity": "Copy"},
                       "because", source="adf")
        assert not plan.can_execute
        with pytest.raises(PermissionError, match="integration"):
            execute(plan, Principal("p", "data_engineer", approved_by="p"), plan.plan_id)

    def test_role_without_read_logs_never_sees_log_text(self, viewer):
        from src.agents.retriever import retrieve
        records, _ = retrieve("customer billing load", viewer)
        assert all("withheld" in r.log_window for r in records)
