from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)


@pytest.fixture(scope="session", autouse=True)
def warehouse_built():
    """Make the demo job fail once, then build the fact table."""
    from src.demo_job import job
    from src.ingest import run
    job.run(apply_fix=False, run_id="test-fail-001")
    run(verbose=False)


@pytest.fixture
def warehouse():
    from src.ingest import connect
    conn = connect()
    yield conn
    conn.close()


@pytest.fixture
def engineer():
    from src.security import Principal
    return Principal("p.gupta", "data_engineer")


@pytest.fixture
def engineer_approved():
    from src.security import Principal
    return Principal("p.gupta", "data_engineer", approved_by="p.gupta")


@pytest.fixture
def viewer():
    from src.security import Principal
    return Principal("v.viewer", "viewer")


@pytest.fixture
def execution_on(monkeypatch):
    from src.config import load
    monkeypatch.setitem(load()["rbac"]["execution"], "enabled", True)
    yield


@pytest.fixture
def execution_off(monkeypatch):
    from src.config import load
    monkeypatch.setitem(load()["rbac"]["execution"], "enabled", False)
    yield
