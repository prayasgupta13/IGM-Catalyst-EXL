# Agentic AI Assistant for Intelligent Pipeline Failure Analysis

**EXL IGM Catalyst — Team 10**

```bash
make setup && source .venv/bin/activate
make demo          # makes the demo job fail, then opens the web UI
```

Then open **http://127.0.0.1:8000** and ask *"why did orders_export fail"*.

---

## The folder structure is the explanation

```
inputs/                          ← ONLY the three inputs from the business case
  pipeline_logs/
    airflow/       *.jsonl       one folder per source system
    adf/           *.jsonl
    databricks/    *.jsonl
    local_demo/    *.jsonl       written by the runnable demo job
  execution_history/
    airflow.json  adf.json  databricks.json  local_demo.json
  error_messages/
    airflow.json  adf.json  databricks.json  local_demo.json
  raw_data/orders.json           what the demo job actually reads
  labels.json                    ground truth for the replay harness

outputs/                         ← everything the assistant produces
  warehouse/failures.db          normalized fact table
  executions/copilot_executions.csv    every execution, one row each
  demo_job/orders_<run>.csv      the CSV a successful re-run produces

knowledge/resolutions.json       the learning loop store

app/                             the web layer (Python stdlib only)
src/                             agents, parsers, ETL, security
config/config.yaml               all four constraints, in one readable file
```

Adding a source system = **one folder + one parser + one config block.** Nothing
else changes. The `local_demo` source is the proof: it was onboarded as a fourth
platform and cost exactly `src/parsers/local_demo.py` (12 lines) plus 5 lines of
YAML.

---

## The live demo: a job that really fails, and really gets fixed

Every other source is read-only — no live ADF/Airflow/Databricks API is wired
up, and the UI says so rather than pretending. So there is one source that
**does** execute, end to end:

**`orders_export.json_to_csv`** reads `inputs/raw_data/orders.json`, casts the
columns and writes a CSV. Seven rows have ISO-8601 timestamps; three use the
legacy `dd/MM/yyyy` format. In strict mode the cast fails.

```bash
python -m src.cli demo-fail
#   [ERROR] cannot resolve 'order_ts' due to data type mismatch:
#           cannot cast string to timestamp (value='09/08/2026 05:12:00')
#   [INFO]  Marking run as FAILED
```

That failure writes a real JSON log into `inputs/pipeline_logs/local_demo/`, a
real execution-history row and a real error-message row. The assistant then
reads it like any other source.

**In the web UI:**

1. Ask *"why did orders_export fail"*
2. Get the root cause at **confidence 0.89**, with evidence from all three
   inputs — and note that two of the evidence items come from **ADF and Airflow
   history**, because they share the same signature. The demo job has no history
   of its own; it borrows the platform's.
3. Click **Re-run the failed pipeline…** → the preview appears **before**
   anything runs:

   > • Apply the fix: enable dual-format timestamp parsing (ISO-8601 and legacy dd/MM/yyyy).
   > • Re-execute `orders_export.json_to_csv` against the same source file — the source is not modified.
   > • Write a NEW CSV to `outputs/demo_job/` with a new run id. Previous output files are left untouched.
   > • Emit a new JSON log file and a new execution-history row so the assistant can read the result back.
   > • Append the outcome to the knowledge base.
   >
   > **Rollback:** kill the triggered run; output goes to a new file.
   > **Requires permission:** `act:rerun` · **plan_id:** `3ac841d1524e`

4. Click **Approve and re-run** → the job actually executes. The UI shows the
   new log with `SUCCEEDED`, the row count, and a download link for the CSV.

**Try it as `support_l1` first.** The approval is refused with
`gate 3: role 'support_l1' lacks 'act:rerun'` — that's constraint 4, live.

---

## Every execution is captured to CSV

`outputs/executions/copilot_executions.csv`, one row per question, refusal and
action:

| execution_id | event_type | user | run_id | signature | confidence | decision | outcome | rows_affected |
|---|---|---|---|---|---|---|---|---|
| EX-a5478c26 | query | p.gupta | demo-0001 | schema_drift.type_mismatch.timestamp | 0.89 | | answered | |
| EX-… | action_refused | l1.support | demo-0001 | schema_drift… | | approved | gate 3: role 'support_l1' lacks 'act:rerun' | |
| EX-… | action_executed | p.gupta | demo-0001 | schema_drift… | | approved | success | 10 |

The **View execution log** button in the sidebar renders it. `python -m src.cli
executions` prints the aggregates — abstention rate, actions executed vs
refused, mean answer time.

---

## The four constraints

Read `config/config.yaml` — each is a labelled block.

| Constraint | Where | See it work |
|---|---|---|
| Secure production data | `src/security.py` — redact at ingest, guard at the model boundary, window the log | The ADF log's bearer token and the Airflow log's JDBC password never reach the warehouse |
| Explainable responses | Evidence on every claim; confidence is arithmetic you can redo by hand | The evidence block in the UI; ask about the deadlock and it **abstains** at 0.35 |
| Cloud agnostic | One parser per source, 3 methods each | Four sources, four log schemas, one fact table |
| Valid roles | 4 gates in `src/agents/operator.py` | Approve as `support_l1` → refused |

---

## Conversational experience

The UI is a chat, and follow-ups bind to the run already in focus — so you never
repeat yourself, and turn 2 costs ~0.1 ms because it answers from session
context instead of re-running the agent loop.

```
you  ▸ why did orders_export fail
AI   ▸ orders_export.json_to_csv (run demo-0001) failed …          [new retrieval · 3.2 ms]

you  ▸ how confident are you?
AI   ▸ Confidence is 0.89, and it is arithmetic …                  [from context · 0.1 ms]
         Known signature matched a rule                    +0.30
         2 prior occurrence(s) of this signature           +0.20
         2 recorded fix(es) for it                         +0.24
         Log window available for this run                 +0.05
                                                     Total  0.89

you  ▸ has this happened before?
AI   ▸ Yes — 3 other time(s), across 1 source system(s)            [from context · 0.6 ms]

you  ▸ re-run it
AI   ▸ Here is exactly what will happen …  [Approve and re-run]    [from context · 0.1 ms]
```

Recognised follow-ups: confidence breakdown, show the log, upstream cause,
downstream impact, history across sources, ranked fixes, evidence, re-run,
what sources can you see, and `help`. Anything unrecognised is treated as a new
question rather than guessed at — intent routing is deterministic keyword
matching, not a model call, so it is free and auditable.

Constraints still hold mid-conversation: ask as `viewer` and *"show me the log"*
returns `your role does not hold read:logs`.

## Flow

```
BROWSER                      SERVER                       FOLDERS
  ask ──────────────► /api/ask ──► Retriever ──────────► outputs/warehouse
                                    Diagnostician ─────► inputs/ (all three)
                                    Recommender ───────► knowledge/
                                    Operator (preview)
  ◄──── diagnosis + evidence + ranked fixes + preview
  click re-run ─────► /api/preview ──► exact actions, rollback, permission
  approve ──────────► /api/approve ──► 4 gates ──► job.py really runs
                                                   └─► outputs/demo_job/*.csv
                                                   └─► inputs/pipeline_logs/local_demo/
  ◄──── new log showing SUCCEEDED + CSV download
                       every step ──► outputs/executions/copilot_executions.csv
```

---

## Commands

```bash
make demo         # demo-fail + web
make web          # just the UI
make ingest       # inputs/ -> outputs/warehouse/failures.db
make ask          # CLI version of the web ask
make test         # 67 tests
make reset        # back to a clean clone
```

## Known limitations

- **Only `local_demo` executes.** ADF, Airflow and Databricks produce a plan and stop — the UI states the reason. Wiring a live API is one method per platform.
- **The mock LLM is the default.** It composes the answer from retrieved evidence, which proves the grounding is retrieval-driven. Set `COPILOT_LLM_PROVIDER=anthropic` with a key for natural phrasing.
- **Retrieval is keyword + signature**, not embeddings. Deterministic and auditable; a vector index fits behind the same interface.
