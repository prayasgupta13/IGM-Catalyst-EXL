let sessionId = null;
let hasFocus = false;
let turnCount = 0, ctxTurns = 0;

const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"]/g, c =>
  ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const role = () => $('role').value;

// tiny markdown: **bold**, `code`, · bullets, newlines
function md(s){
  return esc(s)
    .replace(/\*\*(.+?)\*\*/g, '<b>$1</b>')
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/\n/g, '<br>');
}

async function api(path, body){
  const r = await fetch(path, {method:'POST', headers:{'Content-Type':'application/json'},
                              body: JSON.stringify(body)});
  return {ok: r.ok, data: await r.json()};
}

const OPENERS = ['why did orders_export fail',
                 'why did the customer billing load fail last night',
                 'what happened with crm_ingest',
                 'what sources can you see?'];
const FOLLOWUPS = ['how confident are you?', 'has this happened before?',
                   'what does this affect?', 'show me the log',
                   'how was it fixed?', 're-run it'];

function renderChips(){
  const list = hasFocus ? FOLLOWUPS : OPENERS;
  $('chips').innerHTML = list.map(c =>
    `<span class="chip" onclick="setQ(this)">${esc(c)}</span>`).join('');
}
function setQ(el){ $('q').value = el.textContent.trim(); send(); }

function bubble(who, html, meta){
  const initials = who === 'user' ? 'You' : 'AI';
  return `<div class="msg ${who === 'user' ? 'user' : 'bot'}">
    <div class="who">${initials}</div>
    <div class="body">${html}${meta ? `<div class="meta">${meta}</div>` : ''}</div>
  </div>`;
}

function push(html){
  $('msgs').insertAdjacentHTML('beforeend', html);
  $('thread').scrollTop = $('thread').scrollHeight;
}

// ---------------------------------------------------------------- send
async function send(){
  const text = $('q').value.trim();
  if (!text) return;
  $('q').value = '';
  $('sendBtn').disabled = true;
  push(bubble('user', esc(text)));
  push(`<div class="msg bot" id="pending"><div class="who">AI</div>
        <div class="body"><span class="spin"></span>
        <span style="color:var(--slate);margin-left:7px">thinking…</span></div></div>`);

  const {data} = await api('/api/chat', {message:text, role:role(), session_id:sessionId});
  $('pending').remove();
  $('sendBtn').disabled = false;

  if (data.error){ push(bubble('bot', esc(data.error))); return; }
  sessionId = data.session_id;
  hasFocus = !!data.focus;
  updateFocus(data.focus);
  renderTurn(data.turn);
  renderChips();
  loadStats();
}

function renderTurn(t){
  turnCount++;
  if (t.used_context) ctxTurns++;
  const cards = (t.cards || []).map(renderCard).join('');
  const badge = t.used_context
    ? `<span class="ctx">answered from conversation context</span> · ${t.duration_ms} ms`
    : `new retrieval · ${t.duration_ms} ms`;
  push(bubble('bot', md(t.text) + cards, `${badge} · intent <code>${esc(t.intent)}</code>`));
}

function updateFocus(focus){
  $('focusBox').innerHTML = focus
    ? `<div class="focus"><span class="kicker" style="margin:0">In focus</span>
       <b>${esc(focus)}</b>Follow-ups resolve against this run.</div>`
    : '';
}

// --------------------------------------------------------------- cards
function renderCard(c){
  switch (c.type){
    case 'diagnosis':   return cardDiagnosis(c.answer);
    case 'confidence':  return cardConfidence(c);
    case 'log':         return cardLog(c);
    case 'evidence':    return cardEvidence(c.items);
    case 'impact':      return cardList(c.items);
    case 'history':     return cardHistory(c.items);
    case 'fixes':       return cardFixes(c.items);
    case 'preview':     return cardPreview(c);
    case 'result':      return cardResult(c);
    case 'sources':     return cardSources(c.items);
    default:            return '';
  }
}

function cardDiagnosis(a){
  const r = a.run, d = a.diagnosis;
  let h = `<div class="card"><div class="runhead">
      <span>run <b>${esc(r.run_id)}</b></span>
      <span>source <b>${esc(r.source_label)}</b></span>
      <span>attempt <b>${r.attempt}/${r.max_attempts}</b></span>
      <span>signature <b>${esc(d ? d.signature : '')}</b></span>
      <span>confidence <b>${d ? d.confidence : ''}</b></span>
    </div>`;
  if (d && d.abstained){
    h += `<div style="color:var(--slate);font-size:13px">${esc(d.abstain_reason)}</div>`;
  }
  h += cardEvidenceInner(d ? d.evidence.slice(0,4) : []);
  h += `</div>`;
  return h;
}

function cardEvidenceInner(items){
  if (!items || !items.length) return '';
  return `<div class="kicker" style="margin:12px 0 4px">Evidence</div>` +
    items.map(e => `<div class="ev">
      <div class="tag">${esc(e.source.replace(/_/g,' '))}</div>
      <div>${esc(e.detail)}</div>
      <div class="ref">${esc(e.ref)}</div></div>`).join('');
}
function cardEvidence(items){ return `<div class="card">${cardEvidenceInner(items)}</div>`; }

function cardConfidence(c){
  // scale each bar against the largest contribution so the differences read
  const max = Math.max(...c.parts.map(p => p.value), 0.01);
  const rows = c.parts.map(p => `<div class="bar">
      <span class="lbl">${esc(p.label)}</span>
      <span class="track"><span class="fill" style="width:${Math.max(6, Math.round(p.value/max*100))}%"></span></span>
      <span class="val">+${p.value.toFixed(2)}</span></div>`).join('');
  return `<div class="card">${rows}
    <div class="total"><span>Total</span><span>${c.total}</span></div>
    <div class="rollback">Threshold is ${c.threshold}. Below it the assistant abstains
      and escalates rather than guessing — ${c.abstained
        ? 'which is what happened here.' : 'this run cleared it.'}</div></div>`;
}

function cardLog(c){
  const colour = l => l.includes('[ERROR]') ? `<span class="e">${esc(l)}</span>`
                    : /\[WARN/.test(l) ? `<span class="w">${esc(l)}</span>`
                    : /SUCCEEDED/.test(l) ? `<span class="ok">${esc(l)}</span>`
                    : esc(l);
  const red = c.redacted && Object.keys(c.redacted).length
    ? `<div class="rollback">Redaction applied at ingest:
       <code>${esc(JSON.stringify(c.redacted))}</code></div>` : '';
  return `<div class="card"><pre class="log">${c.lines.map(colour).join('\n')}</pre>${red}</div>`;
}

function cardList(items){
  return `<div class="card"><ul class="plain">${
    items.map(i => `<li>${esc(i)}</li>`).join('')}</ul></div>`;
}

function cardHistory(items){
  return `<div class="card"><table><thead><tr>
      <th>run</th><th>source</th><th>pipeline</th><th>when</th></tr></thead><tbody>${
    items.map(i => `<tr><td>${esc(i.run_id)}</td><td>${esc(i.platform)}</td>
      <td>${esc(i.pipeline)}.${esc(i.activity)}</td>
      <td>${esc(String(i.started_at).slice(0,10))}</td></tr>`).join('')
    }</tbody></table></div>`;
}

function cardFixes(items){
  return `<div class="card">${items.map((f,i) => `<div class="fix">
      <b>${i+1}. ${esc(f.action)}</b>
      <div class="rate">${Math.round(f.success_rate*100)}% success over
        ${f.attempts_seen} attempt(s)${f.tool ? ` · tool: ${esc(f.tool)}` : ''}</div>
      <div style="font-size:12.5px;color:var(--slate);margin-top:3px">${esc(f.rationale)}</div>
    </div>`).join('')}</div>`;
}

function cardPreview(c){
  const p = c.plan;
  const actions = c.executable
    ? `<div style="margin-top:12px;display:flex;gap:9px">
         <button onclick="approve(this)">Approve and re-run</button>
         <button class="ghost" onclick="this.closest('.card').remove()">Not now</button></div>`
    : `<div class="rollback" style="color:var(--bad)">${esc(p.blocked_reason)}</div>`;
  return `<div class="card accent">
    <div class="kicker">Before you approve — exactly what will happen</div>
    <ol class="steps">${p.preview.map(s => `<li>${esc(s)}</li>`).join('')}</ol>
    <div class="rollback"><b>Rollback:</b> ${esc(p.rollback)}<br>
      <b>plan_id:</b> <code>${esc(p.plan_id)}</code></div>${actions}</div>`;
}

function cardResult(c){
  const r = c.result;
  const colour = l => /\[ERROR\]/.test(l) ? `<span class="e">${esc(l)}</span>`
                    : /\[WARN/.test(l) ? `<span class="w">${esc(l)}</span>`
                    : /SUCCEEDED/.test(l) ? `<span class="ok">${esc(l)}</span>`
                    : esc(l);
  return `<div class="result">
    <div class="runhead" style="margin:0 0 7px">
      <span>new run <b>${esc(r.run_id)}</b></span>
      <span>rows <b>${r.rows_written}</b></span>
      <span>coerced <b>${r.coerced}</b></span>
      <span>took <b>${r.duration_ms} ms</b></span></div>
    <a href="/${esc(r.output_file)}" download>Download ${esc(r.output_file)}</a>
    ${r.knowledge_entry ? `<div class="rollback">Learning loop: wrote
      <code>${esc(r.knowledge_entry)}</code> — the next occurrence of this signature
      is answered from memory.</div>` : ''}
    <div class="rollback">Gates passed:
      <code>${esc((r.gates_passed||[]).join(' → '))}</code></div>
  </div>
  ${c.lines && c.lines.length ? `<div class="card">
    <div class="kicker">New log, read back from inputs/pipeline_logs/local_demo/</div>
    <pre class="log">${c.lines.map(colour).join('\n')}</pre></div>` : ''}`;
}

function cardSources(items){
  return `<div class="card">${items.map(s => `<div class="src">
      <span class="pill ${s.can_rerun?'live':'ro'}">${s.can_rerun?'can re-run':'read only'}</span>
      <b>${esc(s.label)}</b><div class="path">${esc(s.folder)}</div></div>`).join('')}</div>`;
}

// ------------------------------------------------------------- approve
async function approve(btn){
  const card = btn.closest('.card');
  card.innerHTML = `<span class="spin"></span>
    <span style="color:var(--slate);margin-left:7px">re-running the job…</span>`;
  const {data} = await api('/api/chat/approve', {session_id:sessionId, role:role()});
  card.remove();
  if (data.error){ push(bubble('bot', esc(data.error))); return; }
  renderTurn(data.turn);
  loadStats();
}

// -------------------------------------------------------------- chrome
function onRole(){
  push(bubble('bot', `Switched to <b>${esc(role())}</b>. Permissions are re-checked
    on every action, so this takes effect immediately.`));
}

function newChat(){
  sessionId = null; hasFocus = false; turnCount = 0; ctxTurns = 0;
  $('msgs').innerHTML = '';
  updateFocus('');
  renderChips();
  greet();
  loadStats();
}

function greet(){
  push(bubble('bot',
    `I read <b>pipeline logs</b>, <b>execution history</b> and <b>error messages</b>
     across every onboarded source. Ask about a failure, then follow up naturally —
     I keep the run in focus, so "how confident are you?" or "re-run it" work without
     you repeating yourself.<br><br>Type <code>help</code> to see what I understand.`));
}

async function loadSources(){
  const r = await fetch('/api/sources'); const d = await r.json();
  $('sources').innerHTML = d.sources.map(s => `<div class="src">
      <span class="pill ${s.can_rerun?'live':'ro'}">${s.can_rerun?'can re-run':'read only'}</span>
      <b>${esc(s.label)}</b>
      <div class="path">${esc(s.log_folder)}</div>
      <div class="path">${s.open_failures} failed run(s)</div></div>`).join('');
}

async function loadStats(){
  const r = await fetch('/api/executions'); const d = await r.json();
  const s = d.summary;
  $('stats').innerHTML = `
    <div class="stat"><span>Turns this chat</span><b>${turnCount}</b></div>
    <div class="stat"><span>From context</span><b>${ctxTurns}</b></div>
    <div class="stat"><span>Questions logged</span><b>${s.questions_answered}</b></div>
    <div class="stat"><span>Actions executed</span><b>${s.actions_executed}</b></div>
    <div class="stat"><span>Actions refused</span><b>${s.actions_refused}</b></div>`;
}

async function showExecutions(){
  const r = await fetch('/api/executions'); const d = await r.json();
  const rows = d.rows.slice().reverse().slice(0, 25);
  push(bubble('bot', `Every turn and action is appended to
    <code>outputs/executions/copilot_executions.csv</code>.` +
    `<div class="card"><table><thead><tr><th>time</th><th>event</th><th>user</th>
     <th>run</th><th>outcome</th><th>ms</th></tr></thead><tbody>${
      rows.map(x => `<tr><td>${esc(x.timestamp_utc.slice(11,19))}</td>
        <td>${esc(x.event_type)}</td><td>${esc(x.user)}</td>
        <td>${esc(x.run_id)}</td><td>${esc(x.outcome).slice(0,38)}</td>
        <td>${esc(x.duration_ms)}</td></tr>`).join('')
     }</tbody></table></div>`));
}

loadSources();
loadStats();
renderChips();
greet();
