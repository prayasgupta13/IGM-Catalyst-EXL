"""Web layer — Python stdlib only, so `make web` works with no extra installs.

Routes
    GET  /                     the single-page UI
    GET  /api/sources          what's onboarded, and which can actually re-run
    POST /api/ask              question in, full diagnosis out
    POST /api/preview          the exact actions a re-run would take
    POST /api/approve          approve + execute (local demo really runs)
    GET  /api/executions       the execution CSV as JSON
    GET  /api/logs?run_id=     the redacted log window for one run
    GET  /outputs/<file>       download a CSV the demo job produced

Sessions live in memory keyed by execution_id, so /preview and /approve act on
the SAME plan the user was shown — an approval can never bind to a different
plan than the one on screen.
"""
from __future__ import annotations

import json
import mimetypes
import sys
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src import ingest  # noqa: E402
from src.agents import approve_and_run, ask  # noqa: E402
from src.config import load, sources  # noqa: E402
from src.conversation import approve as convo_approve  # noqa: E402
from src.conversation import get_session, respond  # noqa: E402
from src.execution_log import read_all, summary  # noqa: E402
from src.ingest import connect  # noqa: E402
from src.knowledge import coverage  # noqa: E402
from src.security import Principal  # noqa: E402

STATIC = Path(__file__).parent / "static"

ROLES = ["viewer", "support_l1", "support_l2", "data_engineer", "lead"]
USER_OF = {"viewer": "v.viewer", "support_l1": "l1.support", "support_l2": "l2.support",
           "data_engineer": "p.gupta", "lead": "team.lead"}

SESSIONS: dict[str, object] = {}


def principal(role: str, approved: bool = False) -> Principal:
    role = role if role in ROLES else "viewer"
    user = USER_OF[role]
    return Principal(user, role, approved_by=user if approved else None)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):        # quieter console
        pass

    # ------------------------------------------------------------------ util
    def _send(self, code: int, body: bytes, ctype: str) -> None:
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, code: int = 200) -> None:
        self._send(code, json.dumps(payload, default=str).encode(),
                   "application/json; charset=utf-8")

    def _body(self) -> dict:
        n = int(self.headers.get("Content-Length", 0))
        return json.loads(self.rfile.read(n) or b"{}")

    # ------------------------------------------------------------------- GET
    def do_GET(self) -> None:
        url = urlparse(self.path)
        q = parse_qs(url.query)
        try:
            if url.path in ("/", "/index.html"):
                return self._send(200, (STATIC / "index.html").read_bytes(),
                                  "text/html; charset=utf-8")
            if url.path.startswith("/static/"):
                f = STATIC / url.path[len("/static/"):]
                if not f.exists():
                    return self._json({"error": "not found"}, 404)
                ctype = mimetypes.guess_type(str(f))[0] or "text/plain"
                return self._send(200, f.read_bytes(), ctype)

            if url.path == "/api/sources":
                return self._json(self._sources())
            if url.path == "/api/executions":
                return self._json({"summary": summary(), "rows": read_all()[-60:]})
            if url.path == "/api/logs":
                return self._json(self._log_window(q.get("run_id", [""])[0]))
            if url.path == "/api/knowledge":
                return self._json(coverage())

            if url.path.startswith("/outputs/"):
                f = ROOT / url.path.lstrip("/")
                if not f.exists() or ".." in url.path:
                    return self._json({"error": "not found"}, 404)
                return self._send(200, f.read_bytes(), "text/csv")

            return self._json({"error": "not found"}, 404)
        except Exception as exc:
            traceback.print_exc()
            return self._json({"error": str(exc)}, 500)

    # ------------------------------------------------------------------ POST
    def do_POST(self) -> None:
        url = urlparse(self.path)
        try:
            body = self._body()

            if url.path == "/api/ingest":
                return self._json(ingest.run(verbose=False))

            if url.path == "/api/chat":
                role = body.get("role", "data_engineer")
                session = get_session(body.get("session_id"), role)
                turn = respond(session, body.get("message", ""), principal(role))
                return self._json({"session_id": session.session_id,
                                   "focus": session.focus,
                                   "turn": turn.to_dict()})

            if url.path == "/api/chat/approve":
                role = body.get("role", "data_engineer")
                session = get_session(body.get("session_id"), role)
                if not session.has_context:
                    return self._json({"error": "no run in focus"}, 409)
                turn = convo_approve(session, principal(role, approved=True))
                return self._json({"session_id": session.session_id,
                                   "turn": turn.to_dict()})

            if url.path == "/api/ask":
                role = body.get("role", "data_engineer")
                answer = ask(body.get("question", ""), principal(role))
                SESSIONS[answer.execution_id] = answer
                return self._json(answer.to_dict())

            if url.path == "/api/preview":
                answer = SESSIONS.get(body.get("execution_id", ""))
                if answer is None or answer.plan is None:
                    return self._json({"error": "no plan for that execution"}, 404)
                return self._json({"plan": answer.plan.to_dict(),
                                   "requires_role": load()["rbac"]["actions"]
                                   .get(answer.plan.tool, {}).get("permission")})

            if url.path == "/api/approve":
                answer = SESSIONS.get(body.get("execution_id", ""))
                if answer is None:
                    return self._json({"error": "session expired — re-ask"}, 404)
                p = principal(body.get("role", "data_engineer"), approved=True)
                try:
                    result = approve_and_run(answer, p)
                except PermissionError as exc:
                    return self._json({"refused": True, "reason": str(exc)}, 403)
                ingest.run(verbose=False)          # re-read inputs so logs show up
                result["new_logs"] = self._log_window(result.get("run_id", ""),
                                                      include_success=True)
                return self._json(result)

            return self._json({"error": "not found"}, 404)
        except Exception as exc:
            traceback.print_exc()
            return self._json({"error": str(exc)}, 500)

    # -------------------------------------------------------------- helpers
    def _sources(self) -> dict:
        conn = connect()
        counts = {r["platform"]: r["n"] for r in conn.execute(
            "SELECT platform, COUNT(*) n FROM fact_failure GROUP BY platform")}
        conn.close()
        out = []
        for sid, spec in sources().items():
            out.append({"id": sid, "label": spec["label"],
                        "can_rerun": bool(spec.get("can_rerun")),
                        "log_folder": f"inputs/pipeline_logs/{spec['log_folder']}",
                        "open_failures": counts.get(sid, 0)})
        return {"sources": out, "roles": ROLES}

    def _log_window(self, run_id: str, include_success: bool = False) -> dict:
        if not run_id:
            return {"run_id": "", "lines": []}
        # failures live in the fact table; successes only in the raw log folder
        conn = connect()
        row = conn.execute("SELECT log_file, log_window, status FROM fact_failure "
                           "WHERE run_id = ?", (run_id,)).fetchone()
        conn.close()
        if row and row["log_window"]:
            return {"run_id": run_id, "status": row["status"],
                    "log_file": row["log_file"],
                    "lines": row["log_window"].splitlines()}
        if include_success:
            from src.parsers import for_source
            folder = ROOT / "inputs" / "pipeline_logs" / "local_demo"
            for f in folder.glob(f"*{run_id}*.jsonl"):
                parsed = for_source("local_demo").parse(f)
                return {"run_id": run_id, "status": "success",
                        "log_file": str(f.relative_to(ROOT)),
                        "lines": parsed.get("log_window", "").splitlines()}
        return {"run_id": run_id, "lines": []}


def main() -> None:
    cfg = load()["web"]
    ingest.run(verbose=False)
    srv = ThreadingHTTPServer((cfg["host"], cfg["port"]), Handler)
    print(f"\n  Pipeline Failure Copilot")
    print(f"  http://{cfg['host']}:{cfg['port']}\n")
    print("  Ask:      \"why did orders_export fail\"")
    print("  Then:     \"how confident are you?\"  \"has this happened before?\"")
    print("            \"show me the log\"  \"re-run it\"\n")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n  stopped")


if __name__ == "__main__":
    main()
